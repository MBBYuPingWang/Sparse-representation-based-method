function test0()
clc 
Ac=1000;
Ar=200;
A=rand(Ar,Ac);
x=zeros(Ac,1);
y=zeros(Ar,1);
y(1:floor(Ar))=1;
lx=size(A,2);
% [x]=Homotophy(A,y,lx)
% [x]=SolveOMP(A,y,lx)
% x=myMFOCUSS(A, y, 0.5)
% x = SolveLasso(A,y);
% x= SolveBP(A, y,lx)%not good
x= SolveStOMP(A, y,lx);

ix=find(x<1e-5)
ix=ix(1)
A(:,ix)=[];%remove the column that not been selected
lx=size(A,2);
% [x1]=Homotophy(A,y,lx)
% [x1]=SolveOMP(A,y,lx)
% x1=myMFOCUSS(A, y, .5)
% x1 = SolveLasso(A,y);
% x1= SolveBP(A, y,lx);%not good
x1= SolveStOMP(A, y,lx);

%test the results
x(ix)=[];
x2=x-x1
xd=sum(abs(x-x1))

function testStepSRVS()
A0=rand(30,300);
windL=inf;
class1Num=15;
Lp=0.5;
x=stepSRVS_selectVars(A0,windL,class1Num,Lp);