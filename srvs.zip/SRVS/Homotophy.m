function [sol,numIters] =Homotophy(A,y,n)
% SolveHomotophy: Implementation of Iterative Threshold-Selective Projection
% algorithm
% Usage
%	[solo, numIters] = Homotophy(A, y,n)
% Input
%	A           Either an explicit nxN matrix, with rank(A) = min(N,n) 
%               by assumption, or a string containing the name of a 
%               function implementing an implicit matrix (see below for 
%               details on the format of the function).
%	y           vector of length n.
%   n           length of solution vector. 
%  Outputs 
%  sol       the solution of iteration from the equation of y= Ax+Larmda*(||x||)
%	 numIters   Total number of steps taken.
%  Error tolerance, default 1e-3.

thresh = 1e-3; 

numIters=0;
x=zeros(n,1);
sign_CI=zeros(n,1);
m=size(A,1);

C=A'*y;%C is residual correlation matrix while x0=0

[Larmda index]=max(abs(C));% initial Larmda and I
I=index;
sign_CI=sign(C(I));
C(I)=Larmda*sign_CI;

old_Delta=0;
old_Larmda=0;
old_x=x;
count_delta_stop=0;

% AtiAi=A(:,I)'*A(:,I);
% iAtiAi=pinv(AtiAi);

while(1)
 
numIters=numIters+1;

old_x=x;
old_Larmda=Larmda;

AtiAi=A(:,I)'*A(:,I);
iAtiAi=pinv(AtiAi);

% Calculate d(I)    
delta_x_vec=zeros(n,1);
delta_x_vec(I)=iAtiAi*sign_CI;

% Calculate Gama_pos and Gama_neg
%Get I_C off-surport of x
temp_I=zeros(n,1);
temp_I(I)=I;
I_C=find([1:n]'~=temp_I);

%dC=A'*A*delta_l=A'*(A(I)*delta_l(I))

dC=A'*(A*delta_x_vec);

%Calculate positive Residual 
pos_index=0;
neg_index=0;
flag=-1;%flag for Adding or Removing element

Gama_1=(Larmda-C(I_C))./(1-dC(I_C));
Gama_1_pos_index=find(Gama_1>0);
Gama_1_pos=Gama_1(Gama_1_pos_index);
[Delta_pos_1 pos_index_1]=min(Gama_1_pos);
if(isempty(Delta_pos_1))
    Delta_pos_1=inf;
end

Gama_2=(Larmda+C(I_C))./(1+dC(I_C));
Gama_2_pos_index=find(Gama_2>0);
Gama_2_pos=Gama_2(Gama_2_pos_index);
[Delta_pos_2 pos_index_2]=min(Gama_2_pos);
if(isempty(Delta_pos_2))
    Delta_pos_2=inf;
end

if(Delta_pos_1>Delta_pos_2)
    Delta_pos=Delta_pos_2;
    pos_index=I_C(Gama_2_pos_index(pos_index_2));
else
    Delta_pos=Delta_pos_1;
    pos_index=I_C(Gama_1_pos_index(pos_index_1));    
end

%Calculate negative residual
Gama_neg=-(x(I)./delta_x_vec(I));
Gama_neg_index=find(Gama_neg>0);
[Delta_neg neg_index]=min(Gama_neg_index);
neg_index=I(Gama_neg_index(neg_index));


% add an new element or remove one
if Delta_neg>0 & Delta_pos>Delta_neg
    %Remove old
    Delta=Delta_neg;
    flag=1;
else
    % Add new
    Delta=Delta_pos;
    flag=0;
end


%Update x, C, Larmda
x=old_x+Delta*delta_x_vec;
C=C-Delta*dC;
Larmda=old_Larmda-Delta;

%continue iter or stop 
%
if old_Delta < 4*eps & Delta < 4*eps
    count_delta_stop = count_delta_stop + 1;
else
    count_delta_stop = 0;
end
if count_delta_stop >= 100
    disp('stuck in some corner');
    break;
end
old_Delta = Delta;

%condition for stopping iteration
if(Larmda==0)
    Estimate_X=x;
    break;
end

%
if Larmda < thresh; 
    delta_end = old_Larmda-thresh;
    C = C-delta_end*dC;
    x = old_x + delta_end*delta_x_vec;
%     disp('done!');
    break;
end

%
% if numIters > 1000
%     disp('too many iterations');
%     break;
% end
%

%Update I,A(I) and dC
if(flag==0)
 %add new element to support of I
    if(~ismember(pos_index,I))
       I=sort([I pos_index]);
    end
    %x(pos_index)=0;
else
 %remove an old element from I
    if(ismember(neg_index,I))
        temp_index=find(I==neg_index);
        I(temp_index)=[];
    end
     x(neg_index)=0;

end

%Update sign of C
sign_CI=zeros(n,1);
sign_CI=sign(C(I));
C(I)=Larmda*sign_CI;

end

Estimate_X=x;
sol=Estimate_X;

Y_Estimate=A*x;
% [y;Y_Estimate];
Error=sqrt(sum((y-Y_Estimate).^2));

%[min_resudual index]=SRC(A,m,n,5*ones(1,20),y,x);










