function varargout = SRVS(varargin)
% _______________________________________________________
% Copyright(c) 2013
% Tulane University,Department of Biomedical Engineering, Tulane
% University, New Orleans, LA, USA
% Written by Hongbao Cao
% http://hongbaocao.weebly.com/software-for-download.html
% Mail to Authors:  caohon2010@gmail.com, wyp@tulane.edu
% H. Cao, J. Duan, D. Lin, V. Calhoun, Y. Wang, BMC Medical Genomics, 2013 6(3):S2, doi:10.1186/1755-8794-6-S3-S2.
% _______________________________________________________
% Last Modified by GUIDE v2.5 26-May-2014 10:50:46

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @SRVS_OpeningFcn, ...
                   'gui_OutputFcn',  @SRVS_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before SRVS is made visible.
function SRVS_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to SRVS (see VARARGIN)

% Choose default command line output for SRVS
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);
%add some work path 
currentDir=pwd;
[parentDir,grandDir]=addPath();
setappdata(handles.dlg_SRVS,'parentDir',parentDir);
setappdata(handles.dlg_SRVS,'currentDir',currentDir);
clc

setappdata(handles.dlg_SRVS,'stopE',0.001);
setappdata(handles.dlg_SRVS,'stopP',1e-4);
setappdata(handles.dlg_SRVS,'Lp',1/2);
setappdata(handles.dlg_SRVS,'winLength',1/20);
setappdata(handles.dlg_SRVS,'Tal',0.4);
setappdata(handles.dlg_SRVS,'VarNum',inf);
setappdata(handles.dlg_SRVS,'maxIter',60);

set(handles.edit_stopE,'Enable','off');
set(handles.edit_stopP,'Enable','off');
set(handles.edit_Lp,'Enable','off');
set(handles.edit_winLength,'Enable','off');
set(handles.edit_Tal,'Enable','off');
set(handles.edit_VarNum,'Enable','off');
set(handles.edit_MaxIter,'Enable','off');



% --- Outputs from this function are returned to the command line.
function varargout = SRVS_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
currentDir=getappdata(handles.dlg_SRVS,'currentDir');
    [filename, pathname, filterindex] = uigetfile(  { '*.mat','MAT-files (*.mat)';}, ...
        'Pick a file',...
        'MultiSelect', 'on',...
    strcat(currentDir,'\work data\'));

stopE=getappdata(handles.dlg_SRVS,'stopE');
stopP=getappdata(handles.dlg_SRVS,'stopP');
Lp=getappdata(handles.dlg_SRVS,'Lp');
winLength=getappdata(handles.dlg_SRVS,'winLength');
Tal=getappdata(handles.dlg_SRVS,'Tal');
VarNum=getappdata(handles.dlg_SRVS,'VarNum');
maxIter=getappdata(handles.dlg_SRVS,'maxIter');
disp('Selecting variables, please wait...');
SRVS_selectVars(filename,pathname,Lp,maxIter,stopE,stopP,winLength,Tal,VarNum);




% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
close(handles.dlg_SRVS);


% --- Executes during object creation, after setting all properties.
function edit_stopE_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_stopE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function edit_Tal_Callback(hObject, eventdata, handles)
val=str2num(get(hObject,'string'));
setappdata(handles.dlg_SRVS,'Tal',val);

setappdata(handles.dlg_SRVS,'VarNum',inf);
set(handles.edit_VarNum,'String','inf');
set(handles.edit_VarNum,'Enable','off');



function edit_VarNum_Callback(hObject, eventdata, handles)
val=str2num(get(hObject,'string'));
setappdata(handles.dlg_SRVS,'VarNum',val);

setappdata(handles.dlg_SRVS,'Tal',0);
set(handles.edit_Tal,'String','0');
set(handles.edit_Tal,'Enable','off');




function edit_stopE_Callback(hObject, eventdata, handles)
val=str2num(get(hObject,'string'));
setappdata(handles.dlg_SRVS,'stopE',val);

function edit_stopP_Callback(hObject, eventdata, handles)
val=str2num(get(hObject,'string'));
setappdata(handles.dlg_SRVS,'stopP',val);

function edit_Lp_Callback(hObject, eventdata, handles)
val=str2num(get(hObject,'string'));
setappdata(handles.dlg_SRVS,'Lp',val);

function edit_winLength_Callback(hObject, eventdata, handles)
val=str2num(get(hObject,'string'));
setappdata(handles.dlg_SRVS,'winLength',val);

function edit_MaxIter_Callback(hObject, eventdata, handles)
val=str2num(get(hObject,'string'));
setappdata(handles.dlg_SRVS,'maxIter',val);


% --- Executes during object creation, after setting all properties.
function edit_stopP_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_stopP (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end




% --- Executes during object creation, after setting all properties.
function edit_Lp_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_Lp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end




% --- Executes during object creation, after setting all properties.
function edit_winLength_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_winLength (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton_Default.
function pushbutton_Default_Callback(hObject, eventdata, handles)
% setappdata(handles.dlg_SRVS,'stopE',0.001);
% set(handles.edit_stopE,'String','0.001');
% 
% setappdata(handles.dlg_SRVS,'stopP',1e-4);
% set(handles.edit_stopP,'String','1e-4');
% 
% setappdata(handles.dlg_SRVS,'Lp',1/2);
% set(handles.edit_Lp,'String','1/2');
% 
% setappdata(handles.dlg_SRVS,'winLength',1/20);
% set(handles.edit_winLength,'String','1/20');

set(handles.edit_stopE,'Enable','on');
set(handles.edit_stopP,'Enable','on');
set(handles.edit_Lp,'Enable','on');
set(handles.edit_winLength,'Enable','on');
set(handles.edit_Tal,'Enable','on');
set(handles.edit_VarNum,'Enable','on');
set(handles.edit_MaxIter,'Enable','on');




% --- Executes during object creation, after setting all properties.
function edit_Tal_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_Tal (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end






% --- Executes during object creation, after setting all properties.
function edit_VarNum_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_VarNum (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



% --- Executes during object creation, after setting all properties.
function edit_MaxIter_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_MaxIter (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
