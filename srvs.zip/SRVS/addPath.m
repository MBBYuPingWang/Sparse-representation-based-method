function [pathParent,pathGrad]=addPath()
%pathParent,pathGrad are the one level and two level upper root path
disp('The following pathes are added:');
%add the dirs undersame root dir

%get the parent path
path0=pwd;
p1=find(path0=='\');
p1=p1(length(p1));
path0=path0(1:p1-1);
pathParent=path0;


%add the dirs under one hihger level root dir
path0=pathParent;
p1=find(path0=='\');
p1=p1(length(p1));
pathGrad=path0(1:p1-1);

