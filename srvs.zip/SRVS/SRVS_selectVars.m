function SRVS_selectVars(filename,pathname,Lp,maxIter,stopE,stopP,winLength,Tal,VarNum)
%this function select the columns significant from the data given in the
%pathname+filename
%stopE is the stop Error threshold
%stopP is the stop probablility threshold
% Lp is the Lp normalization panalty term
% winLength=window length/column numbers
%Tal=norm(y-Ax)/norm(y);
%VarNum is the number of variables to be selected

filePath=fullfile(pathname,filename);
if filename==0
    disp('----------Warning----------');
    disp('Please select the data file containing variable X and y!')
    disp('----------Warning----------');
    return;
end
disp(strcat('Data source is:',filePath));
load(filePath,'X','y');
variables=who;
if ~ismember('X',variables)||~ismember('y',variables)
    disp('----------Warning----------');
    disp('Please select the data file containing variable X and y!')
    disp('----------Warning----------');
    return;
end

[x,y,goodIndex,goodSN,Err]=selectVars(X,y,Lp,maxIter,stopE,stopP,winLength,Tal,VarNum);

%save the results
if Lp==1||Lp==0
    filePath=fullfile(pathname,sprintf('results_L%d.mat',Lp));
else
    filePath=fullfile(pathname,sprintf('results_L%1.1f.mat',Lp));
end
save(filePath,'x','y','goodIndex','goodSN','Err','Lp','maxIter','stopE','stopP','winLength','Tal','VarNum');
disp('------------------------');
disp('The results were saveed to:');
disp(filePath);


