function q=innerP(u,v)
%this function gives the inner product of two vectors
if nargin<2
    q=sum(u.*u);
    return;
end
if size(u)~=size(v)
    disp('The dimension of the vectors must be same for inner product!');
    return;
end

q=sum(u.*v);
