function deleteG()


HPath=pwd;
lh=length(HPath);
HPath(lh+1:lh+13)='\Dapi_G_C.mat';
delete(HPath);
