function [mv,ClassN,ClassV]=FindMaxFre(A,exp)
%Find the max frequent value in a matrix, not consider the values specified
%by 'exp'
%ClassN contains the numbers of points for each value 
%ClassV contains the conresponding value
if nargin<2,
    exp=[];
end

MaxA=max(max(A));
MinA=min(min(A));
nClass=MaxA-MinA+1;%the class of values

ClassN=zeros(nClass,1);
ClassV=zeros(nClass,1);
n=0;
for i=MinA:MaxA
    if isempty(find(exp==i))==0, continue; end % don't consider the values specified by 'exp'
    n=n+1;
    index=find(A==i);
    ClassN(n)=length(index);
    ClassV(n)=i;    
end
ClassN=ClassN(1:n);%remove the unused parts
ClassV=ClassV(1:n);
index=find(ClassN==max(ClassN));
mv=ClassV(index);
return;



     
        
        
        





