function HG=ReviseHG(Y,center,HG)
%This is designed for one image segmentation into 2 class
maxCen=max(center);
minCen=min(center);

lY=length(Y);

if minCen==0, 
    return;
end

for i=1:lY
    if Y(i)>=maxCen%top layer
        HG(i)=max([1,HG(i)]);%>=1
        HG(i)=min([Y(i)/maxCen,HG(i)]);%<=Y(i)/maxCen
        continue;
    end
    if Y(i)>=minCen&&Y(i)<maxCen%middle layer
        HG(i)=min([Y(i)/minCen,HG(i)]);%<=Y(i)/minCen
        HG(i)=max([Y(i)/maxCen,HG(i)]);%>=Y(i)/maxCen
        continue;
    end
    if Y(i)<minCen%middle layer
        HG(i)=min([Y(i)/minCen,HG(i)]);%<=Y(i)/minCen
        HG(i)=max([0,HG(i)]);%>=0
        continue;
    end
end
        
        