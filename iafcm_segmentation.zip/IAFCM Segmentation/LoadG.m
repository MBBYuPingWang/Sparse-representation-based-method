function [G,C,beGood]=LoadG()

HPath=pwd;
lh=length(HPath);
HPath(lh+1:lh+13)='\Dapi_G_C.mat';
load(HPath,'G','C','indexD');
G=G(indexD);
beGood=1;
