function beGood=SetHGPara(r,level,ImSize,beDAPI)

%this function set the parameters for the coarsegrid method for H*G
beGood=0;
HPath=pwd;
lh=length(HPath);
HPath(lh+1:lh+11)='\HGPara.mat';
save(HPath,'r','level','ImSize','beDAPI');
beGood=1;

