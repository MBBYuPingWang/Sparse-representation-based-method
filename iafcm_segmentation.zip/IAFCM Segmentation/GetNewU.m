function [U]=GetNewU(Yim,G,center,expo)
%calculte new U and UK(i,j,k)=||Y(:,i,j)-G(i,j)*center(:,k)||^2

%new distance
dist = MyDistfcm(center,G,Yim);       % fill the distance matrix

index=find(dist<1e-5);
if isempty(index)==0
    dist(index)=1e-5;
end

tmp = dist.^(-2/(expo-1));      % calculate new U, suppose expo != 1
U = tmp./(ones(size(center,1), 1)*sum(tmp));
U=U';




























































        
        


