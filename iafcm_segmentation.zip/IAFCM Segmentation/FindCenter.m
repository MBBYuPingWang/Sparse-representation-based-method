function center=FindCenter(FilePath)
% clc
% FilePath='C:\My Folder\MFISH database\test data_00\V1306XY.mat';
load(FilePath);
Im7=A(:,:,7);
index=find(Im7>24);
Im7(index)=0;

nclass=max(Im7(:));
center=zeros(nclass+1,6);
for i=0:nclass
    index=find(Im7==i);
    for j=1:6
        Im=A(:,:,j);
        temp=Im(index);
        if i==0
            temp1=mean(temp(1:10:length(index)));
        else
            temp1=mean(temp);
        end
        center(i+1,j)=max(temp1(:));
    end
end




        