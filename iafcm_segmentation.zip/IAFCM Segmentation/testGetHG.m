function testGetHG()

clc

FilePath='E:\research work1\MFISH database\test data_8\V1306XY.mat';
load(FilePath);
Im6=double(A(:,:,6));

Im=Im6(:,:);
% Im=double(Im);
figure;
 h = imshow(Im,[0 255]);
% imagesc(Im);
% 
Im=GetHG(Im,9,4);
% 
figure;
imshow(Im,[0 255]);