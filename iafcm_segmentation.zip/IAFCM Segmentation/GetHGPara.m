function [r,level,ImSize,beDAPI]=GetHGPara()

HPath=pwd;
lh=length(HPath);
HPath(lh+1:lh+11)='\HGPara.mat';
load(HPath);