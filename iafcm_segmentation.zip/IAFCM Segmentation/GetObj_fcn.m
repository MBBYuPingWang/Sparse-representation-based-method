function obj_fcn=GetObj_fcn(Yim,U,G,center,expo)
%This function is used to get the value of the Objective function

cluster_n=size(U,2);
Iml=length(Yim);

obj_fcn=0;
for j=1:Iml
    for k=1:cluster_n
        obj_fcn=obj_fcn+U(j,k)^expo*innerP(Yim(j,:)-G(j)*center(k,:));
    end
end
        
