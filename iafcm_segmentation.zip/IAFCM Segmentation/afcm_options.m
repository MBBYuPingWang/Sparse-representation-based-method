function [expo,max_iter,min_impro,display,r]=afcm_options(options)

% Change the following to set default options
default_options = [2;	% exponent for the partition matrix U
		100;	% max. number of iteration
		1e-5;	% min. amount of improvement
		1;	% info display during iteration 
        1];%r

 if nargin<1
    options = default_options;
    expo = options(1);		% Exponent for U
    max_iter = options(2);		% Max. iteration
    min_impro = options(3);		% Min. improvement
    display = options(4);		% Display info or not
    r= options(4);		% raias of the smooth kernel 
    return;
 end
    
% If "options" is not fully specified, pad it with default values.
	if length(options) < 5,
		tmp = default_options;
		tmp(1:length(options)) = options;
		options = tmp;
	end
	% If some entries of "options" are 'nan', replace them with defaults.
	nan_index = find(isnan(options)==1);
	options(nan_index) = default_options(nan_index);
	if options(1) <= 1,
		error('The exponent should be greater than 1!');
	end

expo = options(1);		% Exponent for U
max_iter = options(2);		% Max. iteration
min_impro = options(3);		% Min. improvement
display = options(4);		% Display info or not
r= options(4);		% raias of the smooth kernel 