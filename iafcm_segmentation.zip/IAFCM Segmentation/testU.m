function testU()
clc
% FilePath='C:\My Folder\MFISH database\test data_3\A0105XY.mat'; 
% FilePath='C:\My Folder\MFISH database\test data\V1306XY.mat';
% FilePath='C:\My Folder\MFISH database\test data_9\V1306XY.mat';
% FilePath='C:\My Folder\MFISH database\test data_5\V1313XY.mat';
% FilePath='C:\My Folder\MFISH database\test data_2\A0104XY.mat';
FilePath='C:\My Folder\MFISH database\test data_4\V1310XY.mat';

fpl=length(FilePath);
load(FilePath);
Im6=A(:,:,6);
[Imr,Imc]=size(Im6);

n=6;
Im=A(:,:,n);
figure;
imshow(Im);


temp=sprintf('%d_U_C_G_IAFCM.mat',n);
lt=length(temp);
FilePath(fpl-3:fpl+lt-4)=temp
load(FilePath,'U','center','G','ImSize','n','r');
center
Im=zeros(Imr,Imc);
Id=find(center==max(center));
index=find(U(:,Id)>=0.5);

Im(index)=1;
ImU=Im;

figure;
imshow(ImU);
title('U');

figure;
plot(U(:,Id));

Im(:)=G(:);
figure;
imshow(Im/max(Im(:)));
title('G');

max(Im(:))







% Im=Im6;
% 
% index=find(Im6>55);
% Im(index)=255;
% figure;
% imshow(Im);
% title('Pixels with higher density than 55');