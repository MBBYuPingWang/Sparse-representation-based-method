function [center,U,G,beGood]=UpdateUCG(Yim,cluster_n,center,G,expo,r,ImSize)
%this funciton update the new center,U and G for IAFCM


%calculate new U
% time5=clock;
[U]=GetNewU(Yim,G,center,expo);
% time6=clock;
% usedt=(time6(5)-time5(5))*60+(time6(6)-time5(6))


%calculate new center
[center]=GetNewCenter(Yim,G,U,expo);
% time5=clock;
% usedt=(time6(5)-time5(5))*60+(time6(6)-time5(6))


%update G
[G,beGood]=GetNewG(Yim,center,U,G,cluster_n,expo,r,ImSize);




