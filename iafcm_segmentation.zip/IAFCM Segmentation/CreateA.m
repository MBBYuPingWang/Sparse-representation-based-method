function center=FindCenter(FilePath)
clc
FilePath='C:\My Folder\MFISH database\test data_01\V1306XY.mat';
load(FilePath);
A0=A;
Im7=A(:,:,7);
index=find(Im7>24);
Im7(index)=0;
index=find(Im7==0);


nclass=max(Im7(:));
center=zeros(nclass+1,6);
for i=0:nclass
    index=find(Im7==i);
   
    for j=1:6      
        temp=A(:,:,j);
        temp=mean(temp(index));
        if temp>100
            temp=255;
        else
            temp=0;
        end
        li=length(index);
        [idr,idc]=find(Im7==i);
        for m=1:li            
            A0(idr(m),idc(m),j)=temp;
        end
        
    end
end
lfp=length(FilePath);
FilePath(lfp-3:lfp+1)='1.mat';


 
A0(:,:,7)=Im7;
for i=1:7
    Im=A0(:,:,i);
    figure;
    imshow(Im);
end
A=A0;
save(FilePath,'A','center');
        