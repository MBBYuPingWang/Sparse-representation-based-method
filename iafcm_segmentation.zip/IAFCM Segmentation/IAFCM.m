function [center, U, G, obj_fcn,n]=IAFCM(Yim,cluster_n, options)
%Yim=[Imr,Imc] is the size of a 2-D image, for 2-D images
%cluster_n is the number of classes to be seperated
%options for the clustering process:
%       OPTIONS(1): exponent for the matrix U             (default: 2.0)
%       OPTIONS(2): maximum number of iterations          (default: 100)
%       OPTIONS(3): minimum amount of improvement         (default: 1e-5)
%       OPTIONS(4): info display during iteration         (default: 1)
%       OPTIONS(5): radium of the radium of the moving smooth kernel
%center=[cluster_n,Imd], function number U=[Iml,cluster_n],gain filed G=[Iml,1];
% where Iml=Imr*Imc, and [Imr,Imc]=ImSize is the size of the image
%obj_fcn is the value of iafcm objective function
%n is the number of iterations

if nargin<3
    %extract info from options
    [expo,max_iter,min_impro,display,r]=afcm_options();
else
    [expo,max_iter,min_impro,display,r]=afcm_options(options);
end

if cluster_n<2
    error('The clusters have to be more than one!');
end


%get the image size
[Imr,Imc,Imd]=size(Yim);
ImSize=[Imr,Imc];

Yim=reshape(Yim,[Imr*Imc,Imd]);
%set the initial center center, function number U and gain filed G
[center,U,G]=initiIAfcm(cluster_n,Yim);
U0=U;
G0=G;
% center=center;
tolU=100;
% % Main loop
for i = 1:max_iter,
    n=i;
    time5=clock;
    %calculate the new center,U and G
    [center,U,G,beGood]=UpdateUCG(Yim,cluster_n,center,G,expo,r,ImSize); 
        
    tolG=max(max(abs(G-G0)));
    tolU=max(max(abs(U-U0)));
    time6=clock;
    usedt=(time6(5)-time5(5))*60+(time6(6)-time5(6));
    
    if display==1
        disp('==================================');
        disp('This is iteration :');
        disp(n);
        disp('The centers are:')
        disp(center(:,:));
        disp('The maxtimum change of G and U are:');
        disp(tolG);
        disp(tolU);
        disp('This iteration used time is:');
        disp(usedt);
    end  
    if tolU<min_impro
        break;
    end   
    G0=G;    
    U0=U;
end

obj_fcn=GetObj_fcn(Yim,U,G,center,expo);



















