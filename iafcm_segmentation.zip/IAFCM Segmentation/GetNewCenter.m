function [center]=GetNewCenter(Yim,G,U,expo)
%this function used to get the new center 

%new center and objective function
mf = U.^expo;       % MF matrix after exponential modification
temp=(G.*G)'*mf;

index=find(temp<1e-4);
if isempty(index)==0
    temp(index)=1e-4;
end

mf = mf.*(G*ones(1,size(mf,2))); 
mf=mf';

center = mf*Yim./(ones(size(Yim, 2), 1)*temp)'; % new center