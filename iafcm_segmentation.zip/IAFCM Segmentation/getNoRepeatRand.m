function A=getNoRepeatRand(m,n)
%this function get m rows n columns random 01code
if m>2^n
    error('This could not be done!');
    return;
end

A=zeros(m,n);
% size(A)

tt=0;
while 1    
    tt=tt+1;
    if tt>m break; end
        
    A(tt,:)=rand(1,n);

    for j=1:n
        if A(tt,j)>0.5
            A(tt,j)=1;
        else
            A(tt,j)=0;
        end
    end
    
    if tt<2, continue; end
    
    for k=1:tt-1
        if sum(abs(A(k,:)-A(tt,:)))==0
%             disp('not good');
            tt=tt-1;
            break;
        end
    end  
end