function Im=ImSmooth(Im,r,level)
%This funcion use a square with width of (2*r+1) to smooth the Im
% % 
% figure;
% imshow(Im);
if nargin<3
    level=1;
end

[Imr,Imc]=size(Im);
ii=0;
jj=0;
for i=r+1:Imr-r 
    ii=ii+1;
    if mod(ii,level)~=0%even number
        Im(i,:)=Im(i-1,:);
        continue;
    end
    jj=0;
    for j=r+1:Imc-r
        jj=jj+1;
        if mod(jj,level)~=0
            Im(i,j)=Im(i,j-1);
            continue;
        end
        temp=Im(i-r:i+r,j-r:j+r);
%         Im(i,j)=(mean(temp(:))*(2*r+1)^2-Im(i,j))/((2*r+1)^2-1);
        Im(i,j)=mean(temp(:));
    end
end

%deal with the edeges
for j=r+level:-1:1
    Im(:,j)=Im(:,j+1);
end

for j=Imc-r:Imc
    Im(:,j)=Im(:,j-1);
end

%deal with the edeges
for i=r+level:-1:1
    Im(i,:)=Im(i+1,:);
end

for i=Imr-r:Imr
    Im(i,:)=Im(i-1,:);
end


% 

% figure;
% imshow(SIm);
% i=i;
