function [W,fw]=Get_W_fw(Yim,center,U,cluster_n,expo)
%this function get the W and fw
if nargin<5
    expo=2;
end

%get w and fw, w(i) will be the diagnal elements of A, and Ag=fw
Lu=length(Yim);%image length
W=zeros(Lu,1);
fw=zeros(Lu,1);
% % testing used time
% time1=clock;
Dim=size(Yim,2);

if Dim==1%this is a one dimension imagem group
        for j=1:Lu
            for k=1:cluster_n
            temp=U(j,k)^expo;
            W(j)= W(j)+ temp*center(k)^2;
            fw(j)= fw(j)+temp*Yim(j)*center(k);
            end  
        end     
else
    for j=1:Lu
    for k=1:cluster_n
        W(j)= W(j)+ U(j,k)^expo*innerP(center(k,:),center(k,:));
        fw(j)= fw(j)+U(j,k)^expo*innerP(Yim(j,:),center(k,:));
    end  
    end    
end








    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    








