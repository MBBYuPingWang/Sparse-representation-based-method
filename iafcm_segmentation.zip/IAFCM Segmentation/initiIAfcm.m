function [center,U,G]=initiIAfcm(cluster_n,data)

%set the initial center center=[cluster_n,Imd], 
%function number U=[Iml,cluster_n],gain filed G=[Iml,1];

%initialize center center
[dl,Imd]=size(data);

% if cluster_n>2^Imd
%     error('This could not be done');
% end

%get all the possible center 
center=rand(cluster_n,Imd);

for i=1:Imd
    tempMax=max(data(:,i));
    tempMin=min(data(:,i));
    step=(tempMax-tempMin)/cluster_n;
    for j=1:cluster_n
        center(j,i)=tempMin+step;
    end
end


if Imd==1,%one image segmentation
    center=rand(cluster_n,1);
    center(1)=max(data(:));
end

%initialize function number U
U=rand(dl,cluster_n);

%initialize gain field G
G=ones(dl,1);




