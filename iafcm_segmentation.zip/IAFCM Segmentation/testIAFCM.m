function testIAFCM()
%this is an example of using IAFCM method to segment a 2-D image

clc
close all;
FilePath='E:\research works\research work1\data\test data_10\V1601XX.mat';

% load(FilePath);

A=floor(rand(80,80,1)*200);
figure;
imagesc(A(:,:,1));
title('Original image')


[Ar,Ac,Ad]=size(A);
ImSize=[Ar,Ac];
%this function set the parameters for the coarsegrid method
r=5;
level=1;

fpl=length(FilePath);

for i=1
 time5=clock;
[center, U, G, obj_fcn,n]=IAFCM(A,2,[2,25,1e-2,1,r]);

disp('------------------------------------------------');
center=center
sizeU=size(U)
sizeG=size(G)
obj_fcn=obj_fcn
time6=clock;
usedtime=(time6(5)-time5(5))*60+(time6(6)-time5(6))

temp=sprintf('%d_U_C_G_4.mat',i);
lt=length(temp);
FilePath(fpl-3:fpl+lt-4)=temp;
save(FilePath,'U','center','G','ImSize','n','r');
disp('The file is save to:')
disp(FilePath);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%perform image segmentation using U

indexH=find((U(:,1)-U(:,2))>0);
sizeH=length(indexH)
BW=zeros(Ar,Ac);
BW(indexH)=1;
figure;
imagesc(BW);
title('Segmented image')




