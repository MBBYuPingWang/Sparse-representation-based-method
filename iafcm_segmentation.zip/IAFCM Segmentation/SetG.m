function SetG(G,C,indexD)

HPath=pwd;
lh=length(HPath);
HPath(lh+1:lh+13)='\Dapi_G_C.mat';
save(HPath,'G','C','indexD');
