function Im=ImStretch(Im,range)
%stretch the image into the range of range=[a,b]

a=range(1);
b=range(2);
minIm=min(Im(:));
maxIm=max(Im(:));
if maxIm==minIm
    Im(:)=(b-a)/2+a;
    return;
end

Im=(Im-minIm)/(maxIm-minIm)*(b-a)+a;