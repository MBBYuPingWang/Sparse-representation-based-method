function [G,beGood]=GetNewG(Yim,center,U,G,cluster_n,expo,r,ImSize)
%the the w and fw 
% time5=clock;
[W,fw]=Get_W_fw(Yim,center,U,cluster_n,expo);
% disp('w,fw');
% time6=clock;
% usedt=(time6(5)-time5(5))*60+(time6(6)-time5(6))

lG=length(G);
maxG=max(G(:));
for i=1:lG
    if W(i)==0, 
        G(i)=maxG;
%         warning('Gi is inf');
        continue;
    end
    G(i)=fw(i)/W(i); 
end

% smooth the gain field 
if r==0
    beGood=1;
    return;
end
% ImSize=ImSize
G0=zeros(ImSize);
G0(:)=G(:);
G0=ImSmooth(G0,r);
G(:)=G0(:);
clear G0;%release memery

% G=G/max(G(:))*max(Yim(:));%make the value of G between [0,2]
beGood=1;