function HG=GetHG(G,r,level)
%this function get the (H*G) where 
%
%H=  [-1  ..., -1;
%     -1  m^2, -1;
%     -1  ...  -1]/m^2;
%

if nargin<3
    level=1;
end
m=2*r+1;

Im=ImSmooth(G,r,level);
% HG=((m^2+1)*G-m^2*Im)/m^2;
HG=G-Im+ G/m^2;


