function center=LoadCenter()

HPath=pwd;
lh=length(HPath);
temp='\Center.mat';
lt=length(temp);
HPath(lh+1:lh+lt)=temp;
load(HPath,'center');
