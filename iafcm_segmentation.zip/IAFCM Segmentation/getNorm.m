function nv=getNorm(v,u,expo)
%get the norm option v
%nv=||v||^expo=<v,v>^(1/2)^expo
%when expo=2, this is the intraduction of ,v,u=<v,u>.

if  nargin<3
    expo=1;
end

if  nargin<2
    nv=(sum(v.*v))^(expo/2);
    return;
end

nv=(sum(v.*u))^(expo/2);