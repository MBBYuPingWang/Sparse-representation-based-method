function varargout = FDRParaSetting(varargin)
% FDRPARASETTING M-file for FDRParaSetting.fig
%      FDRPARASETTING, by itself, creates a new FDRPARASETTING or raises the existing
%      singleton*.
%
%      H = FDRPARASETTING returns the handle to a new FDRPARASETTING or the handle to
%      the existing singleton*.
%
%      FDRPARASETTING('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in FDRPARASETTING.M with the given input arguments.
%
%      FDRPARASETTING('Property','Value',...) creates a new FDRPARASETTING or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before FDRParaSetting_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to FDRParaSetting_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help FDRParaSetting

% Last Modified by GUIDE v2.5 16-Sep-2013 16:49:16

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @FDRParaSetting_OpeningFcn, ...
                   'gui_OutputFcn',  @FDRParaSetting_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before FDRParaSetting is made visible.
function FDRParaSetting_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to FDRParaSetting (see VARARGIN)

% Choose default command line output for FDRParaSetting
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);
setappdata(handles.dlg_FDR_Para_Setting,'criticalP',0.01);
setappdata(handles.dlg_FDR_Para_Setting,'q_FDR',0.05);
setappdata(handles.dlg_FDR_Para_Setting,'pathname','');
setappdata(handles.dlg_FDR_Para_Setting,'filename','');
setappdata(handles.dlg_FDR_Para_Setting,'beNegative',0);
setappdata(handles.dlg_FDR_Para_Setting,'bePosotive',0);
setappdata(handles.dlg_FDR_Para_Setting,'beAllSG',1);
setappdata(handles.dlg_FDR_Para_Setting,'requiredSign',0);
setappdata(handles.dlg_FDR_Para_Setting,'beIntraCN',0);
% uiwait;%block the execution and wait for the dealing with this dialog

% --- Outputs from this function are returned to the command line.
function varargout = FDRParaSetting_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% %resume the execution
% uiresume;
% Get default command line output from handles structure
varargout{1} = handles.output;



function edit_p_Callback(hObject, eventdata, handles)
%get the current value of the bar
val=str2num(get(hObject,'string'));
setappdata(handles.dlg_FDR_Para_Setting,'criticalP',val);
set(handles.slider_criticlaP,'Value',val);
maxV=get(handles.slider_criticlaP,'Max');
if maxV<val,
    set(handles.slider_criticlaP,'Max',val);
    set(handles.edit_p_max,'String',sprintf('%0.2e',val));
end
feval(@pushbutton_Process_Callback,handles.pushbutton_Process,eventdata,handles);




% --- Executes during object creation, after setting all properties.
function edit_p_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_p (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_q_Callback(hObject, eventdata, handles)
val=str2num(get(hObject,'string'));
setappdata(handles.dlg_FDR_Para_Setting,'q_FDR',val);


% --- Executes during object creation, after setting all properties.
function edit_q_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_q (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton_Process.
function pushbutton_Process_Callback(hObject, eventdata, handles)
% %resume the execution
% uiresume;
pathname=getappdata(handles.dlg_FDR_Para_Setting,'pathname');
filename=getappdata(handles.dlg_FDR_Para_Setting,'filename');
criticalP=getappdata(handles.dlg_FDR_Para_Setting,'criticalP');
q_FDR=getappdata(handles.dlg_FDR_Para_Setting,'q_FDR');
% feval(@edit_p_Callback,handles.edit_p,eventdata,handles);

if ~isempty(pathname)&&~isempty(filename)
%calculate the PVMs
% check the sign requirment for the analysis
requiredSign=getappdata(handles.dlg_FDR_Para_Setting,'requiredSign');
beIntraCN=getappdata(handles.dlg_FDR_Para_Setting,'beIntraCN');
analyzePVM(pathname,filename,criticalP,q_FDR,requiredSign,beIntraCN);
else
    disp('No file to open!');
end

% --- Executes on slider movement.
function slider_criticlaP_Callback(hObject, eventdata, handles)
val=get(hObject,'Value');
minV=get(hObject,'Min');
maxV=get(hObject,'Max');
stepV=(maxV-minV)/1000;
val=minV+floor((val-minV)/stepV)*stepV;
%set the text_display the value
set(handles.edit_p,'String',sprintf('%0.2e',val));
set(handles.slider_criticlaP,'Value',val);
setappdata(handles.dlg_FDR_Para_Setting,'criticalP',val);
feval(@edit_p_Callback,handles.edit_p,eventdata,handles);
feval(@pushbutton_Process_Callback,handles.pushbutton_Process,eventdata,handles);

% --- Executes during object creation, after setting all properties.
function slider_criticlaP_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider_criticlaP (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on button press in pushbutton_Default.
function pushbutton_Default_Callback(hObject, eventdata, handles)
defaultP=0.01;
setappdata(handles.dlg_FDR_Para_Setting,'criticalP',defaultP);
setappdata(handles.dlg_FDR_Para_Setting,'q_FDR',0.05);

set(handles.checkbox_Negative,'Value',0);
set(handles.checkbox_Posotive,'Value',0);
set(handles.checkbox_AllSign,'Value',1);
setappdata(handles.dlg_FDR_Para_Setting,'requiredSign',0);

set(handles.checkbox_IntraCN,'Value',0);
setappdata(handles.dlg_FDR_Para_Setting,'beIntraCN',0);



%set the text_display the value
set(handles.edit_p,'String',num2str(defaultP));
set(handles.slider_criticlaP,'Value',defaultP);
set(handles.slider_criticlaP,'Max',defaultP);
set(handles.edit_q,'String',num2str(0.05));
set(handles.edit_p_max,'String',num2str(defaultP));
feval(@pushbutton_Process_Callback,handles.pushbutton_Process,eventdata,handles);



function edit_p_max_Callback(hObject, eventdata, handles)
val=str2num(get(hObject,'string'));
set(handles.slider_criticlaP,'Max',val);
set(handles.slider_criticlaP,'Val',val);
set(handles.edit_p,'String',sprintf('%0.2e',val));
feval(@edit_p_Callback,handles.edit_p,eventdata,handles);


% --- Executes during object creation, after setting all properties.
function edit_p_max_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_p_max (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton_Finish.
function pushbutton_Finish_Callback(hObject, eventdata, handles)
%clear and set the axes invisible
h_dlg=findobj('Tag','dlg_main');
h_dlg_main=guihandles(h_dlg);
axes(h_dlg_main.Figure_Main_Axes1);%set the current axes
cla;
set(h_dlg_main.Figure_Main_Axes1,'Visible','off');
set(h_dlg_main.Listbox_main1,'Visible','off'); 
getappdata(handles.dlg_FDR_Para_Setting,'h_Venn_legend');
if ~isempty(h_dlg_main.legend)
    set(h_dlg_main.legend, 'Visible','off');
end
close(handles.dlg_FDR_Para_Setting);
close(100);


% --- Executes on button press in checkbox_Negative.
function checkbox_Negative_Callback(hObject, eventdata, handles)
value=getappdata(handles.dlg_FDR_Para_Setting,'beNegative');
if value==0
    setappdata(handles.dlg_FDR_Para_Setting,'beNegative',1);
    setappdata(handles.dlg_FDR_Para_Setting,'bePosotive',0);
    setappdata(handles.dlg_FDR_Para_Setting,'beAllSG',0);
    
    set(handles.checkbox_Negative,'Value',1);
    set(handles.checkbox_Posotive,'Value',0);
    set(handles.checkbox_AllSign,'Value',0);
    setappdata(handles.dlg_FDR_Para_Setting,'requiredSign',-1);
else
    setappdata(handles.dlg_FDR_Para_Setting,'beAllSG',0);
    feval(@checkbox_AllSign_Callback,handles.checkbox_AllSign,eventdata,handles);
    return;
end
feval(@pushbutton_Process_Callback,handles.pushbutton_Process,eventdata,handles);

% --- Executes on button press in checkbox_Posotive.
function checkbox_Posotive_Callback(hObject, eventdata, handles)
value=getappdata(handles.dlg_FDR_Para_Setting,'bePosotive');
if value==0
    setappdata(handles.dlg_FDR_Para_Setting,'beNegative',0);
    setappdata(handles.dlg_FDR_Para_Setting,'bePosotive',1);
    setappdata(handles.dlg_FDR_Para_Setting,'beAllSG',0);
set(handles.checkbox_Negative,'Value',0);
set(handles.checkbox_Posotive,'Value',1);
set(handles.checkbox_AllSign,'Value',0);
setappdata(handles.dlg_FDR_Para_Setting,'requiredSign',1);
else
    setappdata(handles.dlg_FDR_Para_Setting,'beAllSG',0);
    feval(@checkbox_AllSign_Callback,handles.checkbox_AllSign,eventdata,handles);
    return;
end
feval(@pushbutton_Process_Callback,handles.pushbutton_Process,eventdata,handles);


% --- Executes on button press in checkbox_AllSign.
function checkbox_AllSign_Callback(hObject, eventdata, handles)
value=getappdata(handles.dlg_FDR_Para_Setting,'beAllSG');
if value==0
    setappdata(handles.dlg_FDR_Para_Setting,'beNegative',0);
    setappdata(handles.dlg_FDR_Para_Setting,'bePosotive',0);
    setappdata(handles.dlg_FDR_Para_Setting,'beAllSG',1);
set(handles.checkbox_Negative,'Value',0);
set(handles.checkbox_Posotive,'Value',0);
set(handles.checkbox_AllSign,'Value',1);
setappdata(handles.dlg_FDR_Para_Setting,'requiredSign',0);
else
    set(handles.checkbox_Posotive,'Value',0);
    setappdata(handles.dlg_FDR_Para_Setting,'requiredSign',0);
end
feval(@pushbutton_Process_Callback,handles.pushbutton_Process,eventdata,handles);


% --- Executes on button press in checkbox_IntraCN.
function checkbox_IntraCN_Callback(hObject, eventdata, handles)
value=getappdata(handles.dlg_FDR_Para_Setting,'beIntraCN');
if value==0
    setappdata(handles.dlg_FDR_Para_Setting,'beIntraCN',1);
    set(handles.checkbox_IntraCN,'Value',1);
else
    setappdata(handles.dlg_FDR_Para_Setting,'beIntraCN',0);
    set(handles.checkbox_IntraCN,'Value',0);
end
feval(@pushbutton_Process_Callback,handles.pushbutton_Process,eventdata,handles);
