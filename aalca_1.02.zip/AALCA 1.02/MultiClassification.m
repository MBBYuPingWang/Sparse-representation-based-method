function MultiClassification(PVM_pathname,PVM_filename)
%this function uses multivariate classification to test the effectiveness
%of the selected CNs
clc
%get the PVM, which is cell array saving the comparision results of nClass 
savePath=fullfile(PVM_pathname,PVM_filename);
load(savePath,'PVM','filename');
CFM_filename=filename;
nClass=length(PVM);%number of classes

indexGood=getGoodIndex(PVM);
nGoodFeature=zeros(1,nClass);
for i=1:nClass
    nGoodFeature(i)=indexGood(i).nGoodFeature;
end
nGoodFeature=min(nGoodFeature);


%prepare A for the LOO classification
A=cell(nClass,2);
nContrast=0;
for i=1:nClass
    %open the data file
    savePath=fullfile(PVM_pathname,CFM_filename{i});
    load(savePath,'interCorr','nSubj');
    tempCorr=zeros(nSubj,nGoodFeature);
    for j=1:nSubj,
        temp=interCorr(:,:,j);
        tempCorr(j,:)=temp(indexGood(i).Index(1:nGoodFeature,3));
    end
    tempCorr1=tempCorr;
    for k=i+1:nClass
            %open the data file
        savePath=fullfile(PVM_pathname,CFM_filename{k});
        load(savePath,'interCorr','nSubj');
        tempCorr=zeros(nSubj,nGoodFeature);
        for j=1:nSubj,
             temp=interCorr(:,:,j);
            tempCorr(j,:)=temp(indexGood(i).Index(1:nGoodFeature,3));
        end
        nContrast=nContrast+1;
        A{nContrast,1}=tempCorr1;
        A{nContrast,2}=tempCorr;
    end
end

nTest=100;
nTest=min([nGoodFeature,nTest]);
cr=zeros(nTest,nContrast);
for i=1:nContrast
    for nAc=1:nTest
        [cr(nAc,i),classLabel,nSubj]=LOO_Euclidean(A(i,:),nAc);
    end
end

colors={'r','g','b'};
figure(98);
cla;
for i=1:nContrast
    figure(98);
    plot(cr(:,i),colors{i});
    hold on;
end
legend(PVM(1).ContrastName,PVM(2).ContrastName,PVM(3).ContrastName);
title('Multivariate classification results');
xlabel('Number of selected CNs');
ylabel('Classification ratio(%)');

%find the highest classification ratios and the corresponding CNs
maxCR=struct('Index',cell(nContrast,1),'nCNs',zeros(1),'maxCR',zeros(1),'maxP',zeros(1),'ContrastName',cell(nContrast,1));

for i=1:nContrast
    tempCR=cr(:,i);
    nCNs=find(tempCR==max(tempCR));
    maxCR(i).nCNs=nCNs(1);
    maxCR(i).maxCR=max(tempCR);
    maxCR(i).Index=indexGood(i).Index(1:maxCR(i).nCNs,:);
    maxCR(i).maxP=PVM(i).PVM(maxCR(i).Index(maxCR(i).nCNs,3));    
    maxCR(i).ContrastName=indexGood(i).ContrastName;
end
for i=1:nContrast
    disp(maxCR(i));
end

%save the results
savePath=fullfile(PVM_pathname,PVM_filename);
lsavePath=length(savePath);
savePath=savePath(1:lsavePath-4);
savePath=strcat(savePath,'_maxCR.mat')
save(savePath,'maxCR','indexGood');




