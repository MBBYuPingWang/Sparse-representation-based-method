function calculateCFM(dataPath,winL,stepL,TR)
%this function calculate the CFM for each subject given by the data 
% (.mat file, saved in dataPath). and save the results to the savePath

if nargin<2,
    winL=inf;
end
if nargin<3,
    stepL=winL;
end
if nargin<4,
    TR=2;
end
%%%%%%for test%%%%%%%%%%%
% clc
% dataPath='E:\research NIH 2\work data\A.mat';
% winL=60;
% stepL=60;
%%%%%%%%%%%%%%%%%%%%%%%%%

%loading the data and the related inf
load(dataPath,'data','nSubj','beSmoothed','beFiltered','dimensions','maskIndex','sClusters','nClusters','beDataInf','timePoints');
%change the parameter to the unite of timepoints
winL=winL/TR;
stepL=stepL/TR;
if winL>timePoints,
    winL=timePoints;
    stepL=winL;    
    disp('The time sequence is shorter than the window length!');
end

%get the number of windows for the process
nWin=floor((timePoints-winL)/stepL)+1;
winIndex=zeros(winL*nSubj,nWin);

for i=1:nWin
    %get the index for each time window
    startPoint=(i-1)*stepL+1;
    endPoint=startPoint+winL-1;
    temp=0;
    for j=1:nSubj
        winIndex(temp+1:temp+winL,i)=[[startPoint:endPoint]+(j-1)*timePoints]';
        temp=temp+winL;
    end           
end

% nClusters=5;

for i=1:nWin
    interCorr=calculateCFM0(data(winIndex(:,i),:),nSubj,sClusters,nClusters,winL);
    %save results
    [fileName,pathName]=getParentDir(dataPath);
    savePath=strcat(pathName,'\',fileName,sprintf('_%d_CFM_%d_%d_%d.mat',i,nClusters,winL,stepL));
    save(savePath,'sClusters','nClusters','nSubj','interCorr');
    disp('-----------------------------------------');
    fprintf('Results were save to:%s\n',savePath);
    disp('-----------------------------------------');
end

function interCorr=calculateCFM0(data,nSubj,sClusters,nClusters,timePoints)

%size of the data
[rd,cd]=size(data);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%sort the data according to the indexs given by sClusters
sIndex=zeros(cd,1);
totalNum=0;
Nums=zeros(nClusters,1);
 for j=1:nClusters
     tempNum=sClusters(j).Num;
     sIndex(totalNum+1:totalNum+tempNum)=sClusters(j).Index1;%using the index for this current data, not original data
     totalNum=totalNum+tempNum;
     Nums(j)=tempNum;
 end
 sIndex=sIndex(1:totalNum);
data=data(:,sIndex);

%get the dimension of the resized data
[rd,cd]=size(data);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%calculate the inter&intra CN
interCorr=zeros(nClusters,nClusters,nSubj);
for i=1:nSubj%one subject at a time
    clc;
    totalNum=0; 
    for j=1:nClusters %get all the cross correlations for the current cluster
        disp(sprintf('Processing the %dth subject, region %d...',i,j));
        sIndex=totalNum+1:totalNum+Nums(j);%columns for the current region
        lsIndex=totalNum+1:cd;%columns for all the rest regions
        totalNum=totalNum+Nums(j);
          temp=(getCrossCorrMatrix(data((i-1)*timePoints+1:i*timePoints,sIndex),data((i-1)*timePoints+1:i*timePoints,lsIndex)));
%           tt=temp(:,1237)
          temp(:)=FisherR2Z(double(temp(:)));%Fisher r to z transfermation
%         sizeTemp=size(temp)
%           tt=temp(:,1237)
        for k=j:nClusters 
            %get the index for the kth cluster
            tempIndex=sum(Nums(j:k))-Nums(k)+1:sum(Nums(j:k));
            temp1=temp(:,tempIndex);
            %correct the intra-network connectivity by set the diagnal
            %elements to 0
            if j==k
                %remove the 1s on the diagram
                sizeTemp1=size(temp1,1);
                interCorr(j,k,i)=(sum(temp1(:))-sum(diag(temp1)))/(sizeTemp1*(sizeTemp1-1));
            else
                interCorr(j,k,i)=mean(temp1(:));
            end
                
            interCorr(k,j,i)=interCorr(j,k,i);
        end%for k=j:nClusters
        clear temp;
        clear temp1;
    end %for j=1:nClusters
end%for i=1:nSubj
%  interCorr= FisherR2Z(interCorr);
    x=1:nClusters;
    y=1:nClusters;
    z=interCorr(:,:,i);
    figure;
    mesh(x,y,z);
