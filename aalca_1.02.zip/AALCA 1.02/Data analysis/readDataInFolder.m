function readDataInFolder(fileDir,maskDir,saveDir)
%read all the data in a folder according to the mask, and save it to a .mat file;
% if there are child folders in the selected
%folder, each of them will be read as data from seperate subject
% 
 
clc 
%show and get the handle of the parameter seting dialog 
h_para=readDataFolder();
h_readDataFoler=guihandles(h_para);

beFilter=getappdata(h_readDataFoler.dlg_readDataFolder,'beFilter');
beFiltered=0;
if beFilter~=0,
%set the filter band limit
filterLow=getappdata(h_readDataFoler.dlg_readDataFolder,'filterLow')
filterHigh=getappdata(h_readDataFoler.dlg_readDataFolder,'filterHigh')
TR=getappdata(h_readDataFoler.dlg_readDataFolder,'TR')
end

beSmoothed=0;
beSmooth=getappdata(h_readDataFoler.dlg_readDataFolder,'beSmooth');
if beSmooth~=0,
%set the filter band limit
fwhm=getappdata(h_readDataFoler.dlg_readDataFolder,'fwhm')
VoxelSize=getappdata(h_readDataFoler.dlg_readDataFolder,'VoxelSize')
end

beDataInf=getappdata(h_readDataFoler.dlg_readDataFolder,'beDataInf');
if beDataInf~=0,
%set the filter band limit
timePoints=getappdata(h_readDataFoler.dlg_readDataFolder,'TimePoints')
timePoints2Skip=getappdata(h_readDataFoler.dlg_readDataFolder,'DiscardPoints')
if timePoints==0,
    disp('Reading all the timePoints!');
end
end

%close the dialog
% h=findobj('Tag','dlg_readDataFolder') 
close(h_para); 
 
 
% %set the data path
% fileDir='E:\research NIH 2\data07_30_2013\A';
% saveDir='E:\research NIH 2\work data\A.data';
% 
% %load the AAL brain region mask
% maskDir='E:\research NIH 2\work data\currentMask.mat';
load(maskDir,'sClusters','nClusters','maskIndex','lMask','dimensions');

%get the folders, each folder is supposed to save the data of one subject
[folderName,nFolder]=getChildFolders(fileDir);
% nFolder=1;
nSubj=nFolder;%each folder is supposed to save the data of one subject

if beDataInf==0||timePoints==0,
%get the number of files in each folder, each folder is supposed to have
%same number of files
fileTag=fullfile(fileDir,folderName{1},'*.img');
[fileName,nFile]=getAllFilesInFolder(fileTag);
timePoints=nFile;%the total number of time points
timePoints2Skip=0;%the number of time points to skip
disp('Reading all the timePoints!');
end
timePoints=timePoints-timePoints2Skip;

%create a temperal image matrix
% tempIm=zeros(61,73,61,'int32');%data at one time point for each subject 
tempIm=zeros(dimensions(1),dimensions(2),dimensions(3),'int32');

data=zeros(nSubj*(timePoints),length(maskIndex),'int8');
% size(data)
%process data of each subject
disp('------------------------------------------');
fprintf('Reading folder: %s. Please wait...\n',fileDir);
disp('------------------------------------------');

for i=1:nFolder
    disp(sprintf('Reading the %dth folder...',i));
    %get the .img file in the folder
    fileTag=fullfile(fileDir,folderName{i},'*.img');
    [fileName,nFile]=getAllFilesInFolder(fileTag);
    %test the completeness  of the data of this subject
    if timePoints~=nFile-timePoints2Skip,
        error('The number of samples for this subject is not correct!');
    end
    %read files one by one
    for j=timePoints2Skip+1:nFile
        close all;
        filePath=fullfile(fileDir,folderName{i},fileName{j}); 
        fid=fopen(filePath);
        tempIm(:)=fread(fid,inf,'int32');
%         figure(100);
%         imageNumber=38;
%         imagesc(tempIm(:,:,imageNumber));
        if beSmooth~=0
%             disp(sprintf('Smoothing data of the %dth subject ...',i));
            tempIm=GaussionSmooth(tempIm,floor(fwhm/VoxelSize));%using two points fwhm Gaussion kernel to smooth the data 
            beSmoothed=1;
%         figure(101);
%         imagesc(tempIm(:,:,imageNumber));
        end
        tempIm=ImStretch(tempIm,[-127,127]);%stretch the data into the range of -127~127
%         figure(102);
%         imagesc(tempIm(:,:,imageNumber));
        warning ('off','all');
        data((i-1)*timePoints+j-timePoints2Skip,:)=int8(tempIm(maskIndex));
        
        fclose(fid); %close the file 
    end        
end

sizeData=size(data)

%%%%%%%%%%band pass filter the data%%%%%%%%%% 

if beFilter==0,%don't filter the data
    %save the results
    save(saveDir,'data','nSubj','beSmoothed','beFiltered','dimensions','maskIndex','sClusters','nClusters','beDataInf','timePoints');
    disp('------------------------------------------');
    disp(strcat('The data were saved to:',saveDir,'!'));
    return;
end

beFiltered=1;
fs=1/TR;
wp=[filterLow, filterHigh];
ws=[filterLow*0.95, filterHigh*1.01];
rp=1;%signal loss in pass band
rs=20;%signal attenuation in the stopband.  
bePlotFilter=0;

disp('------------------------------------------');
for i=1:nSubj
    disp(sprintf('Filtering the %dth subject...',i));
    y=data((i-1)*timePoints+1:i*timePoints,:);
%     figure(99);
%     plot(y(:,1000),'r');
%     hold on;
    
    [y]=FilterBP(fs,wp,ws,rp,rs,double(y),bePlotFilter); 
%     figure(99);
%     plot(y(:,1000),'g');
%     hold on;
    
    y=ImStretch(double(y),[-127,127]);%stretch the data into the range of -127~127
%     figure(99);
%     plot(y(:,1000),'b');
%     hold off;
    
    data((i-1)*timePoints+1:i*timePoints,:)=int8(y);
    clear y;
end

%save the results
save(saveDir,'data','nSubj','beSmoothed','beFiltered','dimensions','maskIndex','sClusters','nClusters','beDataInf','timePoints');
disp('------------------------------------------');
disp(strcat('The data were saved to:',saveDir,'!'));



