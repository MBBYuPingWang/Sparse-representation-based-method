function readData2()
clc
close all;
addPath;
fclose all;
% path=strcat(pwd,'\data_case');
% load(path,'data_case','rd','cd','badi');

%load the mask
path='E:\research NIH\data1\mask.mat';
load(path,'maskIndex','lMask','dimensions');

%%%%% reading the sibling control data of 31 %%%%%%
% timePoints=155;
% n=31*timePoints;%31 sibling controls with 155 times for each person
% data_sibling= zeros(n,lMask,'uint8');
% size(data_sibling)
% subjId=zeros(1,31);
% nSubj=0;
% for i=1:31
%     disp(i)
%     nSubj=nSubj+1;
%     subjId(nSubj)=i;
%     %read all the .img file for this subject
%     for j=6:160
%         if i<10
%             if j<10
%                 str=sprintf('E:\\research NIH\\data1\\b0%d\\resting_fMRI\\wrab0%d_fmri_00%d.img',i,i,j);
%             elseif j>99
%                 str=sprintf('E:\\research NIH\\data1\\b0%d\\resting_fMRI\\wrab0%d_fmri_%d.img',i,i,j);
%                 else
%                 str=sprintf('E:\\research NIH\\data1\\b0%d\\resting_fMRI\\wrab0%d_fmri_0%d.img',i,i,j);
%             end
%         else
%             if j<10
%                  str=sprintf('E:\\research NIH\\data1\\b%d\\resting_fMRI\\wrab%d_fmri_00%d.img',i,i,j);
%             elseif j>99
%                  str=sprintf('E:\\research NIH\\data1\\b%d\\resting_fMRI\\wrab%d_fmri_%d.img',i,i,j);
%             else                    
%                  str=sprintf('E:\\research NIH\\data1\\b%d\\resting_fMRI\\wrab%d_fmri_0%d.img',i,i,j);               
%             end
%         end%if i<10
%             fid=fopen(str);
%             if fid==-1%file not exist 
%                 i=i
%                 disp('This subject is not exist!');
%                 nSubj=nSubj-1;%delete this subject
%                 break;
%             else                
%                 tempData=fread(fid,inf,'int16');
%                 tempData=ImStretch(tempData,[0,255]);
%                 data_sibling((nSubj-1)*155+j-5,:)=uint8(tempData(maskIndex));
%                  fclose(fid); %close the file 
%                  clear tempData;
%             end        
%     end%for j=6:160
%     
%     if j<160 &&  j>6 %the number images of this subject is not enough
%        nSubj=nSubj-1;%delete this subject
%     end
% end 
% 
% data_sibling=data_sibling(1:nSubj*155,:);
% subjId=subjId(1:nSubj);
% [rd,cd]=size(data_sibling)
% nSubj=nSubj
% %save the data
% path='E:\research NIH\data1\data_sibling.mat';
% save(path,'data_sibling','rd','cd','subjId','nSubj');

% %filter the data
% path='E:\research NIH\data1\data_sibling.mat';
% load(path,'data_sibling','rd','cd','subjId','nSubj');
% 
% fs=0.5;
% wp=.08;
% ws=.1; 
% rp=3;%signal loss in pass band
% rs=30;%signal attenuation in the stopband.  
% 
% for i=1:nSubj
%     i=i
%     for j=1:cd
%         y=data_sibling((i-1)*155+1:i*155,j);
% %         figure(99);
% %         plot(y)
% %         hold on;
%         [y]=FilterLP(fs,wp,ws,rp,rs,double(y));
%         data_sibling((i-1)*155+1:i*155,j)=uint8(y);
% %         plot(uint8(y),'red');
% %         hold off; 
%     end
% end
% 
% path='E:\research NIH\data1\data_sibling_smooth.mat';
% save(path,'data_sibling','rd','cd','subjId','nSubj');


%%%%% reading the case data of 32 %%%%%%
% timePoints=155;
% n=32*timePoints;%32 cases with 155 times for each person
% data_case= zeros(n,lMask,'uint8');
% size(data_case)
% subjId=zeros(1,32);
% nSubj=0;
% for i=1:32
%     disp(i)
%     nSubj=nSubj+1;
%     subjId(nSubj)=i;
%     %read all the .img file for this subject
%     for j=6:160
%         if i<10
%             if j<10
%                 str=sprintf('E:\\research NIH\\data1\\s0%d\\resting_fMRI\\wras0%d_fmri_00%d.img',i,i,j)
%             elseif j>99
%                 str=sprintf('E:\\research NIH\\data1\\s0%d\\resting_fMRI\\wras0%d_fmri_%d.img',i,i,j)
%                 else
%                 str=sprintf('E:\\research NIH\\data1\\s0%d\\resting_fMRI\\wras0%d_fmri_0%d.img',i,i,j)
%             end
%         else
%             if j<10
%                  str=sprintf('E:\\research NIH\\data1\\s%d\\resting_fMRI\\wras%d_fmri_00%d.img',i,i,j)
%             elseif j>99
%                  str=sprintf('E:\\research NIH\\data1\\s%d\\resting_fMRI\\wras%d_fmri_%d.img',i,i,j)
%                 else                    
%                 str=sprintf('E:\\research NIH\\data1\\s%d\\resting_fMRI\\wras%d_fmri_0%d.img',i,i,j)              
%             end
%         end%if i<10
%             fid=fopen(str);
%             if fid==-1%file not exist 
%                 i=i
%                 disp('This subject is not exist!');
%                 nSubj=nSubj-1;%delete this subject
%                 break;
%             else                
%                 tempData=fread(fid,inf,'int16');
%                 tempData=ImStretch(tempData,[0,255]);
%                 data_case((nSubj-1)*155+j-5,:)=uint8(tempData(maskIndex));
%                  fclose(fid); %close the file 
%                  clear tempData;
%             end        
%     end%for j=6:160
%     
%     if j<160 &&  j>6 %the number images of this subject is not enough
%        nSubj=nSubj-1;%delete this subject
%     end
% end 
% 
% data_case=data_case(1:nSubj*155,:);
% subjId=subjId(1:nSubj);
% [rd,cd]=size(data_case)
% nSubj=nSubj
% %save the data
% path='E:\research NIH\data1\data_case.mat';
% save(path,'data_case','rd','cd','subjId','nSubj');

% % %filter the data
% path='E:\research NIH\data1\data_case.mat';
% load(path,'data_case','rd','cd','subjId','nSubj');
% 
% fs=0.5;
% wp=.08;
% ws=.1; 
% rp=3;%signal loss in pass band
% rs=30;%signal attenuation in the stopband.  
% 
% for i=1:nSubj
%     i=i
%     for j=1:cd
%         y=data_case((i-1)*155+1:i*155,j);
% %         figure(99);
% %         plot(y)
% %         hold on;
%         [y]=FilterLP(fs,wp,ws,rp,rs,double(y));
%         data_case((i-1)*155+1:i*155,j)=uint8(y);
% %         plot(uint8(y),'red');
% %         hold off;
%     end
% end
% 
% path='E:\research NIH\data1\data_case_smooth.mat';
% save(path,'data_case','rd','cd','subjId','nSubj');



%%%%% reading the normal control data 44 %%%%%%
% timePoints=155;
% n=44*timePoints;%43 normal controls with 155 times for each person
% data_control= zeros(n,lMask,'uint8');
% size(data_control)
% subjId=zeros(1,44);
% nSubj=0;
% for i=3:54
%     disp(i)
%     nSubj=nSubj+1;
%     subjId(nSubj)=i;
%     %read all the .img file for this subject
%     for j=6:160
%         if i<10
%             if j<10
%                 str=sprintf('E:\\research NIH\\data1\\c0%d\\resting_fMRI\\wrac0%d_fmri_00%d.img',i,i,j);
%             elseif j>99
%                 str=sprintf('E:\\research NIH\\data1\\c0%d\\resting_fMRI\\wrac0%d_fmri_%d.img',i,i,j);
%                 else
%                 str=sprintf('E:\\research NIH\\data1\\c0%d\\resting_fMRI\\wrac0%d_fmri_0%d.img',i,i,j);
%             end
%         else
%             if j<10
%                  str=sprintf('E:\\research NIH\\data1\\c%d\\resting_fMRI\\wrac%d_fmri_00%d.img',i,i,j);
%             elseif j>99
%                  str=sprintf('E:\\research NIH\\data1\\c%d\\resting_fMRI\\wrac%d_fmri_%d.img',i,i,j);
%                 else                    
%                 str=sprintf('E:\\research NIH\\data1\\c%d\\resting_fMRI\\wrac%d_fmri_0%d.img',i,i,j);               
%             end
%         end%if i<10
%             fid=fopen(str);
%             if fid==-1%file not exist 
%                 i=i
%                 disp('This subject is not exist!');
%                 nSubj=nSubj-1;%delete this subject
%                 break;
%             else                
%                 tempData=fread(fid,inf,'int16');
%                 tempData=ImStretch(tempData,[0,255]);
%                 data_control((nSubj-1)*155+j-5,:)=uint8(tempData(maskIndex));
%                  fclose(fid); %close the file 
%                  clear tempData;
%             end        
%     end%for j=6:160
%     
%     if j<160 &&  j>6 %the number images of this subject is not enough
%        nSubj=nSubj-1;%delete this subject
%     end
% end 
% 
% data_control=data_control(1:nSubj*155,:);
% subjId=subjId(1:nSubj);
% [rd,cd]=size(data_control)
% nSubj=nSubj
% %save the data
% path='E:\research NIH\data1\data_control.mat';
% save(path,'data_control','rd','cd','subjId','nSubj');

% %filter the data
% path='E:\research NIH\data1\data_control.mat';
% load(path,'data_control','rd','cd','subjId','nSubj');


% fs=0.5;
% wp=.08;
% ws=.1; 
% rp=3;%signal loss in pass band
% rs=30;%signal attenuation in the stopband.  
% 
% for i=1:nSubj
%     i=i
%     for j=1:cd
%         y=data_control((i-1)*155+1:i*155,j);
% %         figure(99);
% %         plot(y)
% %         hold on;
%         [y]=FilterLP(fs,wp,ws,rp,rs,double(y));
%         data_control((i-1)*155+1:i*155,j)=uint8(y);
% %         plot(uint8(y),'red');
% %         hold off;
%     end
% end
% 
% path='E:\research NIH\data1\data_control_smooth.mat';
% save(path,'data_control','rd','cd','subjId','nSubj');


%%%%%generate mask for each slice
% path='E:\research NIH\data1\brainmask\rmaskwholeHEAD.img';
% fid=fopen(path,'r');
% % data=zeros(61,73,61);% 61��73��61
% data=fread(fid,inf);
% %save data
% path='E:\research NIH\data1\mask.mat';
% maskIndex=find(data>0);
% lMask=length(maskIndex)
% dimensions=[61 73 61];
% save(path,'maskIndex','lMask','dimensions');



