function [AALRegions,broadmanAreas]=compareAAL2Broadman(maskDir,AALRegions,broadmanAreas,beB2A,resolution)
%this function converted the specified AAL brain regions to the
%corresponding broadman areas, or wise verse.


if nargin<5
    resolution=0;
end
if nargin<4
    beB2A=1;
end

clc
disp('----------------------------------------');
disp('Converting, please wait...');

%get the fullMask AAL regions
aalMaskPath=strcat(maskDir,'\mask_aal.img');
fid=fopen(aalMaskPath,'r');
aalMask=fread(fid,'uint8');
fclose(fid);

%get the fullMask Broadman regions
broadmanMaskPath=strcat(maskDir,'\mask_broadman.img');
fid=fopen(broadmanMaskPath,'r');
broadmanMask=fread(fid,'uint8');
fclose(fid);

if length(aalMask)~=length(broadmanMask)
    error('The two mask is not in same size!');
end

if beB2A%convert broadman areas to AAL brain regions
    [AALRegions]=convertB2A(broadmanAreas,aalMask,broadmanMask,resolution);
else%convert AAL to broadman
    [broadmanAreas]=convertB2A(AALRegions,broadmanMask,aalMask,resolution);
end
disp('                        ');
disp('----------------------------------------');
disp('Converting is done!');
disp('----------------------------------------');

function [AALs]=convertB2A(broadmanAreas,aalMask,broadmanMask,resolution)
lB=length(broadmanAreas);%the number of broadman areas
%find the corresponding index of the specified broadmanAreas
nIndexB=0;
indexB=length(aalMask);
for i=1:lB
    tempIndexB=find(broadmanMask==broadmanAreas(i));
    ltempIndexB=length(tempIndexB);
    indexB(nIndexB+1:nIndexB+ltempIndexB)=tempIndexB;
    nIndexB=nIndexB+ltempIndexB;
end
    indexAALs=aalMask(indexB);%the corresponding regions' index
    AALs=unique(indexAALs);%the corresponding regions
    AALs(AALs==0)=[];%remove the zeros/non AAL brain regions
    
    histAALs=myhistc(indexAALs,AALs);%voxel number in the selected regions
    histTotalAALs=myhistc(aalMask,AALs);%voxel number in the the whole AAL regions
    Res=histAALs./histTotalAALs*100;
%     disp([AALs,Res,histAALs/100,histTotalAALs/100]);
    AALs(Res<=resolution)=[];
    %make sure AALs is a row vector
    if size(AALs,1)>size(AALs,2),
        AALs=AALs';
    end
    
 function hB=myhistc(A,B)
     lB=length(B);
     hB=zeros(lB,1);
     lA=length(A);
     for i=1:lB
         for j=1:lA
             if B(i)==A(j)
                 hB(i)=hB(i)+1;
             end
         end
     end
         
     
    
   