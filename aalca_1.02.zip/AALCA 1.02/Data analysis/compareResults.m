function compareResults(resultsPath,P_value,AALRegions,beRegion,beIntraRegion)
% This function view the brain regions specified in the multivariate
% classification results
%beRegion specifies if only compare the region or the feature (1feature has
%two regions)
%beIntraRegion specifies if only compare the CNs between the given AALRegions

clc
if nargin<5,
    beIntraRegion=1;
end
if nargin<4,
    beRegion=1; 
end
  

load(resultsPath,'maxCR','indexGood'); 
indexGood=indexGood
P_value=P_value
AALRegions=AALRegions

if beRegion==1%compare the regions 
    [outcomes]=compareRegions(indexGood,P_value,AALRegions,beIntraRegion);
else
    [outcomes]=compareVariables(indexGood,P_value,AALRegions);
end

[OCr,OCc]=size(outcomes);
outcomes{1,OCc+1}='#Region';
for i=2:OCr-1
    outcomes{i,OCc+1}=AALRegions(i-1);
end
outcomes=outcomes

AALRegions(length(AALRegions)+1)=0;
for i=1:length(AALRegions)
    disp('*************************************');
    if AALRegions(i)==0
        disp('For all the regions');
    else
        disp(sprintf('For region %d',AALRegions(i)));
    end
    
    for j=1:length(indexGood)
    disp('----------------------------------');
    disp(strcat(indexGood(j).ContrastName,':'));
    disp(outcomes{i+1,j});
    end
    disp('----------------------------------');
    disp(strcat('C1&C2',':'));
    disp(outcomes{i+1,j+1});
    disp('          ');
end



function [outcomes]=compareRegions(indexGood,P_value,AALRegions,beIntraRegion)
if nargin<4,
    beIntraRegion=1;
end
%the number of AALs to compare
lAALs=length(AALRegions);
%the number of constrast in our results
nContrasts=length(indexGood);
outcomes=cell(lAALs+2,nContrasts+1);

for i=1:nContrasts
    outcomes{1,i}=indexGood(i).ContrastName;
end
outcomes{1,i+1}='C1&C2';


for i=1:nContrasts
    %determine the number of varaibles to be used 
    P=indexGood(i).Index(:,4);
    tempIndex=[indexGood(i).Index(P<P_value,1),indexGood(i).Index(P<P_value,2)];
    ltempIndex=length(tempIndex);
    for k=1:lAALs%process one region by one region
        nTemp=0;
        for j=1:ltempIndex           
            if beIntraRegion==1,%only get those not within the given AAL regions
%                 disp('Only wanna the CNs between those given AAL regions!')
                if myhistc(AALRegions,tempIndex(j,1))==0|| myhistc(AALRegions,tempIndex(j,2))==0
%                     disp('Not within those given AAL regions!');
                    continue;
                end
            end
                
            if tempIndex(j,1)==AALRegions(k)||tempIndex(j,2)==AALRegions(k)
               nTemp=nTemp+1;
               outcomes{k+1,i}(nTemp,1)=nTemp; 
               outcomes{k+1,i}(nTemp,2:3)=tempIndex(j,:); 
            end

        end%for j=1:ltempIndex   
    end%for k=1:lAALs%
end%for i=1:nContrasts


for i=2:lAALs+1,
    outcomes{i,nContrasts+1}=findRowCross(outcomes{i,1},outcomes{i,2},2:3);
    
    for j=1:nContrasts+1
        outcomes{lAALs+2,j}=uniqueRow([outcomes{i,j};outcomes{lAALs+2,j}],(2:3));
    end
end
    for j=1:nContrasts+1
        outcomes{lAALs+2,j}(:,1)=1:size(outcomes{lAALs+2,j},1);
    end

       


function compareVariables(indexGood,P_value,AALRegions)