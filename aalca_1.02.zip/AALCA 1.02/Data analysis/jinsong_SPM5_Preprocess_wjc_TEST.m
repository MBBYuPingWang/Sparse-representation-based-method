% The standard procedures for the preprocessing of fMRI data%%%%%
% Written By Kun Wang, National Laboratory of Pattern Recognition,CAS%%%%%%%%%%%
%%%% kwang@nlpr.ia.ac.cn%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Edited By Jinsong Tang for SPM5 13627311963
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all;

dir_Group1='H:\wjc_converted\foranalysisi_files\wjc_fmri\3d_fmri\'; %% the directory of the data
nslices=24; % The number of slices
TR=2; %% Repetition time
FWHM=[6]; %% the FWHM of the Gaussion kernel for smooth " paul use 8 for fmri data.

cd H:\wjc_converted\foranalysisi_files\wjc_fmri\3d_fmri\;
subj_Group=dir('*.*');            % sub-dirrectory. ie k1, k2,k3

for subj_number=3:size(subj_Group,1)

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%%%%%%%Slice Timing%%%%%%%%
 Temp_dir=strcat(dir_Group1,subj_Group(subj_number).name,'\resting_fMRI\');
funcfile=dir(fullfile(Temp_dir,'*.nii'));
T=size(funcfile,1);
for Tp=1:T
    P(Tp,1:size(Temp_dir,2)+size(funcfile(Tp).name,2))=strcat(Temp_dir,funcfile(Tp).name);
end
if round(nslices/2)==nslices/2
   sliceorder=[1:2:nslices-1 2:2:nslices];
   refslice=nslices-1;
else
    sliceorder=[1:2:nslices 2:2:nslices-1];
   refslice=nslices;
end
TA=TR-TR/(nslices-1);
timing(2) = TR - TA;
timing(1) = TA / (nslices -1);
spm_slice_timing(P, sliceorder, refslice, timing)
clear P;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%Realign the Imgs%%%%%%%%%%%%%%
funcfile=dir(fullfile(Temp_dir,'a*.nii'));
for Tp=1:T
    P(Tp,1:size(Temp_dir,2)+size(funcfile(Tp).name,2))=strcat(Temp_dir,funcfile(Tp).name);
end
FlagsC = struct('quality',0.9,'fwhm',5,'rtm',0);  %   'quality',?
%def_flags = struct('quality',1,'fwhm',5,'sep',4,'interp',2,'wrap',[0 0
%0],'rtm',0,'PW','','graphics',1,'lkp',1:6);

spm_realign(P,FlagsC)
FlagsR = struct('interp',4,'wrap',[0 0 0],'mask',1,'which',2,'mean',1);
   % def_flags = struct('interp',1,'mask',1,'mean',1,'which',2,'wrap',[0 0 0]');
    
spm_reslice(P,FlagsR);
clear P;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%Normalize the Imgs%%%%%%%%%%%%%%
funcfile=dir(fullfile(Temp_dir,'ra*.nii'));
for Tp=1:T
    P(Tp,1:size(Temp_dir,2)+size(funcfile(Tp).name,2))=strcat(Temp_dir,funcfile(Tp).name);
end
Template='D:\program_files\spm5\templates\EPI.nii';
filename=dir(fullfile(Temp_dir,'mean*.nii'));
subj.P = strcat(Temp_dir,filename.name);
subj.matname = [spm_str_manip(subj.P,'sd') '_sn.mat']; % 's remove remove trailing suffix - only if it is either '.img', 
                                                       %    '.hdr', '.mat' or  '.nii'
subj.objmask = '';
subj.PP =P;
defs.estimate.weight='';
defs.estimate.wtsrc  = 0;
defs.estimate.cutoff = 25;
defs.estimate.reg    = 1;
defs.estimate.nits   = 16;
defs.write.preserve = 0;                                   % 0 not modulated
defs.write.bb       = [-90 -126 -72; 90 90 108];
defs.write.vox      = [3 3 3];
defs.write.interp   = 1;
defs.write.wrap     = [0 0 0];
spm_normalise(Template, subj.P, subj.matname,...
			defs.estimate.weight,subj.objmask,defs.estimate);
spm_write_sn(subj.PP,subj.matname,defs.write);
clear P;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%Smooth the Imgs%%%%%%%%%%%%%%
Temp_dir=strcat(dir_Group1,subj_Group(subj_number).name,'\resting_fMRI\');
funcfile=dir(fullfile(Temp_dir,'wra*.nii'));
T=size(funcfile,1);
for Tp=1:T
    P(1:size(Temp_dir,2)+size(funcfile(Tp).name,2))=strcat(Temp_dir,funcfile(Tp).name);
    Q(1:size(Temp_dir,2)+size(funcfile(Tp).name,2)+1)=strcat(Temp_dir,'s',funcfile(Tp).name);
    spm_smooth(P,Q,FWHM)
end
clear P;
clear Q;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%%%%%%%%%% remove whole brain and head motion %%%%%%%%%%
% fprintf('removing the head motion and whole brain mean.\n');
% Temp_dir=strcat(dir_Group1,subj_Group(subj_number).name);
% funcfile=dir(fullfile(Temp_dir,'swraf*.img'));
% T=size(funcfile,1);
% cd(Temp_dir);
% 
%     func_name = strcat(Temp_dir,'\swraf*.hdr');
%     motionfile_name = strcat(Temp_dir,'\rp_*.txt');
%     file = dir(motionfile_name);
%     motionfile_name = strcat(Temp_dir,'\',file.name);
%     [TC_mean] = f_RemoveHeadMotion_Wholemean_2(Temp_dir,func_name,motionfile_name,T);
%     
%     cd(Temp_dir);
%     target_directory=strcat(target_parent_directory,subj);
%     mkdir(target_parent_directory,subj);
%     
%     movefile('rhmw_*.*',target_directory);
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
end

fprintf('Over!');