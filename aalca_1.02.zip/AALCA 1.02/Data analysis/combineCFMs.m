function combineCFMs(pathname,filename)
%this function combines the files specified by the pathname+filename
%filename is a cell matrix
%in each file, there should be variables with same names, and the one in
%three dimension of double is the one to be combined

clc
%get the number of files to be combined
nFile=length(filename);
%
filePath=strcat(pathname,filename{1});    
varsAll=load(filePath);
[data0,dataIndex]=locateData(varsAll,3);

[d1,d2,d3]=size(data0);
[indexTriu,lindexTriu]=getTriuIndex(d1,d2);%get the upper triangular index of 
data=zeros(lindexTriu,nFile*d3);%suppose the data size is same for the nFiles
tempData=zeros(d1*d2,d3);
datac=0;
for i=1:nFile
    filePath=strcat(pathname,filename{i});
    disp(filePath);
    varsAll=load(filePath);
    [tempData0]=locateData(varsAll,3);
    [d1,d2,d3]=size(tempData0);
    tempData=reshape(tempData0,d1*d2,d3);
    data(:,datac+1:datac+d3)=tempData(indexTriu,:);
    datac=datac+d3;
end

% save the combined data
name1=filename{1};
lp=find(name1=='_');
name1=name1(1:lp(1));

name2=filename{nFile};
lp=find(name2=='_');
name2=name2(1:lp(1)-1);
savePath=strcat(pathname,sprintf('combined_%d_CFMs_',nFile),name1,name2,'.mat');

varsName=fieldnames(varsAll);
[tempData0,dataIndex]=locateData(varsAll,3);
varsAll=setfield(varsAll,varsName{dataIndex},data);
save(savePath,'varsAll');
disp(strcat('The results were save to: ',sprintf('%s',savePath)));
    
function [data,dataIndex]=locateData(varsAll,nDim)  
%
varsName=fieldnames(varsAll);
   for j=1:length(varsName)
        data=getfield(varsAll,varsName{j});
        if ndims(data)==nDim%this is the data to be used
            dataIndex=j;
            break;
        end
   end







