function testRead()
clc
close all
filePath='E:\research NIH 2\data07_30_2013\B\B01_Covremoved_detrend\00000001.img'
fid=fopen(filePath);
tempData=fread(fid,inf,'int32');
size(tempData)
Im=zeros(61,73,61);
Im(:)=tempData(:);

Im1=GaussionSmooth(Im,2);

for i=1:10:61
figure;
imagesc(Im(:,:,i));
figure;
imagesc(Im1(:,:,i));
end
