function getInterRegionConnectivity_aal()
%this function get the inter-region connncecitivity for the given
%regions by aal defined brain regions 

clc
close all; 
[pathParent,pathGrad]=addPath();

%load the brain regions located by FPC
nClusters=1000;
path=strcat(pathGrad,sprintf('\\work data\\aal_clusters_%d.mat',nClusters))
load(path,'sClusters','nClusters');

t=sClusters(1)
tt=sClusters(2)
ttt=sClusters(12)
totalSubj=0; 
%  
%%% process the control data set
dataType='control'; 
[savePath,nSubj]=getInterCNs(pathGrad,sClusters,nClusters,dataType)
% 
% %%% process the case data set 
% dataType='case';
% [savePath,nSubj]=getInterCNs(pathGrad,sClusters,nClusters,dataType)
% 
%  
% %%% process the sibling control data set
% dataType='sibling';
% [savePath,nSubj]=getInterCNs(pathGrad,sClusters,nClusters,dataType)


totalSubj=32+31+44;
% % % %save connectivity results
TotalInterCorr=struct('interCorr',zeros(nClusters,nClusters,totalSubj),'nSubj',zeros(3,1),'nClusters',zeros(1));
dataType={'case','sibling','control'};
totalSubj=0;
TotalInterCorr_Cell=cell(3,1);
for i=1:length(dataType)
    savePath=strcat(pathGrad,sprintf('\\work data\\data_%s_inter_CN_%d.mat',dataType{i},nClusters));
    load(savePath,'sClusters','nClusters','nSubj','interCorr');
    TotalInterCorr.interCorr(:,:,totalSubj+1:totalSubj+nSubj)=double(interCorr);
    nClusters=double(nClusters);
    temp=reshape(interCorr,nClusters^2,nSubj);
    TotalInterCorr_Cell{i}=temp';
    TotalInterCorr.nSubj(i)=double(nSubj);
    TotalInterCorr.nClusters=nClusters;
    totalSubj=totalSubj+nSubj;
    clear interCorr;
end
% %chage the connectivities into Z-score
% TotalInterCorr.interCorr(:)=zscore(TotalInterCorr.interCorr(:));
%save the total results 
savePath=strcat(pathGrad,sprintf('\\work data\\data_Total_inter_CN_%d.mat',nClusters))
save(savePath,'sClusters','TotalInterCorr','dataType','nClusters','TotalInterCorr_Cell');

end


function [savePath,nSubj,interCorr]=getInterCNs(pathGrad,sClusters,nClusters,dataType)
timePoints=155;
% %process the 
% path=strcat(pathGrad,'\work data\data_',dataType,'_smooth.mat');
% load(path,'data','rd','cd','subjId','nSubj'); 

% % process the aal brain regions masked data
path=strcat(pathGrad,'\work data\data_',dataType,'_aal_sbf.mat')
load(path,'data','rd','cd','subjId','nSubj');

size(data) 


% 
% % process the aal brain regions masked data
% path=strcat(pathGrad,'\work data\data_',dataType,'_aal_lowpass.mat')
% load(path,'data','rd','cd','subjId','nSubj');

%sort the data according to the indexs given by sClusters
sIndex=zeros(cd,1);
totalNum=0;
Nums=zeros(nClusters,1);
 for j=1:nClusters
     tempNum=sClusters(j).Num;
     sIndex(totalNum+1:totalNum+tempNum)=sClusters(j).Index;
     totalNum=totalNum+tempNum;
     Nums(j)=tempNum;
 end
 sIndex=sIndex(1:totalNum);
data=data(:,sIndex);
%get the dimension of the resized data
[rd,cd]=size(data);


interCorr=zeros(nClusters,nClusters,nSubj);
for i=1:nSubj%one subject at a time
    clc;
    totalNum=0; 
    for j=1:nClusters %get all the cross correlations for the current cluster
        disp([i,j])
        sIndex=totalNum+1:totalNum+Nums(j);
        lsIndex=totalNum+1:cd;  
        totalNum=totalNum+Nums(j);
%         temp=abs(getCrossCorrMatrix(data((i-1)*timePoints+1:i*timePoints,sIndex),data((i-1)*timePoints+1:i*timePoints,lsIndex)));
          temp=(getCrossCorrMatrix(data((i-1)*timePoints+1:i*timePoints,sIndex),data((i-1)*timePoints+1:i*timePoints,lsIndex)));
%           tt=temp(:,1237)
          temp=FisherR2Z(temp);%Fisher r to z transfermation
%         sizeTemp=size(temp)
%           tt=temp(:,1237)
        for k=j:nClusters 
            %get the index for the kth cluster
            tempIndex=sum(Nums(j:k))-Nums(k)+1:sum(Nums(j:k));
            temp1=temp(:,tempIndex);
            %correct the intra-network connectivity by set the diagnal
            %elements to 0
            if j==k
                %remove the 1s on the diagram
                sizeTemp1=size(temp1,1);
                interCorr(j,k,i)=(sum(temp1(:))-sizeTemp1)/(sizeTemp1*(sizeTemp1-1));
            else
                interCorr(j,k,i)=mean(temp1(:));
            end
                
            interCorr(k,j,i)=interCorr(j,k,i);
        end%for k=j:nClusters
        clear temp;
        clear temp1;
    end %for j=1:nClusters
end%for i=1:nSubj
        
    x=1:nClusters;
    y=1:nClusters;
    z=interCorr(:,:,i);
    figure;
    mesh(x,y,z);

%save results
savePath=strcat(pathGrad,sprintf('\\work data\\data_%s_inter_CN_%d.mat',dataType,nClusters));
save(savePath,'sClusters','nClusters','nSubj','interCorr');
clear data;
clear subjId
clear interCorr;   
    
end%function [savePath,nSubj,interCorr]=getInterCNs(pathGrad,sClusters,nClusters,dataType)


