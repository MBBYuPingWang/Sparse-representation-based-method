function analyzePVM(pathname,filename,criticalP,q_FDR,requiredSign,beIntraCN)
%this funciton compares the PVM specified by the pathname and filename
%figure 100 is used to display the brain regions selected

if nargin<5,
    requiredSign=0;
end
if nargin<6,
    beIntraCN=0;
end
clc

savePath=fullfile(pathname,filename);
load(savePath,'PVM','filename');

% criticalP=4.8e-3;
%%%%%correcte criticalP use FDR%%%%%%%%%%%%
% q_FDR=0.01;
pThresh1=FDRCorrection(PVM,criticalP,q_FDR);
criticalP=min(pThresh1)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
indexGood=getGoodIndex(PVM,criticalP,requiredSign,beIntraCN);


nPVM=length(PVM);%the number of PVMs
%show the selected features for each PVM
disp('------------------------------------');
disp('Here are the good variables selected:');
disp('------------------------------------');
for i=1:nPVM
    disp(strcat(indexGood(i).ContrastName,':'));
    disp(indexGood(i));
end

%show the results with venn plot
drawVenn(indexGood);
disp('------------------------------------');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%55
function drawVenn(indexGood)
%draw the Venn diagram on main dialog
h_dlg=findobj('Tag','dlg_main');
h_dlg_main=guihandles(h_dlg);
set(h_dlg_main.Figure_Main_Axes1,'Visible','on');
set(h_dlg_main.Listbox_main1,'Visible','on'); 
nPVM=length(indexGood);

if nPVM==1,
    A=[indexGood.nGoodFeature,0];
    IA=0;   
    axes(h_dlg_main.Figure_Main_Axes1);%set the current axes
    cla;
    venn(A,IA);
    legend(indexGood(1).ContrastName);
    str{1}=sprintf('C%d: %s: (%d, %2.2f%%)',1,indexGood(1).ContrastName,A(1),indexGood(1).goodPercentage);
    set(h_dlg_main.Listbox_main1,'String',str);    
    return;
    
elseif nPVM==3
    drawVenn_3(h_dlg_main,indexGood);
    return;
else
    msgbox('Please select three groups for comparison!');
end

% if nPVM>3    
% %    %each time select 3 to plot the venn diagram
% %    [vennIndex,nTotallPlots]=getCombines([1:nPVM],3)
% %    str=cell(nTotallPlots);
% %    for i=1:nTotallPlots      
% %        tempVennIndex=vennIndex{i};
% %       str{i}=strcat(indexGood(tempVennIndex(1)),'&&',
% %       drawVennMoreThan3(nTotallPlots,i,indexGood(vennIndex{i}));
% %    end   
% end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function drawVennMoreThan3(nTotallPlots,currentPlot,indexGood)
%indexGood contains all the PVMs, while w
    nPVM=length(indexGood);
    temp1=indexGood(1).Index(:,3);
    temp2=indexGood(2).Index(:,3);
    temp3=indexGood(3).Index(:,3);
    [str12,ls12]=findCross(temp1,temp2);
    [str13,ls13]=findCross(temp1,temp3);
    [str23,ls23]=findCross(temp2,temp3);
    [str123,ls123]=findCross(str13,str23);
    A=[length(temp1),length(temp2),length(temp3)];
    IA=[ls12,ls13,ls23,ls123];
    figure(96);%set the current axes
    subplot(ceil(nTotallPlots/3),3,currentPlot);
    venn(A,IA);    
    legend(indexGood(1).ContrastName,indexGood(2).ContrastName,indexGood(3).ContrastName);
    

    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function drawVenn_3(h_dlg_main,indexGood)
%%%%%%%%process the features (CNs)%%%%%%
    temp1=indexGood(1).Index(:,3);
    temp2=indexGood(2).Index(:,3);
    temp3=indexGood(3).Index(:,3);
    [str12,ls12]=findCross(temp1,temp2);
    [str13,ls13]=findCross(temp1,temp3);
    [str23,ls23]=findCross(temp2,temp3);
    [str123,ls123]=findCross(str13,str23);
    A=[length(temp1),length(temp2),length(temp3)];
    maxFeatureN=max(A);%the max number of selected features
    IA=[ls12,ls13,ls23,ls123];
    axes(h_dlg_main.Figure_Main_Axes1);%set the current axes
    cla;
    venn(A,IA);    
    warning('off','all');
    legend(indexGood(1).ContrastName,indexGood(2).ContrastName,indexGood(3).ContrastName);
    warning('on','all');
    %disp the results in the edit text
    %disp the results in the edit text
    str{1}='-----Selected CNs------';
    for i=1:length(A)
        str{i+1}=sprintf('C%d: %s: (%d, %2.2f%%)',i,indexGood(i).ContrastName,A(i),indexGood(i).goodPercentage);
    end
    nTotalFeature=indexGood(i).nTotalFeature
    str{5}=sprintf('C1&C2: (%d, %2.2f%%)',IA(1),IA(1)/nTotalFeature*100);
    str{6}=sprintf('C1&C3: (%d, %2.2f%%)',IA(2),IA(2)/nTotalFeature*100);   
    str{7}=sprintf('C2&C3: (%d, %2.2f%%)',IA(3),IA(3)/nTotalFeature*100);
    str{8}=sprintf('C1&C2&C3: (%d, %2.2f%%)',IA(4),IA(4)/nTotalFeature*100); 
    str{9}='                                  ';
    str{10}='-----CN related brain regions------';
%     set(h_dlg_main.Listbox_main1,'String',str);
    
    %%%%%%%%process the CN related brain regions %%%%%%
    temp1=unique([indexGood(1).Index(:,1);indexGood(1).Index(:,2)]);
    temp2=unique([indexGood(2).Index(:,1);indexGood(2).Index(:,2)]);
    temp3=unique([indexGood(3).Index(:,1);indexGood(3).Index(:,2)]);
    [str12,ls12]=findCross(temp1,temp2);
    [str13,ls13]=findCross(temp1,temp3);
    [str23,ls23]=findCross(temp2,temp3);
    [str123,ls123]=findCross(str13,str23);
    A=[length(temp1),length(temp2),length(temp3)];
    IA=[ls12,ls13,ls23,ls123];
    figure(100);
     cla;
    venn(A,IA); 
    title('Brain regions associated with the selected CNs ');
    warning('off','all');
    legend(indexGood(1).ContrastName,indexGood(2).ContrastName,indexGood(3).ContrastName);
    warning('on','all');
    %disp the results in the edit text
    nRegions=indexGood(1).sizePVM(1);

    for i=1:length(A)
        str{i+10}=sprintf('C%d: %s: (%d, %2.2f%%)',i,indexGood(i).ContrastName,A(i),A(i)/nRegions*100);
    end
    str{14}=sprintf('C1&C2: (%d, %2.2f%%)',IA(1),IA(1)/nRegions*100);
    str{15}=sprintf('C1&C3: (%d, %2.2f%%)',IA(2),IA(2)/nRegions*100);   
    str{16}=sprintf('C2&C3: (%d, %2.2f%%)',IA(3),IA(3)/nRegions*100);
    str{17}=sprintf('C1&C2&C3: (%d, %2.2f%%)',IA(4),IA(4)/nRegions*100);  
    set(h_dlg_main.Listbox_main1,'String',str);
    
    %draw the hist plot for the regeions 
    features=zeros(maxFeatureN*2,3);    
    for i=1:3
        temp=([indexGood(i).Index(:,1);indexGood(i).Index(:,2)]);
        ltemp=length(temp);
        features(1:ltemp,i)=temp;
    end
    figure(101);
    cla;
    featHist=hist(features(:),[1:nRegions+1]);
    cla;
    hist(features,[1:nRegions+1]);
    featHist(1)=[];%remove the first one which is the number of zeros
    maxFH=max(featHist(:));
    legend(indexGood(1).ContrastName,indexGood(2).ContrastName,indexGood(3).ContrastName);
    title('Number of connectivities selected in each region');
     axis([2,nRegions+1,0,maxFH]);
    
    %draw the hist plot for only two contrasts with the overlap drawed
    %seperatedly 
    C2draw=[1,2];
    index1=indexGood(C2draw(1)).Index;
    index2=indexGood(C2draw(2)).Index;
    [temp,temp1,index3from1,index3from2]=findCross(index1(:,3),index2(:,3));
    index12=index1(index3from1,:);
    index1(index3from1,:)=[];
    index2(index3from2,:)=[];
    
    lindex=zeros(1,3);
    li(1)=size(index1,1)*2;
    li(2)=size(index2,1)*2;
    li(3)=size(index12,1)*2
    maxFeatureN=max(li);    
    features=zeros(maxFeatureN*2,3);    
    features(1:li(1),1)=[index1(:,1);index1(:,2)];
    features(1:li(2),2)=[index2(:,1);index2(:,2)];
    features(1:li(3),3)=[index12(:,1);index12(:,2)];
    
    figure(102);
    cla;
    featHist=hist(features(:),[1:nRegions+1]);
    cla;
    hist(features,[1:nRegions+1],'color',['r','g','b']);
    featHist(1)=[];%remove the first one which is the number of zeros
    maxFH=max(featHist(:));
    legend(indexGood(C2draw(1)).ContrastName,indexGood(C2draw(2)).ContrastName,strcat(indexGood(C2draw(1)).ContrastName, ' & ',indexGood(C2draw(2)).ContrastName));
    title('Number of connectivities selected in each region');
    axis([2,nRegions+1,0,maxFH]);
  
    %draw the hist plot for only two contrasts with the overlap drawed
    %seperatedly 
    C2draw=[1,2];
    index1=indexGood(C2draw(1)).Index;
    index2=indexGood(C2draw(2)).Index;
    [temp,temp1,index3from1,index3from2]=findCross(index1(:,3),index2(:,3));
    index12=index1(index3from1,:);
    index1(index3from1,:)=[];
    index2(index3from2,:)=[];
    
    figure(103);
    cla   
    for i=1:length(index2)
        line([index2(i,2),index2(i,1)],[0,70],'Color','g');
    end 
    for i=1:length(index12)
        line([index12(i,2),index12(i,1)],[0,70],'Color','m');
    end
    for i=1:length(index1)
        line([index1(i,1),index1(i,2)],[0,70],'Color','b');
    end
    legend(indexGood(C2draw(1)).ContrastName,indexGood(C2draw(2)).ContrastName,strcat(indexGood(C2draw(1)).ContrastName, ' & ',indexGood(C2draw(2)).ContrastName));
    title('CNs distribution map'); 


    
    
    
    
    
    


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function p1=FDRCorrection(PVM,p,q)
% This function correct the p value thresholds to have less than q false
% detective ratio 
%p is the origional p value threshold

if nargin<3,
q=0.01;
end

nTest=length(PVM);%the number of PVMs
p1=zeros(nTest,1);
for i=1:nTest
%     disp(strcat('________',PVM(i).ContrastName,'____________'));
    tempOnes=ones(size(PVM(i).PVM,1))+100;
    tempOnes=triu(tempOnes,1);
    tempGoodPVM=PVM(i).PVM+tempOnes;
    tempGoodPVM(tempGoodPVM>90)=[];%remove the up right corner
    tempGoodPVM=tempGoodPVM(tempGoodPVM<p);  
   [p1(i)] = getFDR(tempGoodPVM,q);
end







