function indexGood=getGoodIndex(PVM,criticalP,requiredSign,beIntraCN)
% This function get the selected significant variables/CNs from the PVMs
%the index are sorted according to the decreasing significance
%requiredSign specify select the increased or decreased variable that
%<criticalP
%beIntraCN specifies if selecting the within region CN features
%
if nargin<4,
    beIntraCN=0;
end
if nargin<3,
    requiredSign=0;
end
if nargin<2,
    criticalP=0.1;
end

nPVM=length(PVM);%the number of PVMs
[PVMr,PVMc]=size(PVM(1).PVM);
indexGood=struct('Index',cell(nPVM,1),'criticalP',zeros(1),'ContrastName',cell(nPVM,1),'nGoodFeature',zeros(1),'goodPercentage',zeros(1),'nTotalFeature',zeros(1),'sizePVM',zeros(1,2));
for i=1:nPVM   
    tempPVM=tril(PVM(i).PVM,0);%lower corner with diagonal = PVM; right up cornre=2
    %detect the sign requirement
    if requiredSign==-1,%only analyze the negative part
        tempIndex=find(PVM(i).PVM_sg>0);%remove those posotive ones
        tempPVM(tempIndex)=2;
        tttNeg=length(tempIndex)
    elseif requiredSign==1,%only analyze the posotive part
        tempIndex=find(PVM(i).PVM_sg<0);%remove those negative ones
        tempPVM(tempIndex)=2;
        tttPos=length(tempIndex)
    end
       
    n_tempPVM=size(tempPVM,1);%the number of columns  
    triuTempPVM=triu(tempPVM+2,1);
    tempPVM=tempPVM+triuTempPVM;%set the up corner of the tempPVM bigger than 1 to remove them    
    
    if beIntraCN==1%only process the ones on the diagonal
         trilTempPVM=tril(tempPVM+2,-1);
         tempPVM=tempPVM+trilTempPVM;%set the low left corner of the tempPVM bigger than 1 to remove them    
    end
    
    indexGood(i).sizePVM=[PVMr,PVMc];
    

    %sort the index in ascend order 
    [tempx,tempy]=find(tempPVM<criticalP);
    ltempx=length(tempx);
    tempP=zeros(ltempx,1);
    for j=1:ltempx,
        tempP(j)=tempPVM(tempx(j),tempy(j));
    end
    [tempP,tempIndex]=sort(tempP,'ascend');
    indexGood(i).Index(:,1)=tempx(tempIndex);
    indexGood(i).Index(:,2)=tempy(tempIndex);
    
%     [indexGood(i).Index(:,1),indexGood(i).Index(:,2)]= find(tempPVM<criticalP);
    indexGood(i).Index(:,3)=(indexGood(i).Index(:,2)-1)*n_tempPVM+indexGood(i).Index(:,1);
    indexGood(i).Index(:,4)=tempP;
    
    indexGood(i).criticalP=criticalP;
    indexGood(i).ContrastName=PVM(i).ContrastName;
    indexGood(i).nGoodFeature=size(indexGood(i).Index,1);    

    indexGood(i).nTotalFeature=n_tempPVM*(n_tempPVM+1)/2;
    indexGood(i).goodPercentage=indexGood(i).nGoodFeature/indexGood(i).nTotalFeature*100;
    
end
