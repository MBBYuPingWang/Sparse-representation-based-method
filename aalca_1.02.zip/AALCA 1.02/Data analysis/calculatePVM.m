function PVM=calculatePVM(pathname,filename)
%this function first read data from the files specified by the filename, in
%the direction of pathname, each file should be one data group, in 3
%dimesion, in the size of nClusters*nClusters*nSubj,
%then it calculate the paire-wised comparision PVM (P-value map).

% close all;

nGroup=length(filename);
if nGroup<2
    disp('There should be at least 2 groups to compare!');
    PVM=[];
    return;
end

data=cell(nGroup,1);
groupName=cell(nGroup,1);
%read the data, data{i} is a row matrix, each row represent the data from
%one subject
for i=1:nGroup
    fullPath=fullfile(pathname,filename{i});
    load(fullPath,'sClusters','nClusters','nSubj','interCorr');
    tempData=reshape(interCorr,double(nClusters)^2,nSubj);
    data{i}=tempData';
    clear tempData;    
    p1=find(filename{i}=='_');
    p1=p1(1);
    groupName{i}(1:nSubj)={filename{i}(1:p1-1)};
end

PVM=struct('PVM',zeros(nClusters,nClusters),'PVM_sg',zeros(nClusters,nClusters),'ContrastName',cell(nGroup*(nGroup-1)/2,1));
nPVM=0;
for  i=1:nGroup
     for j=i+1:nGroup
         nPVM=nPVM+1
         [PVM(nPVM).PVM, PVM(nPVM).PVM_sg]=getPVMfor2(nClusters,{data{i},data{j}},{groupName{i},groupName{j}});
         PVM(nPVM).ContrastName=sprintf('%s vs. %s',groupName{i}{1},groupName{j}{1});
     end
end
   
PVM=PVM(1:nPVM);
for i=1:nPVM
figure; 
imagesc(PVM(i).PVM);
colorbar;
title(PVM(i).ContrastName);
end

%save the PVM
savePath='';
for i=1:nGroup
    savePath=strcat(savePath,groupName{i}{1},'_');
end
savePath=strcat('PVM_',savePath(1:length(savePath)-1),'.mat');
savePath=fullfile(pathname,savePath);
save(savePath,'PVM','filename');
disp('----------------------------------');
disp('The data were saved to:');
disp(savePath);
disp('----------------------------------');


 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
function [PVM,PVM_sg]=getPVMfor2(nClusters,data,groupName)

    PVM=zeros(nClusters,nClusters);
    PVM_sg=zeros(nClusters,nClusters);%save the sign of the PVM
    totalV=double(nClusters)^2;
    for i=1:totalV
        d1=data{1}(:,i);
        d2=data{2}(:,i);
        if length(groupName{1})==length(groupName{2})
            PVM(i)=myAnova1([d1,d2],[groupName{1};groupName{2}],'off');
        else
            PVM(i)=myAnova1([d1;d2],[groupName{1},groupName{2}],'off');
        end
            PVM_sg(i)=sign(mean(d1)-mean(d2));       
        
        if mod(i,300)==0
        figure(200);
        plot(data{1}(:,i),'b'); 
        hold on;
        plot(data{2}(:,i),'r');        
        hold off;
        end
        
    end

