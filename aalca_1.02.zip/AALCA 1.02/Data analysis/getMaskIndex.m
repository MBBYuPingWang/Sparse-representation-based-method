function getMaskIndex(pathname,filename,savePath)
%This function read the .img file of the brain masks (e.g. AAL whole brain
%mask), and save the mask index in .mat file

clc

%show and get the handle of the parameter seting dialog 
h_para=DataDimension();
h_DataDimension=guihandles(h_para);

dimensions(1)=getappdata(h_DataDimension.dlg_DataDimension,'d_x');
dimensions(2)=getappdata(h_DataDimension.dlg_DataDimension,'d_y');
dimensions(3)=getappdata(h_DataDimension.dlg_DataDimension,'d_z');

%close the dialog
close(h_para); 
%create a temperal image matrix
% tempIm=zeros(61,73,61,'int32');%data at one time point for each subject 
tempIm=zeros(dimensions(1),dimensions(2),dimensions(3),'int32');

%get the path for the mask .img file
filePath=fullfile(pathname,filename)
fid=fopen(filePath);
tempIm(:)=fread(fid,inf,'int8');%read data
fclose(fid); %close the file 

%get the mask index for all AAL brain region
maskIndex=find(tempIm>0);
lMask=length(maskIndex);
disp('----------------------------------');
fprintf('This mask has %d voxels; Index in the rang of [%d,%d]!\n',lMask,min(maskIndex),max(maskIndex));

%get the mask index for ech AAL brain regiond
nClusters=max(tempIm(:));
sClusters=struct('Index',cell(nClusters,1),'Index1',cell(nClusters,1),'Num',zeros(1,1));
lMask=0;
for i=1:nClusters,
    tempIndex=find(tempIm(:)==i);
    sClusters(i).Index=tempIndex;
    sClusters(i).Num=length(tempIndex);  
    maskIndex(lMask+1:lMask+sClusters(i).Num)=sClusters(i).Index;
    sClusters(i).Index1=lMask+1:lMask+sClusters(i).Num;
    lMask=lMask+sClusters(i).Num;
end

%save the mask for current work
readMe='Index of sClusters(i) save the index from original data for the ith cluster; Index1 is the index from the current data';
savePath0=strcat(savePath,'currentMask.mat');
save(savePath0,'dimensions','lMask','maskIndex','nClusters','sClusters','readMe');

%save the mask for the user
[fileName]=getParentDir(filePath);
savePath=strcat(savePath,fileName,sprintf('_%d.mat',nClusters));
save(savePath,'dimensions','lMask','maskIndex','nClusters','sClusters','readMe');
fprintf('The mask has been save in: %s.\n',savePath);



str={'dimensions','lMask','maskIndex','nClusters','sClusters','readMe'};
fprintf('The saved variables include:\n\n');
for i=1:length(str)
    disp(str(i));
end
disp('----------------------------------');

% %%%%%%%%%disp and test the mask %%%%%%%%%%%%
% max(tempIm(:))
% min(tempIm(:))

% for i=1:floor(dimensions(3)/10):dimensions(3)
%     figure(99);
%     imagesc(tempIm(:,:,i));
% end
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    
