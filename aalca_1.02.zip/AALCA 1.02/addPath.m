function [pathParent,pathGrad]=addPath()
%pathParent,pathGrad are the one level and two level upper root path
disp('The following pathes are added:');
%add the dirs undersame root dir

%get the parent path
path0=pwd;
p1=find(path0=='\');
p1=p1(length(p1));
path0=path0(1:p1-1);
pathParent=path0;

%the folders in the current path
path0=pwd;
str='\Data preprocess';
path=strcat(path0,str);
addpath(path);
disp(path);

str='\Data analysis';
path=strcat(path0,str);
addpath(path);
disp(path);

%add the dirs under one hihger level root dir
path0=pathParent;
p1=find(path0=='\');
p1=p1(length(p1));
pathGrad=path0(1:p1-1);

str='\work data';
path=strcat(path0,str);
addpath(path);
disp(path);

str='\support programs\wfu_pickatlas';
path=strcat(path0,str);
addpath(path);
disp(path);

% str='\support programs\spm8';
% path=strcat(path0,str);
% addpath(path);
% disp(path);

str='\support programs\spm5';
path=strcat(path0,str);
addpath(path);
disp(path);

str='\support programs\REST_V1.8_121225';
path=strcat(path0,str);
addpath(path);
disp(path);

str='\support programs\xjview8';
path=strcat(path0,str);
addpath(path);
disp(path);


% str='\programs for fMRI\xjview8';
% path=strcat(path0,str);
% addpath(path);
% disp(path);
% 
% str='\programs for fMRI\spm8';
% path=strcat(path0,str);
% addpath(path);
% disp(path);
% 
% str='\programs for fMRI\wfu_pickatlas';
% path=strcat(path0,str);
% addpath(path);
% disp(path);
% 
% str='\programs for fMRI\conn';
% path=strcat(path0,str);
% addpath(path);
% disp(path);
% 
% str='\programs for fMRI\REST_V1.8_121225';
% path=strcat(path0,str);
% addpath(path);
% disp(path);



