function varargout = AALCA(varargin)
% _______________________________________________________
% Copyright(c) 2013
% Unit on Statistical Genomics, National Institute of Mental Health, NIH,
% Bethesda, 20852, USA
% Written by Hongbao Cao
% http://hongbaocao.weebly.com/software-for-download.html
% Mail to Authors:  caohon2010@gmail.com, hongbao.cao@nih.gov
% _______________________________________________________
% Last Modified by GUIDE v2.5 1-Dec-2013 20:44:31

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @AALCA_OpeningFcn, ...
                   'gui_OutputFcn',  @AALCA_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before AALCA is made visible.
function AALCA_OpeningFcn(hObject, eventdata, handles, varargin)

% Choose default command line output for AALCA
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

%add some work path 
currentDir=pwd;
[parentDir,grandDir]=addPath();

%save the directions
setappdata(handles.dlg_main,'currentDir',currentDir);
setappdata(handles.dlg_main,'parentDir',parentDir);
setappdata(handles.dlg_main,'grandDir',grandDir);


% --- Outputs from this function are returned to the command line.
function varargout = AALCA_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --------------------------------------------------------------------
function Menu_ReadData_Callback(hObject, eventdata, handles)
% hObject    handle to Menu_ReadData (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function Menu_ReadFolder_Callback(hObject, eventdata, handles)
%get the folder of the data
parentDir=getappdata(handles.dlg_main,'parentDir');
fileDir=uigetdir(strcat(parentDir,'\work data\'),'Current work directory')%the directory for the data
%get the name of the folder
p1=find(fileDir=='\');
p1=p1(length(p1));
folderName=fileDir(p1+1:length(fileDir)); 

%the directory for the mask 
parentDir=getappdata(handles.dlg_main,'parentDir');
maskDir=fullfile(parentDir,'work data\currentMask.mat');
%the directory for saving the data
saveDir=strcat(parentDir,'\work data\',folderName,'.mat')

readDataInFolder(fileDir,maskDir,saveDir);


% --------------------------------------------------------------------
function Menu_CFM_Callback(hObject, eventdata, handles)
% hObject    handle to Menu_CFM (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function Menu_getCFM4MultiGroups_Callback(hObject, eventdata, handles)
%get a single data file (in .mat) to calculate CFM
parentDir=getappdata(handles.dlg_main,'parentDir');
    [filename, pathname, filterindex] = uigetfile(  { '*.mat','MAT-files (*.mat)';}, ...
        'Pick a file',...
        'MultiSelect', 'on',...
    strcat(parentDir,'\work data\'));
%set the parameter for the calculation of CFM
h_para=CFM_Parameter_Setting();
h_CFM_Parameter_Setting=guihandles(h_para);
winL=getappdata(h_CFM_Parameter_Setting.dlg_CFM_Parameter_Setting,'winL');
stepL=getappdata(h_CFM_Parameter_Setting.dlg_CFM_Parameter_Setting,'stepL');
TR=getappdata(h_CFM_Parameter_Setting.dlg_CFM_Parameter_Setting,'TR');
close(h_para);

if~iscell(filename)%only one file is selected
    dataPath=fullfile(pathname,filename);
    calculateCFM(dataPath,winL,stepL,TR);
    return;
end

%calculate the CFM one by one
nFile=length(filename);
for i=1:nFile
    dataPath=fullfile(pathname,filename{i});
    calculateCFM(dataPath,winL,stepL,TR);
end
    

% --------------------------------------------------------------------
function Menu_PVM_Callback(hObject, eventdata, handles)



% --------------------------------------------------------------------
function Menu_GetPVM_Callback(hObject, eventdata, handles)
%Read data from *_CFM.mat files, and get the P-value map for comparison
%them: two group (1comparision) for one PVM, three group (4 comparison) for 4 PVMs. 
parentDir=getappdata(handles.dlg_main,'parentDir');
    [filename, pathname, filterindex] = uigetfile(  { '*.mat','MAT-files (*.mat)';}, ...
        'Pick a file',...
        'MultiSelect', 'on',...
    strcat(parentDir,'\work data\'));
%calculate the PVMs
calculatePVM(pathname,filename);


% --------------------------------------------------------------------
function Menu_PVM_Comparison_Callback(hObject, eventdata, handles)
%this compares the selected PVMs
parentDir=getappdata(handles.dlg_main,'parentDir');
    [filename, pathname, filterindex] = uigetfile(  { '*.mat','MAT-files (*.mat)';}, ...
        'Pick a file',...
    strcat(parentDir,'\work data\'));

%show and get the handle of the parameter seting dialog 
h_para=FDRParaSetting();
h_FDRParaSetting=guihandles(h_para);
setappdata(h_FDRParaSetting.dlg_FDR_Para_Setting,'pathname',pathname);
setappdata(h_FDRParaSetting.dlg_FDR_Para_Setting,'filename',filename);



% --------------------------------------------------------------------
function Menu_getMask_Callback(hObject, eventdata, handles)
%this selects a brain mask used for the following data processing
parentDir=getappdata(handles.dlg_main,'parentDir');
    [filename, pathname, filterindex] = uigetfile(  { '*.img','Disc Image File (*.img)';}, ...
        'Pick a file',...
    strcat(parentDir,'\work data\'));
%get the maks file
savePath=strcat(parentDir,'\work data\');
getMaskIndex(pathname,filename,savePath);



function edit_main1_Callback(hObject, eventdata, handles)
% hObject    handle to edit_main1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_main1 as text
%        str2double(get(hObject,'String')) returns contents of edit_main1 as a double


% --- Executes during object creation, after setting all properties.
function edit_main1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_main1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in Listbox_main1.
function Listbox_main1_Callback(hObject, eventdata, handles)
% hObject    handle to Listbox_main1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns Listbox_main1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from Listbox_main1


% --- Executes during object creation, after setting all properties.
function Listbox_main1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Listbox_main1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function Figure_Main_Axes1_ButtonDownFcn(hObject, eventdata, handles)


function dlg_main_ResizeFcn(hObject, eventdata, handles)
% keep the size of figures in the dlg change accordingly
dlg_main_Pos=get(handles.dlg_main,'Position');
% set(handles.Figure_Main_Axes1,'Visible','on');
sides=2;
Figure_Main_Axes1_pos=[0,0,dlg_main_Pos(3)/3*2-sides,dlg_main_Pos(4)-sides];
set(handles.Figure_Main_Axes1,'Position',Figure_Main_Axes1_pos);

% set(handles.Listbox_main1,'Visible','on');
Listbox_main1_pos=[dlg_main_Pos(3)/3*2,0,dlg_main_Pos(3)/3-sides,dlg_main_Pos(4)-sides];
set(handles.Listbox_main1,'Position',Listbox_main1_pos);

% Figure_Main_Axes1_pos=get(handles.Figure_Main_Axes1,'Position')


% --------------------------------------------------------------------
function Menu_Tools_Callback(hObject, eventdata, handles)
% hObject    handle to Menu_Tools (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function Menu_Data_Clustering_Callback(hObject, eventdata, handles)
% hObject    handle to Menu_Data_Clustering (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function Menu_FPC_Callback(hObject, eventdata, handles)
%%To cluster the columns of an input matrix A into N equal-sized clusters
%according to the intra-cluster Pearson correlations.
parentDir=getappdata(handles.dlg_main,'parentDir');
Dlg_Para_FPC({parentDir});


% --------------------------------------------------------------------
function Menu_combine_CFMs_Callback(hObject, eventdata, handles)
%for one data set there maybe multiple segmentations of the data along time
%course, leading to multiple CFM for this data. For the convinience of
%post-processing, one may wanna to combine all those .mat files to one .mat
%file, in the form of A=[nVariants,nSubj*nTimeWin]
parentDir=getappdata(handles.dlg_main,'parentDir');
%open the files to be combined
[filename, pathname, filterindex] = uigetfile(  { '*.mat','MAT-files (*.mat)';}, ...
        'Pick a file',...
        'MultiSelect', 'on',...
    strcat(parentDir,'\work data\'));
if iscell(filename)
   combineCFMs(pathname,filename);
else
    combineCFMs(pathname,{filename});
end
    


% --------------------------------------------------------------------
function Menu_MultiClassification_Callback(hObject, eventdata, handles)
%this uses the multiClassification method to test the effectiveness of the
%secelcted CN features
parentDir=getappdata(handles.dlg_main,'parentDir');
    [filename, pathname, filterindex] = uigetfile(  { '*.mat','MAT-files (*.mat)';}, ...
        'Pick a file',...
    strcat(parentDir,'\work data\'));
MultiClassification(pathname,filename);


% --------------------------------------------------------------------
function Menu_LOO_Euclidean_Callback(hObject, eventdata, handles)
% This one performs a LOO cross validation using Eulidean distance based
% classifier
% [cr,classLabel,nSubj]=LOO_Euclidean(A,nAc,beShow)


% --------------------------------------------------------------------
function Menu_ViewBrainRegions_Callback(hObject, eventdata, handles)
% This function view the brain regions specified in the multivariate
% classification results
parentDir=getappdata(handles.dlg_main,'parentDir');
    [filename, pathname, filterindex] = uigetfile(  { '*.mat','MAT-files (*.mat)';}, ...
        'Pick a file',...
    strcat(parentDir,'\work data\'));
ViewBrainRegions( pathname,filename);


% --------------------------------------------------------------------
function Menu_compareAAL2Broadman_Callback(hObject, eventdata, handles)
%convert AAL brain regions to Broadman areas or wise verse. 
Dlg_compareAAL2Broadman();


% --------------------------------------------------------------------
function Menu_compareResults_Callback(hObject, eventdata, handles)
%Compare the results with prious findings
Dlg_compareResults();
