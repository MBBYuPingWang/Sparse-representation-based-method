function varargout = Dlg_compareResults(varargin)
% DLG_COMPARERESULTS M-file for Dlg_compareResults.fig
%      DLG_COMPARERESULTS, by itself, creates a new DLG_COMPARERESULTS or raises the existing
%      singleton*.
%
%      H = DLG_COMPARERESULTS returns the handle to a new DLG_COMPARERESULTS or the handle to
%      the existing singleton*.
%
%      DLG_COMPARERESULTS('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in DLG_COMPARERESULTS.M with the given input arguments.
%
%      DLG_COMPARERESULTS('Property','Value',...) creates a new DLG_COMPARERESULTS or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Dlg_compareResults_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Dlg_compareResults_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Dlg_compareResults

% Last Modified by GUIDE v2.5 22-Sep-2013 10:25:11

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Dlg_compareResults_OpeningFcn, ...
                   'gui_OutputFcn',  @Dlg_compareResults_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Dlg_compareResults is made visible.
function Dlg_compareResults_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Dlg_compareResults (see VARARGIN)

% Choose default command line output for Dlg_compareResults
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);
clc

setappdata(handles.dlg_compareResults,'P_value',0.01);
set(handles.edit_P_Value,'String','0.01');

h_dlg=findobj('Tag','dlg_main');
h_dlg_main=guihandles(h_dlg);
%get the dir for the mask
parentDir=getappdata(h_dlg_main.dlg_main,'parentDir');
[filename, pathname, filterindex] = uigetfile(  { '*.mat','MAT-files (*.mat)';}, ...
        'Pick the saved results',...
    strcat(parentDir,'\work data\'));
myResultsPath=fullfile(pathname,filename);
setappdata(handles.dlg_compareResults,'myResultsPath',myResultsPath);
setappdata(handles.dlg_compareResults,'AALRegions',0);
setappdata(handles.dlg_compareResults,'beRegion',1);
set(handles.checkbox_beRegion,'Value',1);
setappdata(handles.dlg_compareResults,'beIntraRegion',0);
set(handles.checkbox_beIntraRegion,'Value',0);



% --- Outputs from this function are returned to the command line.
function varargout = Dlg_compareResults_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function edit_AALRegions_Callback(hObject, eventdata, handles)
val=str2num(get(hObject,'string'));
setappdata(handles.dlg_compareResults,'AALRegions',val);


% --- Executes during object creation, after setting all properties.
function edit_AALRegions_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_AALRegions (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton_compare.
function pushbutton_compare_Callback(hObject, eventdata, handles)
myResultsPath=getappdata(handles.dlg_compareResults,'myResultsPath');
P_value=getappdata(handles.dlg_compareResults,'P_value');
AALRegions=getappdata(handles.dlg_compareResults,'AALRegions');
beRegion=getappdata(handles.dlg_compareResults,'beRegion');
beIntraRegion=getappdata(handles.dlg_compareResults,'beIntraRegion')
compareResults(myResultsPath,P_value,AALRegions,beRegion,beIntraRegion);

% --- Executes on button press in pushbutton_close.
function pushbutton_close_Callback(hObject, eventdata, handles)
close(handles.dlg_compareResults);



function edit_P_Value_Callback(hObject, eventdata, handles)
val=str2num(get(hObject,'string'));
setappdata(handles.dlg_compareResults,'P_value',val);


% --- Executes during object creation, after setting all properties.
function edit_P_Value_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_P_Value (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in checkbox_beRegion.
function checkbox_beRegion_Callback(hObject, eventdata, handles)
beRegion=getappdata(handles.dlg_compareResults,'beRegion');
if beRegion==0,
    setappdata(handles.dlg_compareResults,'beRegion',1);
else
    setappdata(handles.dlg_compareResults,'beRegion',0);
end
    


% --- Executes on button press in checkbox_beIntraRegion.
function checkbox_beIntraRegion_Callback(hObject, eventdata, handles)
beIntraRegion=getappdata(handles.dlg_compareResults,'beIntraRegion');
if beIntraRegion==0,
    setappdata(handles.dlg_compareResults,'beIntraRegion',1);
else
    setappdata(handles.dlg_compareResults,'beIntraRegion',0);
end
