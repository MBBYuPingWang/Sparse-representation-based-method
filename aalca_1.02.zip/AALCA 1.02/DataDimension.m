function varargout = DataDimension(varargin)
% DATADIMENSION M-file for DataDimension.fig
%      DATADIMENSION, by itself, creates a new DATADIMENSION or raises the existing
%      singleton*.
%
%      H = DATADIMENSION returns the handle to a new DATADIMENSION or the handle to
%      the existing singleton*.
%
%      DATADIMENSION('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in DATADIMENSION.M with the given input arguments.
%
%      DATADIMENSION('Property','Value',...) creates a new DATADIMENSION or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before DataDimension_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to DataDimension_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help DataDimension

% Last Modified by GUIDE v2.5 09-Aug-2013 09:20:15

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @DataDimension_OpeningFcn, ...
                   'gui_OutputFcn',  @DataDimension_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end

% End initialization code - DO NOT EDIT


% --- Executes just before DataDimension is made visible.
function DataDimension_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to DataDimension (see VARARGIN)

% Choose default command line output for DataDimension
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

setappdata(handles.dlg_DataDimension,'d_x',0);
setappdata(handles.dlg_DataDimension,'d_y',0);
setappdata(handles.dlg_DataDimension,'d_z',0);

uiwait;%block the execution and wait for the dealing with this dialog

% --- Outputs from this function are returned to the command line.
function varargout = DataDimension_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function edit_x_Callback(hObject, eventdata, handles)
%get the current value of the bar
val=str2num(get(hObject,'string'));
setappdata(handles.dlg_DataDimension,'d_x',val);

% --- Executes during object creation, after setting all properties.
function edit_x_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_x (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_z_Callback(hObject, eventdata, handles)
%get the current value of the bar
val=str2num(get(hObject,'string'));
setappdata(handles.dlg_DataDimension,'d_z',val);


% --- Executes during object creation, after setting all properties.
function edit_z_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_z (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_y_Callback(hObject, eventdata, handles)
%get the current value of the bar
val=str2num(get(hObject,'string'));
setappdata(handles.dlg_DataDimension,'d_y',val);


% --- Executes during object creation, after setting all properties.
function edit_y_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_y (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in radiobutton_ImgFormat.
function radiobutton_ImgFormat_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton_ImgFormat (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton_ImgFormat


% --- Executes on button press in pushbutton_OK.
function pushbutton_OK_Callback(hObject, eventdata, handles)
%resume the execution
uiresume;
