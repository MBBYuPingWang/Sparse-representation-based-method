function varargout = Dlg_compareAAL2Broadman(varargin)
% DLG_COMPAREAAL2BROADMAN M-file for Dlg_compareAAL2Broadman.fig
%      DLG_COMPAREAAL2BROADMAN, by itself, creates a new DLG_COMPAREAAL2BROADMAN or raises the existing
%      singleton*.
%
%      H = DLG_COMPAREAAL2BROADMAN returns the handle to a new DLG_COMPAREAAL2BROADMAN or the handle to
%      the existing singleton*.
%
%      DLG_COMPAREAAL2BROADMAN('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in DLG_COMPAREAAL2BROADMAN.M with the given input arguments.
%
%      DLG_COMPAREAAL2BROADMAN('Property','Value',...) creates a new DLG_COMPAREAAL2BROADMAN or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Dlg_compareAAL2Broadman_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Dlg_compareAAL2Broadman_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Dlg_compareAAL2Broadman

% Last Modified by GUIDE v2.5 18-Sep-2013 14:24:12

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Dlg_compareAAL2Broadman_OpeningFcn, ...
                   'gui_OutputFcn',  @Dlg_compareAAL2Broadman_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Dlg_compareAAL2Broadman is made visible.
function Dlg_compareAAL2Broadman_OpeningFcn(hObject, eventdata, handles, varargin)

% Choose default command line output for Dlg_compareAAL2Broadman
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);
setappdata(handles.dlg_compareAAL2Broadman,'broadmanAreas',0);
setappdata(handles.dlg_compareAAL2Broadman,'AALRegions',0);
setappdata(handles.dlg_compareAAL2Broadman,'beB2A',1);
set(handles.radiobutton_B2A,'Value',1);
set(handles.radiobutton_A2B,'Value',0);
set(handles.edit_Resolution,'String',0);
setappdata(handles.dlg_compareAAL2Broadman,'resolution',0);
clc

% --- Outputs from this function are returned to the command line.
function varargout = Dlg_compareAAL2Broadman_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function edit_AALRegions_Callback(hObject, eventdata, handles)
val=str2num(get(hObject,'string'));
setappdata(handles.dlg_compareAAL2Broadman,'AALRegions',val);


% --- Executes during object creation, after setting all properties.
function edit_AALRegions_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_AALRegions (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_BroadmanArea_Callback(hObject, eventdata, handles)
val=str2num(get(hObject,'string'))
setappdata(handles.dlg_compareAAL2Broadman,'broadmanAreas',val);
feval(@pushbutton_Convert_Callback,handles.pushbutton_Convert,eventdata,handles);

% --- Executes during object creation, after setting all properties.
function edit_BroadmanArea_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in radiobutton_A2B.
function radiobutton_A2B_Callback(hObject, eventdata, handles)
setappdata(handles.dlg_compareAAL2Broadman,'beB2A',0);
set(handles.radiobutton_B2A,'Value',0);
feval(@pushbutton_Convert_Callback,handles.pushbutton_Convert,eventdata,handles);




% --- Executes on button press in radiobutton_B2A.
function radiobutton_B2A_Callback(hObject, eventdata, handles)
setappdata(handles.dlg_compareAAL2Broadman,'beB2A',1);
set(handles.radiobutton_A2B,'Value',0);
feval(@pushbutton_Convert_Callback,handles.pushbutton_Convert,eventdata,handles);


% --- Executes on button press in pushbutton_Convert.
function pushbutton_Convert_Callback(hObject, eventdata, handles)
h_dlg=findobj('Tag','dlg_main');
h_dlg_main=guihandles(h_dlg);
%get the dir for the mask
parentDir=getappdata(h_dlg_main.dlg_main,'parentDir');
maskDir=strcat(parentDir,'\work data\mask');

broadmanAreas=getappdata(handles.dlg_compareAAL2Broadman,'broadmanAreas');
AALRegions=getappdata(handles.dlg_compareAAL2Broadman,'AALRegions');
beB2A=getappdata(handles.dlg_compareAAL2Broadman,'beB2A');
resolution=getappdata(handles.dlg_compareAAL2Broadman,'resolution');
[AALRegions,broadmanAreas]=compareAAL2Broadman(maskDir,AALRegions,broadmanAreas,beB2A,resolution)
%show the results
setappdata(handles.dlg_compareAAL2Broadman,'broadmanAreas',broadmanAreas);
setappdata(handles.dlg_compareAAL2Broadman,'AALRegions',AALRegions);
set(handles.edit_BroadmanArea,'String',num2str(broadmanAreas));
set(handles.edit_AALRegions,'String',num2str(AALRegions));



% --- Executes on button press in pushbutton_Close.
function pushbutton_Close_Callback(hObject, eventdata, handles)
close(handles.dlg_compareAAL2Broadman);


function edit_Resolution_Callback(hObject, eventdata, handles)
val=str2num(get(hObject,'string'))
setappdata(handles.dlg_compareAAL2Broadman,'resolution',val);
pushbutton_Convert_Callback(hObject, eventdata, handles)
feval(@pushbutton_Convert_Callback,handles.pushbutton_Convert,eventdata,handles);



% --- Executes during object creation, after setting all properties.
function edit_Resolution_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
