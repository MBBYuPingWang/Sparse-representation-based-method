function ViewBrainRegions(pathname,CR_filename)
% This function view the brain regions specified in the multivariate
% classification results
clc
filePath=fullfile(pathname,CR_filename);
load(filePath,'maxCR');

nContrast=length(maxCR);
regionIndex=cell(nContrast,1);
% disp regions selected by each of the contrasts
for i=1:nContrast
    tempIndex=[maxCR(i).Index(:,1);maxCR(i).Index(:,2)];
    regionIndex{i}(:,1)=unique(tempIndex);
    [regionIndex{i}(:,2)]=getHist(tempIndex,num2cell(unique(tempIndex)));
    disp('                               ');
    disp('******************************');
    disp(sprintf('Contrast %s:',maxCR(i).ContrastName));
    disp('----------CN pairs------------');
    disp(maxCR(i).Index(:,1:2))
    disp('---CN related brain regions---');
    disp(regionIndex{i});    
    disp('-------------CR(%)------------');
    disp(sprintf('MaxCR=%2.2f, P-value<%2.2e',maxCR(i).maxCR,maxCR(i).maxP));    
  
end

%copy the aal mask.img file to the work data
maskPath=strcat(pathname,'\mask\mask_aal.hdr');
workPath=strcat(pathname,'\selected_AAL_Regions.hdr');
copyfile(maskPath,workPath,'f');

maskPath=strcat(pathname,'\mask\mask_aal.img');
workPath=strcat(pathname,'\selected_AAL_Regions.img');
copyfile(maskPath,workPath,'f');

%get the fullMask AAL regions
maskPath=strcat(pathname,'\mask\mask_aal.img');
fid=fopen(maskPath,'r');
fullMask=fread(fid,'uint8');
lfullMask=length(fullMask);
fclose('all');

%generate the selected brain regions for each contrast
for i=1:nContrast
%copy the aal mask.img file to the work data
maskPath=strcat(pathname,'\mask\mask_aal.hdr');
workPath=strcat(pathname,'\',maxCR(i).ContrastName,'.hdr');
copyfile(maskPath,workPath,'f');

maskPath=strcat(pathname,'\mask\mask_aal.img');
workPath=strcat(pathname,'\',maxCR(i).ContrastName,'.img');
copyfile(maskPath,workPath,'f');

%create the regions
regionsMask=zeros(lfullMask,1);
nRegions=size(regionIndex{i},1);
% disp('-----------------')
% maxFullMask=max(fullMask)
% minFullMask=min(fullMask)
for j=1:nRegions
    tempIndex=find(fullMask==regionIndex{i}(j,1));
    regionsMask(tempIndex)=regionIndex{i}(j,2);
end
% size(regionsMask)
% max(regionsMask)
% min(regionsMask)
%write the .img file
fid=fopen(workPath,'w+');
fwrite(fid,regionsMask,'uint8');
fclose(fid);
clear regionsMask;
end
fclose all;
xjview;%open the xjview to view the images
msgbox(strcat('Brain regions selected by each contrasts were save to:',workPath,', under name of the contrast. Please open the file use [xjview]!'),'Data were saved!');



