function varargout = readDataFolder(varargin)
%this dialog sets the parametes for reading the data: Band filter's edge
%frequences: FreLow, FreHigh (Hz) and the sampling period TR (s). The
%default values of those are (0.01~0.08 Hz) (2s)
%The Gaussisan smoother parameter fwhm (mm) and the size of a voxel (mm).
%The default values for those are (6mm) and (3mm)
%the TimePoints for each subject (defaulty is the sample number of the
%first subject), the DiscardPoints (defaulty is 5).

% clc

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @readDataFolder_OpeningFcn, ...
                   'gui_OutputFcn',  @readDataFolder_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before readDataFolder is made visible.
function readDataFolder_OpeningFcn(hObject, eventdata, handles, varargin)
% Choose default command line output for readDataFolder
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

setappdata(handles.dlg_readDataFolder,'filterLow',0.01);
setappdata(handles.dlg_readDataFolder,'filterHigh',0.08);
setappdata(handles.dlg_readDataFolder,'TR',2);
setappdata(handles.dlg_readDataFolder,'fwhm',6);
setappdata(handles.dlg_readDataFolder,'VoxelSize',3);
setappdata(handles.dlg_readDataFolder,'TimePoints',0);
setappdata(handles.dlg_readDataFolder,'DiscardPoints',0);


setappdata(handles.dlg_readDataFolder,'beFilter',0);
set(handles.edit_freLow,'Enable','off'); 
set(handles.edit_freHigh,'Enable','off'); 
set(handles.edit_TR,'Enable','off'); 

setappdata(handles.dlg_readDataFolder,'beSmooth',0);
set(handles.edit_fwhm,'Enable','off'); 
set(handles.edit_VoxelSize,'Enable','off'); 

setappdata(handles.dlg_readDataFolder,'beDataInf',0);
set(handles.edit_TimePoints,'Enable','off'); 
set(handles.edit_DiscardPoints,'Enable','off'); 


uiwait;%block the execution and wait for the dealing with this dialog


% --- Outputs from this function are returned to the command line.
function varargout = readDataFolder_OutputFcn(hObject, eventdata, handles) 
% Get default command line output from handles structure
varargout{1} = handles.output;

% --- Executes on button press in checkbox_bandFilter.
function checkbox_bandFilter_Callback(hObject, eventdata, handles)
beFilter=getappdata(handles.dlg_readDataFolder,'beFilter');

if beFilter==0
    set(handles.edit_freLow,'Enable','on'); 
    set(handles.edit_freHigh,'Enable','on'); 
    set(handles.edit_TR,'Enable','on'); 
    setappdata(handles.dlg_readDataFolder,'beFilter',1);
else
    set(handles.edit_freLow,'Enable','off'); 
    set(handles.edit_freHigh,'Enable','off'); 
    set(handles.edit_TR,'Enable','off'); 
    setappdata(handles.dlg_readDataFolder,'beFilter',0);
end


function edit_freLow_Callback(hObject, eventdata, handles)
clc
%get the current value of the bar
val=str2num(get(hObject,'string'));
setappdata(handles.dlg_readDataFolder,'filterLow',val);



function edit_freLow_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_freLow (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_freHigh_Callback(hObject, eventdata, handles)
%get the current value of the bar
val=str2num(get(hObject,'string'));
setappdata(handles.dlg_readDataFolder,'filterHigh',val);


% --- Executes during object creation, after setting all properties.
function edit_freHigh_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_freHigh (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton_Default.
function pushbutton_Default_Callback(hObject, eventdata, handles)

setappdata(handles.dlg_readDataFolder,'beFilter',1);
setappdata(handles.dlg_readDataFolder,'beSmooth',1);
setappdata(handles.dlg_readDataFolder,'beDataInf',0);
set(handles.edit_freLow,'string','0.01'); 
set(handles.edit_freHigh,'string','0.08'); 
set(handles.edit_TR,'string','2');
set(handles.edit_fwhm,'string','6');
set(handles.edit_VoxelSize,'string','3');
set(handles.checkbox_GaussianSmooth,'Value',1);
set(handles.checkbox_bandFilter,'Value',1);
set(handles.checkbox_DataInformation,'Value',0);
setappdata(handles.dlg_readDataFolder,'beDataInf',0);
set(handles.edit_TimePoints,'string','0');
set(handles.edit_DiscardPoints,'string','0');



% --- Executes on button press in checkbox_GaussianSmooth.
function checkbox_GaussianSmooth_Callback(hObject, eventdata, handles)
if getappdata(handles.dlg_readDataFolder,'beSmooth')==0
    set(handles.edit_fwhm,'Enable','on'); 
    set(handles.edit_VoxelSize,'Enable','on'); 
    setappdata(handles.dlg_readDataFolder,'beSmooth',1)
else
    set(handles.edit_fwhm,'Enable','off'); 
    set(handles.edit_VoxelSize,'Enable','off'); 
    setappdata(handles.dlg_readDataFolder,'beSmooth',0)
end
    



function edit_fwhm_Callback(hObject, eventdata, handles)
%get the current value of the bar
val=str2num(get(hObject,'string'));
setappdata(handles.dlg_readDataFolder,'fwhm',val);



% --- Executes during object creation, after setting all properties.
function edit_fwhm_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_VoxelSize_Callback(hObject, eventdata, handles)
%get the current value of the bar
val=str2num(get(hObject,'string'));
setappdata(handles.dlg_readDataFolder,'VoxelSize',val);



% --- Executes during object creation, after setting all properties.
function edit_VoxelSize_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_TR_Callback(hObject, eventdata, handles)
%get the current value of the bar
val=str2num(get(hObject,'string'));
setappdata(handles.dlg_readDataFolder,'TR',val);


% --- Executes during object creation, after setting all properties.
function edit_TR_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function edit_freLow_ButtonDownFcn(hObject, eventdata, handles)
set(handles.edit_freLow,'string',''); 


function edit_freHigh_ButtonDownFcn(hObject, eventdata, handles)
set(handles.edit_freHigh,'string',''); 


function edit_TR_ButtonDownFcn(hObject, eventdata, handles)
set(handles.edit_TR,'string','');


function edit_fwhm_ButtonDownFcn(hObject, eventdata, handles)
set(handles.edit_fwhm,'string','');


function edit_VoxelSize_ButtonDownFcn(hObject, eventdata, handles)
set(handles.edit_VoxelSize,'string','');


function pushbutton_OK_Callback(hObject, eventdata, handles)
beFilter=getappdata(handles.dlg_readDataFolder,'beFilter');
if beFilter==0
    setappdata(handles.dlg_readDataFolder,'filterLow',0);
    setappdata(handles.dlg_readDataFolder,'filterHigh',0);
end

beSmooth=getappdata(handles.dlg_readDataFolder,'beSmooth');
if beFilter==0
    setappdata(handles.dlg_readDataFolder,'fwhm',0);
    setappdata(handles.dlg_readDataFolder,'VoxelSize',0);
end

%resume the execution
uiresume;






% --- Executes during object creation, after setting all properties.
function edit_TimePoints_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_TimePoints (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_DiscardPoints_Callback(hObject, eventdata, handles)
%get the current value of the bar
val=str2num(get(hObject,'string'));
setappdata(handles.dlg_readDataFolder,'DiscardPoints',val);


% --- Executes during object creation, after setting all properties.
function edit_DiscardPoints_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_DiscardPoints (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function checkbox_DataInformation_Callback(hObject, eventdata, handles)
beDataInf=getappdata(handles.dlg_readDataFolder,'beDataInf');
if beDataInf==0
    setappdata(handles.dlg_readDataFolder,'beDataInf',1);
    set(handles.edit_TimePoints,'Enable','on'); 
    set(handles.edit_DiscardPoints,'Enable','on');  
else
    setappdata(handles.dlg_readDataFolder,'beDataInf',0);
    set(handles.edit_TimePoints,'Enable','off');
    set(handles.edit_DiscardPoints,'Enable','off'); 
end

function edit_TimePoints_Callback(hObject, eventdata, handles)
%get the current value of the bar
val=str2num(get(hObject,'string'));
setappdata(handles.dlg_readDataFolder,'TimePoints',val);


function edit_TimePoints_ButtonDownFcn(hObject, eventdata, handles)
set(handles.edit_TimePoints,'string',''); 

function edit_DiscardPoints_ButtonDownFcn(hObject, eventdata, handles)
set(handles.edit_DiscardPoints,'string',''); 
