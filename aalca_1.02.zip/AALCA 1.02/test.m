
 
clc
close all;
clear
addPath();

imPath='C:\Users\chb\Desktop\pic1.bmp';
data=imread(imPath);
figure;
imagesc(data);


% for i=1:3
% [data(:,:,i),s,dimsValue]=GaussionSmooth(data(:,:,i),2);
% end

[data,s,dimsValue]=GaussionSmooth(data,2);
size(data)
imshow(data)
for i=1:3
figure;
imagesc(data(:,:,i));
end


% fs=0.5;
% wp=[.01 .08];
% ws=[.001 .1];
% rp=1;
% rs=20;
% bePlotFilter=1;
% x=rand(155,1)
% figure(99);
% plot(x,'r');
% hold on;
% 
% [y,la,a1,b1]=FilterBP(fs,wp,ws,rp,rs,x,bePlotFilter);
% figure(99);
% plot(y,'g');
% hold on;
% [y,la,a2,b2]=FilterBP_0(fs,wp,ws,rp,rs,x,bePlotFilter);
% figure(99);
% plot(y,'b');
% hold on;
% ad=a1-a2
% bd=b1-b2

% % test the data saved in .mat file
% load('E:\research NIH 2\work data\A.mat','maskIndex','data')
% 
% subj=10;
% data14=data(155*(subj-1)+1:155*subj,:);
% tempIm=zeros(61,73,61,'int32');
% 
% tempIm(maskIndex)=data14(15,:);
% for i=1:7:61
%     figure(10);
%     imagesc(tempIm(:,:,i));
%     tt=0;
% end




% %%%%%%%%%%band pass filter the data%%%%%%%%%%
% fs=0.5;
% filterH=0.15;
% filterL=0.01;
% wp=[filterL, filterH];
% ws=[filterL*0.95, filterH*1.01];
% rp=1;%signal loss in pass band 
% rs=20;%signal attenuation in the stopband.  
% bePlotFilter=1;
% 
% x=1:70;
% a=2;
% y=sin(a*x')+cos(a*x');
% % y=x';
% figure(100);
% plot(y); 
% hold on;
% [y1]=FilterBP(fs,wp,ws,rp,rs,double(y),bePlotFilter);  
% figure(100);
% plot(y1,'r');
% 
% fy=fft(y);
% fy1=fft(y1);
% figure;
% plot(fy);
% hold on;
% plot(fy1,'r');








% aalPath='E:\research NIH\work data\aal_clusters_1000.mat';
% load(aalPath,'sClusters','nClusters');
% 
% % 'maskIndex','lMask','dimensions',
% maskIndex=0;
% lMask=0;
% for i=1:nClusters
%     tempN=sClusters(i).Num;
%     maskIndex(lMask+1:lMask+tempN)=sClusters(i).Index(:);
%     lMask=lMask+tempN;
% end
% lMask=lMask
% nClusters=nClusters
% dimensions=[61,73,61];
% save(aalPath,'sClusters','nClusters','maskIndex','lMask','dimensions');