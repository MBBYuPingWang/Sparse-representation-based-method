function varargout = CFM_Parameter_Setting(varargin)
% CFM_PARAMETER_SETTING M-file for CFM_Parameter_Setting.fig
%      CFM_PARAMETER_SETTING, by itself, creates a new CFM_PARAMETER_SETTING or raises the existing
%      singleton*.
%
%      H = CFM_PARAMETER_SETTING returns the handle to a new CFM_PARAMETER_SETTING or the handle to
%      the existing singleton*.
%
%      CFM_PARAMETER_SETTING('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in CFM_PARAMETER_SETTING.M with the given input arguments.
%
%      CFM_PARAMETER_SETTING('Property','Value',...) creates a new CFM_PARAMETER_SETTING or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before CFM_Parameter_Setting_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to CFM_Parameter_Setting_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help CFM_Parameter_Setting

% Last Modified by GUIDE v2.5 13-Aug-2013 11:29:36

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @CFM_Parameter_Setting_OpeningFcn, ...
                   'gui_OutputFcn',  @CFM_Parameter_Setting_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before CFM_Parameter_Setting is made visible.
function CFM_Parameter_Setting_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to CFM_Parameter_Setting (see VARARGIN)

% Choose default command line output for CFM_Parameter_Setting
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);
setappdata(handles.dlg_CFM_Parameter_Setting,'winL',inf);
setappdata(handles.dlg_CFM_Parameter_Setting,'stepL',inf);
setappdata(handles.dlg_CFM_Parameter_Setting,'TR',2);
uiwait;%block the execution and wait for the dealing with this dialog



% --- Outputs from this function are returned to the command line.
function varargout = CFM_Parameter_Setting_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function edit_WinL_Callback(hObject, eventdata, handles)
val=str2num(get(hObject,'string'));
setappdata(handles.dlg_CFM_Parameter_Setting,'winL',val);


% --- Executes during object creation, after setting all properties.
function edit_WinL_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_WinL (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_TR_Callback(hObject, eventdata, handles)
val=str2num(get(hObject,'string'));
setappdata(handles.dlg_CFM_Parameter_Setting,'TR',val);


% --- Executes during object creation, after setting all properties.
function edit_TR_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_TR (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_StepL_Callback(hObject, eventdata, handles)
val=str2num(get(hObject,'string'));
setappdata(handles.dlg_CFM_Parameter_Setting,'stepL',val);

% --- Executes during object creation, after setting all properties.
function edit_StepL_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_StepL (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function pushbutton_Default_Callback(hObject, eventdata, handles)
setappdata(handles.dlg_CFM_Parameter_Setting,'winL',inf);
setappdata(handles.dlg_CFM_Parameter_Setting,'stepL',inf);
setappdata(handles.dlg_CFM_Parameter_Setting,'TR',2);

set(handles.edit_WinL,'String','Inf');
set(handles.edit_StepL,'String',inf);
set(handles.edit_TR,'String','2');



function pushbutton_OK_Callback(hObject, eventdata, handles)
% close(handles.dlg_CFM_Parameter_Setting);
uiresume;%resume the execution
