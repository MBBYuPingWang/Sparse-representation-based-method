function [combines,nCombines]=getCombines(index_n,m)
% This function get the combinations for selecting m number of variables
% from index_n of (n,1);

% disp('------------------------');
n=length(index_n);
if m<1||m>n
    combines='';
    nCombines=0;
    return;
end

nCombines=factorial(n)/factorial(n-m)/factorial(m);
combines=cell(nCombines,1);

if m==1,
    for i=1:nCombines
        combines{i}=index_n(i);   
    end
    return;
end

if m==n,
    combines{nCombines}=index_n(1:n);
    return;
end

if m>1
    nSelected=0;
        for i=1:length(index_n)-1
            %selecting from the rest elements m-1;
            currentIndex=index_n(i);
            [subCombines,nSubCombines]=getCombines(index_n(i+1:end),m-1);
            for j=1:nSubCombines
                combines{nSelected+j}=[currentIndex,subCombines{j}];
            end
            nSelected=nSelected+nSubCombines;
        end
end


if nSelected~=nCombines
    error('The results is not correct!');
end



    