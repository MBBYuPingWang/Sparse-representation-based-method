function testGsmooth2()

Im=rand(100);
figure;
imagesc(Im);
Im=gsmooth2(Im,5,'same');
figure;
imagesc(Im);