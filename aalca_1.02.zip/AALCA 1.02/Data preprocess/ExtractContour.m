function Im0=ExtractContour(Im,r)
%find the contour of the targets in the Image Im
if nargin<2,
    r=1;
end
Im0=Im;
[Imr,Imc]=size(Im);

for i=r+1:Imr-r
    for j=r+1:Imc-r
        if Im(i,j)==0,%backgrounds 
           continue; 
        end
        
        beContour=0;
        for ii=-r:r
            for jj=-r:r
              if Im(i+ii,j+jj)==0
                  beContour=1;
                  break;
              end
            end
            if beContour==1
                break;
            end
        end
        
        if beContour==0
            Im0(i,j)=0;
        end
    end
end
            
                