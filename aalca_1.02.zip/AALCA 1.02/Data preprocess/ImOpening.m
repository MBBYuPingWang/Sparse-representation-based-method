function Im=ImOpening(Im,r)
% opening is the dilation of the erosion 
% used to remove the high frequency noises in the background

Im=ImErosion(Im,r);
Im=ImDilation(Im,r);

