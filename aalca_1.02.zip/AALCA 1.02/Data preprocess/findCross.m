function [str3,ls3,index3from1,index3from2]=findCross(str1,str2,exceptions)
%this function locate the same strings/numbers in string cells/number vectors str1 and str2
%str1 and str2 are supposed to have no repeated strings/numbers
% str1={'--','asf','asdfadsgf'}
% str2={'--','asf','asdfadsgf','sfdg','asfg'}
% exceptions={'--'}

if nargin<3
    exceptions='';
end

if isempty(str1)||isempty(str2)
    str3=[];
    ls3=0;
    index3from1=[];
    index3from2=[];
    return;
end

if isnumeric(str1(1))==0
    [str3,ls3,index3from1,index3from2]=findCrossChar(str1,str2,exceptions);
else
    [str3,ls3,index3from1,index3from2]=findCrossNum(str1,str2,exceptions);
end
end

function [str3,ls3,index3from1,index3from2]=findCrossNum(str1,str2,exceptions)
if nargin<3
    exceptions='';
end

[str1,I1]=sort(str1);%sort the str1 by 'ascend' order,
[str2,I2]=sort(str2);%sort the str1 by 'ascend' order,

if(str1(end)<str2(1)||str1(1)>str2(end))
    str3=[];
    ls3=0;
    index3from1=[];
    index3from2=[];
%     disp('No cross!');
    return;
end

ls1=length(str1);
ls2=length(str2);
le=length(exceptions);
ls3=0;
ps2=1;%current position of the search in str2
for i=1:ls1
    beExcep=0;
    for k=1:le
        if str1(i)==exceptions(k)
            beExcep=1;
            break;
        end
    end
    if beExcep==1
       continue;
    end
        
    for j=ps2:ls2
        if (str1(i)==str2(j))
            ls3=ls3+1;
            str3(ls3)=str1(i);
            index3from1(ls3)=I1(i);
            index3from2(ls3)=I2(j);
            ps2=j;%update the position
            break;
        end
    end
end
if ls3==0
    str3='';
    index3from2=0;
    index3from1=0;
%     disp('No cross!');
    return;
end

%restore the index according to original str1
[index3from1,I3]=sort(index3from1);
str3=str3(I3);
[index3from2]=sort(index3from2);

end


function [str3,ls3,index3from1,index3from2]=findCrossChar(str1,str2,exceptions)
if nargin<3
    exceptions='';
end

[str1,I1]=sort(str1);%sort the str1 by 'ascend' order,
[str2,I2]=sort(str2);%sort the str1 by 'ascend' order,

if(str1{end}(1)<str2{1}(1)||str1{1}(1)>str2{end}(1))
    str3='';
    ls3=0;
    index3from1=[];
    index3from2=[];
    return;
end

ls1=length(str1);
ls2=length(str2);
le=length(exceptions);
ls3=0;
ps2=1;%current position of the search in str2
for i=1:ls1
    beExcep=0;
    for k=1:le
        if strcmp(str1(i),exceptions(k))
            beExcep=1;
            break;
        end
    end
    if beExcep==1
       continue;
    end
        
    for j=ps2:ls2
        if strcmp(str1(i),str2(j))
            ls3=ls3+1;
            str3(ls3)=str1(i);
            index3from1(ls3)=I1(i);
            index3from2(ls3)=I2(j);
            ps2=j;%update the position
            break;
        end
    end
end
if ls3==0
    str3='';
    index3from2=0;
    index3from1=0;
%     disp('No cross!');
    return;
end

%restore the index according to original str1
[index3from1,I3]=sort(index3from1);
str3=str3(I3);
[index3from2]=sort(index3from2);
end

    

