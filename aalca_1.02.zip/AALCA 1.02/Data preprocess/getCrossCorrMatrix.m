function ABCorr=getCrossCorrMatrix(A,B,beDiag)
% This function get the cross corr matrix of two column matrix A and B
%the rows of A and B must be same length
%ACorr is the size of Ac by Bc
%beDiag=1or0 states the diagnal value of the ACorr to zero 

if nargin<3
    beDiag=1;
end

A=double(A);
B=double(B);
[Ar,Ac]=size(A);
[Br,Bc]=size(B);

A=NormolizeA(A);
B=NormolizeA(B);
ABCorr=A'*B;

if beDiag==0%remove the diagnal elements
    ABCorr=triu(ABCorr,1)+tril(ABCorr,-1);
end
    

end



function A=NormolizeA(A,beZMean,beColumn)
%this function normalize each column of A to have unit L2 norm
% if beColumn=0 specify if the normalization is to the comun or  row
% if beZMean=1, normalize each column to have zero means

A=double(A);

if  nargin<3
    beColumn=1;
end
if nargin<2
    beZMean=1;
end

if beColumn==0
    A=A'
end

[Ar,Ac]=size(A);
y=zeros(Ar,1);

for j=1:Ac  
    if beZMean==1
        A(:,j)=A(:,j)-mean(A(:,j));
    end
    nA=norm(A(:,j));
    if nA==0
        continue;
    end
    A(:,j)=A(:,j)/nA;
end


if beColumn==0
    A=A'
end

end
