function compareListsFromExelColums()
%this funciton compare the list from two columns of an excel file
clc
filePath='E:\research works\research work5\manuscript\BMC Medical Genomics paper\first 50 genes selected from the two methods.xlsx';
[An1,At1]=xlsread(filePath,'sheet1','a3:a52')
[An2,At2]=xlsread(filePath,'sheet1','c3:c52')

[s,ls,indet1xFromA]=findCross(At1,At2)