function Mdis=GetMahaDistance(x,Y)
% This function get the Mahalanobis distance of x to Y
%x is a column vector
%Y =[Yr,Yc] is a matrix with Yc variables and Yr samples
Cov=cov(Y);
Mean=mean(Y,2);
Mdis=sqrt((x-Mean)'*inv(Cov)*(x-Mean));
 
