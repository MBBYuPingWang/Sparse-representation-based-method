 function [hB,indexB]=myhistc(A,B)
%  This function is a replace of the matlab function histc
%finding the frequency of the elements of B from A.
     lB=length(B);
     hB=zeros(lB,1);
     lA=length(A);
     indexB=cell(lB,1);
     for i=1:lB
         tempN=0;
         for j=1:lA
             if B(i)==A(j)
                 tempN=tempN+1;
                 hB(i)=hB(i)+1;
                 indexB{i}(tempN)=j;
             end
         end
     end