function nXY=drawFigures(A,nXY,zRange,Titles,figID,beColorbar)
%This function draw the matrix of A into one big figuer with Az number of
%subplots, where [Ar,Ac,Az]=size(A)

if nargin<6
    beColorbar=1;
end
if nargin<5
    figID=100;
end
if nargin<4
    Titles='';
end
if nargin<3
    zRange=[1,size(A,3)];
end
if nargin<2
    [Az]=size(A,3);
    nXY(1)=ceil(((Az/6)^0.5)*3);
    nXY(2)=[ceil(Az/nXY(1))];
end

nx=nXY(1);
ny=nXY(2);
[Ar,Ac,Az]=size(A);
nIm=0;
for z=zRange(1):zRange(2)
    tempIm=A(:,:,z);
    figure(figID);
    nIm=nIm+1;
    subplot(nx,ny,nIm);
    imagesc(tempIm);
end

figure(figID);
title(Titles);

if beColorbar==1
    colorbar;
end