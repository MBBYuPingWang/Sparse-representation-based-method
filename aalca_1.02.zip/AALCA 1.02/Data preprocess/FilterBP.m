function [y,la,a,b]=FilterBP(fs,wp,ws,rp,rs,x,bePlotFilter)
%this function filter the data with a band pass fileter
%fs is the sample frequency
% wp and ws are the passband and stopband edge frequencies
%example Bandpass:   Wp = [.01 .08], Ws = [.001 .1]
% rp is signal loss in pass band (db)
% rs is signal attenuation in the stopband (db)
% bePlotFilter=1 plot the fileter

%%%%%%%%%%%%%%example for 0.08 hz band pass filter%%%%%%%%%%
% clc
% fs=0.5;
% wp=[.01 .08];
% ws=[.001 .1];
% rp=1;
% rs=20;
% bePlotFilter=1;
% x=rand(100,1);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
x=double(x);
if nargin<7
    bePlotFilter=0;
end
f0=fs/2;

la=50;
while la>20
    [n,wn]=buttord(wp/f0,ws/f0,rp,rs,'z');
    [b,a]=butter(n,wn);
    la=length(a);
    ws(2)=ws(2)*1.01;
    ws(1)=ws(1)*0.95;
end

%filter x1
[y]=filter(b,a,x);

%plot the filter results
if bePlotFilter==1
[h,w]=freqz(b,a);
figure;
plot(w*fs/(2*pi),abs(h));
xlabel('Frequece(Hz)');
ylabel('Amplitude modification');
end
