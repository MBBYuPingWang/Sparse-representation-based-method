function ACorr=getCorrMatrix(A,beDiag)
% This function get the corr matrix of a column matrix A
%beDiag=1or0 states the diagnal value of the ACorr to zero 

if nargin<2
beDiag=1;
end

A=double(A);
[Ar,Ac]=size(A);
A=NormolizeA(A);
ACorr=zeros(Ac,Ac);

%process big data matrix
if beDiag==1
    ACorr(Ac,Ac)=1;
else
    ACorr(Ac,Ac)=0;
end

for i=1:Ac-1
    if beDiag==1
        ACorr(i,i)=1;%the diagnal of ACorr
    else
        ACorr(i,i)=0;%the diagnal of ACorr
    end
    ACorr(i,i+1:Ac)=A(:,i)'*A(:,i+1:Ac);%up-right corner of the matrix
    ACorr(i+1:Ac,i)=ACorr(i,i+1:Ac)';%the low-left corner of the matrix    
end    

end



function A=NormolizeA(A,beZMean,beColumn)
%this function normalize each column of A to have unit L2 norm
% if beColumn=0 specify if the normalization is to the comun or  row
% if beZMean=1, normalize each column to have zero means

A=double(A);

if  nargin<3
    beColumn=1;
end
if nargin<2
    beZMean=1;
end

if beColumn==0
    A=A'
end

[Ar,Ac]=size(A);
y=zeros(Ar,1);

for j=1:Ac  
    if beZMean==1
        A(:,j)=A(:,j)-mean(A(:,j));
    end
    nA=norm(A(:,j));
    if nA==0
        continue;
    end
    A(:,j)=A(:,j)/nA;
end


if beColumn==0
    A=A'
end

end
