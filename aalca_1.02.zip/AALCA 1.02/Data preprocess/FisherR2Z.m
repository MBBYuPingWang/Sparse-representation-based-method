function z=FisherR2Z(r)
%this function perferm the Fisher transformation for a correlation
%coefficient �� 
% % r=-1:0.05:1;
% r=rand(5,5)*2-1
r=double(r);%in case the input is not double
thre=0.9999;
r(r>=thre)=thre;
r(r<=-thre)=-thre;
z=0.5*log((r+1)./(1-r));
