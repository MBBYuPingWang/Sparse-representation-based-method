function Im=ImStretch(Im,range,sourceRange)
%stretch the image into the range of range=[a,b]
% sourceRange refers to the value range of Im to be stretched

Im=double(Im);
range=double(range);

if nargin<3
    sourceRange=[min(Im(:)),max(Im(:))];
else
    sourceRange=double(sourceRange);
end

minIm=sourceRange(1);
maxIm=sourceRange(2);
a=range(1);
b=range(2);

if maxIm==minIm
    Im(:)=(b-a)/2+a;
    return;
end

%record the ones that are out of the sourceRange
srLow=sourceRange(1);
srUp=sourceRange(2);

indexL=find(Im(:)<srLow);
ImLow=Im(indexL);
indexU=find(Im(:)>srUp);
ImUp=Im(indexU);

%stretch image
Im=(Im-minIm)/(maxIm-minIm)*(b-a)+a;



%restore image
if isempty(ImLow)==0
    Im(indexL)=ImLow(:);
end
if isempty(ImUp)==0
    Im(indexU)=ImUp(:);
end

% disp('Image strech is done!');




