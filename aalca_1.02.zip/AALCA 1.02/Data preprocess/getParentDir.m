function [fileName,pathName,apendixName]=getParentDir(fileDir)
%this function get the path, fileName and the apendix of the  of the
%current file 

path0=fileDir;
p1=find(path0=='.');
if isempty(p1)
    apendixName='';
    disp('This is a folder or a file with no apendix!');
else
    p1=p1(length(p1));
    apendixName=path0(p1+1:length(path0));%apendixName
    path0=path0(1:p1-1);
end

p1=find(path0=='\');
p1=p1(length(p1));
fileName=path0(p1+1:length(path0));%file name without apendix
pathName=path0(1:p1-1);%path name
