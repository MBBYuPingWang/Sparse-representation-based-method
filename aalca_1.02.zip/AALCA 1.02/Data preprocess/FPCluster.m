function [sClusters]=FPCluster(A,nClusters,nSeed,minCorr,maxTry)
%this function clusters the columns of the input matrix A into nClusters
%according to the pearson correlations between each two nClumns.
%%%% inputs%%%%%%
%nSeed is the number to selected the center of each clusters
%minCorr specify the minimu corr of each trial
%maxTry specify the maximu time for the seletion of each trial
%%%%%%%%%%outputs%%%%%%%
% sClusters=struct('clusterIndex','SeedIndex','Num','meanCorr','Corr','Index');
%sClusters(i).clusterIndex specifies the order of this cluster
%sClusters(i).SeedIndex is the index of the column used as seed for this
%cluster
%sClusters(i).Num is the number of columns in this cluster
%sClusters(i).meanCorr is the mean of the Pearson correlation coefficients
%of the columns for within the cluster
% sClusters(i).Corr are the Pearson correlation coefficients between all the
% columns and the seed column
%sClusters(i).Index is the column indexs from A for the columns in this
%cluster
%sClusters were sorted according to its meanCorr in descend order


if nargin<3,
    nSeed=10;
end
if nargin<4,
    minCorr=0;
end
if nargin<5,
    maxTry=1;
end

%decide the clomumns to be found in each cluster
[Ar,Ac]=size(A);
nColumns=floor(Ac/nClusters);
%correct the nClusters
nClusters=ceil(Ac/nColumns);

sClusters=struct('clusterIndex',zeros(1),'SeedIndex',zeros(1),'Num',zeros(1),'meanCorr',zeros(1),'Corr',cell(nClusters,1),'Index',cell(nClusters,1));

indexA=1:Ac;%prepare the index for A
MC=zeros(nClusters,1);
clusIndex0=[];%the current indexes to be deleted
for i=1:nClusters
    
    if ~isempty(clusIndex0)%remove the selected clusters
       A(:,clusIndex0)=[];
       indexA(clusIndex0)=[];
    end
    
    for j=1:maxTry
        [sClusters(i).Corr,sClusters(i).Index,sClusters(i).Num,clusIndex0]=PCcluster1(A,indexA,nColumns,nSeed);   
        sClusters(i).meanCorr=mean(sClusters(i).Corr);
        if sClusters(i).meanCorr<minCorr
            continue;
        else
            break;
        end
    end
    sClusters(i).SeedIndex=sClusters(i).Index(1);
    MC(i)=sClusters(i).meanCorr;
    disp(sprintf('Got the cluster %d',i));
end
%sort the clusters accourding to the mean clusCorr in the order of descend 

[MC,IC]=sort(MC,'descend');
sClusters=sClusters(IC);

for i=1:nClusters
    sClusters(i).clusterIndex=i;
end

end
    
    
function [clusCorr,clusIndex,nColumns,clusIndex0]=PCcluster1(A,indexA,nColumns,seedNum)
%this function find nColumns columns from A that have the highest pearson correlation with the seedNum columns of A
%indexA contains the index of each column of A
%clusIndex0 contains the current index of the selected columns

if nargin<4
    seedNum=20;
end

Ac=size(A,2);
if Ac<=nColumns%there are not enough columns to be select
    nColumns=Ac;
    clusIndex=indexA;
    clusIndex0=1:Ac;
    clusCorr=corr(A(:,1),A(:,2:Ac));
    return;
end
    


%test if the data size is too large
lA=length(A(:));
nSep=1;
if lA>1e8%the data is too large
    nSep=ceil(lA/1e8);
end

[Ar,Ac]=size(A);
nSep=1;
stepNum=Ac;
if lA>1e8%the data is too large
    nSep=ceil(lA/1e8);
    stepNum=ceil(1e8/Ar);
end


% %get the seedNum columns of A
% firtC=NormolizeA(A(:,getRandomColumn(1,Ac,seedNum)));
% seedNum=size(firtC,2);

tempStep=ceil(Ac/seedNum);
firtC=A(:,1:tempStep:Ac);
firtC=NormolizeA(firtC);
seedNum=length(1:tempStep:Ac);

%prepare the pearson correlation vector
clusCorr=zeros(seedNum,Ac);

for i=1:nSep
    cStart=(i-1)*stepNum+1;
    cEnd=i*stepNum;
    if cEnd>Ac
        cEnd=Ac;
    end
    stepA=double(A(:,cStart:cEnd));%change the data the double
    stepA=NormolizeA(stepA);
%     sizeFirtC=size(firtC')
%     sizeStepA=size(stepA)
%     size(clusCorr(:,cStart:cEnd))
    clusCorr(:,cStart:cEnd)=firtC'*stepA;    
end

clear stepA;

% find the seed columns that have the hihest average corr
meanCorrs=mean(clusCorr,2);%get the means for each seed column
[meanCorrs,tempIndex]=sort(abs(meanCorrs),'descend');
clusCorr=clusCorr(tempIndex(1),:);%only take the highest one

%sort the clusCorr in descend order
[clusCorr,clusIndex]=sort(abs(clusCorr),'descend');
if nColumns>size(A,2),
    nColumns=size(A,2);
end    
clusCorr=clusCorr(1:nColumns);
clusIndex=clusIndex(1:nColumns);
clusIndex0=clusIndex;
%restore the index of origianl index
clusIndex=indexA(clusIndex);
end

    
    
function A=NormolizeA(A,beZMean,beColumn)
%this function normalize each column of A to have unit L2 norm
% if beColumn=0 specify if the normalization is to the comun or  row
% if beZMean=1, normalize each column to have zero means

A=double(A);

if  nargin<3
    beColumn=1;
end
if nargin<2
    beZMean=1;
end

if beColumn==0
    A=A'
end

[Ar,Ac]=size(A);
y=zeros(Ar,1);

for j=1:Ac  
    if beZMean==1
        A(:,j)=A(:,j)-mean(A(:,j));
    end
    nA=norm(A(:,j));
    if nA==0
        continue;
    end
    A(:,j)=A(:,j)/nA;
end


if beColumn==0
    A=A'
end

end

function cIndex=getRandomColumn(rlow,rup,nc)
% This function randomly select nc columns from [rlow,rup];
%the two ends will show up with same possiblity
%rlow and rup should be int

if nc<1
    cIndex=[];
    return;
end

if nc>rup-rlow
    cIndex=rlow:rup;
    return;
end

cIndex=zeros(1,nc);

nfound=0;
while 1
    tempIndex=ceil((rand(1))*(rup-rlow)+rlow-0.5);
    if tempIndex>rup
        tempIndex=rup;
    end
    
    if isempty(find(cIndex==tempIndex))
        nfound=nfound+1;
        if nfound>nc
            break;
        end
        cIndex(nfound)=tempIndex;
    end
end
    
end    
    
