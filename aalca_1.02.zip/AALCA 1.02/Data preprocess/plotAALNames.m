function plotAALNames()

lre=47;
figure(103);
plot(1:lre);
set(gca,'xtick',[],'yticklabel',[])
xTickLabels=getAALName();
size(xTickLabels)
YP=zeros(1,lre)-1;
XP=1:lre;

for i=1:lre
    hText = text(XP(i),YP(i), xTickLabels(i));
%     set(hText,'fontsize',8);
%     Rotate the text objects by 90 degrees
    set(hText,'Rotation',-30, 'fontsize',10,'fontweight','bold');
end

function AALName=getAALName()
AALName={
'Precentral'
'Frontal-Sup'
'Frontal-Sup-Orb'
'Frontal-Mid'
'Frontal-Mid-Orb'
'Frontal-Inf-Oper'
'Frontal-Inf-Tri'
'Frontal-Inf-Orb'
'Rolandic-Oper'
'Supp-Motor-Area'
'Olfactory'
'Frontal-Sup-Medial'
'Frontal-Mid-Orb'
'Rectus'
'Insula'
'Cingulum-Ant'
'Cingulum-Mid'
'Cingulum-Post'
'Hippocampus'
'ParaHippocampal'
'Amygdala'
'Calcarine'
'Cuneus'
'Lingual'
'Occipital-Sup'
'Occipital-Mid'
'Occipital-Inf'
'Fusiform'
'Postcentral'
'Parietal-Sup'
'Parietal-Inf'
'SupraMarginal'
'Angular'
'Precuneus'
'Paracentral-Lobule'
'Caudate'
'Putamen'
'Pallidum'
'Thalamus'
'Heschl'
'Temporal-Sup'
'Temporal-Pole-Sup'
'Temporal-Mid'
'Temporal-Pole-Mid'
'Temporal-Inf'
'Cerebellum'
'Vermis'
};

% 'Cerebellum_Crus1_L'
% 'Cerebelum_Crus2_L'
% 'Cerebelum_3_L'
% 'Cerebelum_4_5_L'
% 'Cerebelum_6_L'
% 'Cerebelum_7b_L'
% 'Cerebelum_8_L'
% 'Cerebelum_9_L'
% 'Cerebelum_10_L'
% 'Vermis_1_2'
% 'Vermis_3'
% 'Vermis_4_5'
% 'Vermis_6'
% 'Vermis_7'
% 'Vermis_8'
% 'Vermis_9'
% 'Vermis_10'
