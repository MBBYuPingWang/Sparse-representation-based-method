function testLocateTarget()
clc
close all;
% FilePath='C:\My Folder\MFISH database\test data_00\V1306XY.mat';
% FilePath='C:\My Folder\MFISH database\test data_01\V1306XY.mat';
% FilePath='C:\My Folder\MFISH database\test data_21\V240352.mat';
FilePath='C:\My Folder\MFISH database\test data_04\V1310XY.mat';
fpl=length(FilePath);
temp=sprintf('%d_U_C_G_IAFCM.mat',6);
lt=length(temp);
FilePath(fpl-3:fpl+lt-4)=temp
load(FilePath,'U','center','G','ImSize','n','r');
Id=find(center==max(center));
U=U(:,Id);

index=find(U>=0.5);
Im=zeros(ImSize);
Im(index)=U(index);


beDisp=1;
r=1;
mr=1;
[Im1,TgName,TgCenter]=LocateTarget(Im,beDisp,r,mr);

Area=TgCenter(:,3);
[A,idA]=sort(Area,'descend');
result=[A,idA]

