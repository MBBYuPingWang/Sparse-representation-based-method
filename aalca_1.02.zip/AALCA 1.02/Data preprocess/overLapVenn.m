function [regionName,pureA,PercentPureA,totalFeature]=overLapVenn(A,IA,totalN)
% this function calculate the total percentages in each region in a three
% circle Venn plot
%A=[a1,a2,a3] are the elements in the three circles
%IA=[ia12,ia13,ia23,ia123] for overlaps
%totalFeature is the number of features in A

if nargin<3,
    totalN=sum(A(:))-sum(IA(1:3))+IA(4);
end

%calculate the regions only have a1
oa1=A(1)-sum(IA(1:2))+IA(4);
%calculate the regions only have a2
oa2=A(2)-IA(1)-IA(3)+IA(4);
%calculate the regions only have a3
oa3=A(3)-IA(2)-IA(3)+IA(4);


%only have a12
oa12=IA(1)-IA(4);
%only have a13
oa13=IA(2)-IA(4);
%only have a23
oa23=IA(3)-IA(4);
%only have a123
oa123=IA(4);

regionName={'oa1','oa2','oa3','oa12','oa13','oa23','oa123'};
pureA=[oa1,oa2,oa3,oa12,oa13,oa23,oa123];
PercentPureA=pureA/totalN*100; 

totalFeature=sum(pureA);


