function Im1=ImDilation(Im,r)
%this function perform rx and ry times erosion along x and y axis respectively
Im1=Im;
nIm=size(Im,3);
for i=1:nIm
    Im1(:,:,i)=ImDilation0(Im(:,:,i),r);
end
end




function Im1=ImDilation0(Im,r)
%perform rx and ry times erosion along x and y axis respectively
if length(r)<1
    r=[1,1];
end
if length(r)<2
    r(1)=r;
    r(2)=r(1);
end

rx=r(1);
ry=r(2);
[Imr,Imc]=size(Im);
Im1=Im;
for i=rx+1:Imr-rx
    for j=ry+1:Imc-ry
        if Im(i,j)>0,
            continue;
        end 
        
        temp=Im(i-rx:i+rx,j);
        Id0=find(temp(:)>0);
        if isempty(Id0)==0 % there is zeros
            Im1(i,j)=max(temp(:));
            continue;
        end
        
        temp=Im(i,j-ry:j+ry);
        Id0=find(temp(:)>0);
        if isempty(Id0)==0 % there is zeros
            Im1(i,j)=max(temp(:));
            continue;
        end 
        
    end
end
end
        

