function [y,la,a,b]=FilterHP(fs,wp,ws,rp,rs,x,bePlotFilter)
%this function filter the data with a high pass fileter
%fs is the sample frequency
% wp and ws are the passband and stopband edge frequencies
% rp is signal loss in pass band (db)
% rs is signal attenuation in the stopband (db)
% bePlotFilter=1 plot the fileter

%%%%%%%%%%%%%%example for 0.08 hz high pass filter%%%%%%%%%%
% fs=0.5;
% wp=0.01;
% ws=0.001;
% rp=1;
% rs=20;
% bePlotFilter=1;
% x=rand(100,1);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
x=double(x);
if nargin<7
    bePlotFilter=1;
end
f0=fs/2;
[n,wn]=buttord(wp/f0,ws/f0,rp,rs,'z');
[b,a]=butter(n,wn,'high');

la=length(a);
[lx,xc]=size(x);
%conpensate the begining
coL=floor(3*la);
x1=zeros(lx+coL,xc);
x1(1:coL,:)=x(1:coL,:);
x1(coL+1:coL+lx,:)=x(:,:);

%filter x1
y=filter(b,a,x1);
%recover y
y=y(coL+1:coL+lx,:);

if bePlotFilter==1
[h,w]=freqz(b,a);
figure(100);
plot(w*fs/(2*pi),abs(h));
xlabel('Frequece(Hz)');
ylabel('Amplitude modification');
end
