function [fileName,nFile]=getAllFilesInFolder(fileDir)
%get all the files in folder fileDir
files=dir(fileDir);
NumFiles=length(files);

if NumFiles==0,
    fileName='';
    nFile=0;
    return;
end

fileName=cell(1,NumFiles);

nFile=0;
for i=1:NumFiles
    if files(i).isdir==1
        continue;
    end
        nFile=nFile+1;
        fileName{nFile}=files(i).name;
%     disp(childFolders(i));
end

if nFile==0,
    fileName='';
    nFile=0;
    return;
end

fileName=fileName(1:nFile);