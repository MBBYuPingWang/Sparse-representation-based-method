function [Im,TgName,TgCenter]=LocateTarget(Im,beDisp,r,mr)
%This function locate the targets in a binary image
%the targets should be '255', background be '0'
%r is the rang to the neighbers, within which to search same group
%mr is the morphology process range
% TgName is the group numbers
%TgCenter is the center coordinates and area of each target, 

if nargin<2,
    beDisp=0;
end
if nargin<3,
    r=1;
end

if nargin<4,
    mr=1;
end

%%%%%%%%Image erosion%%%%%%%
Im=ImErosion(Im,mr);

%%%%%%%% group each target%%%%%%%
indexT=find(Im>0);%index of targets
Im(indexT)=255;%the targets named from '1'
TgName=0;%the total number of targets found

[Imr,Imc]=size(Im);

beChange=1;
while beChange==1
    beChange=0;%the total change
    
    for i=r+1:Imr-r%suppose the targets not at the edge
        for j=r+1:Imc-r
               beChange1=0;%change of each pixel
           
            if Im(i,j)==0,%backgrounds 
                continue; 
            end
            if Im(i,j)<255,%grouped 
                continue; 
            end
            
            for ii=-r:r
                for jj=-r:r
                    if Im(i+ii,j+jj)<255&&Im(i+ii,j+jj)>0,%find neighbor than has benn grouped
                       Im(i,j)=Im(i+ii,j+jj);
                       beChange=1;
                       beChange1=1;
                       break;
                     end
                end
                if beChange1==1
                   break;
                end
            end%for ii=-r:r
            
            if Im(i,j)==255,%not find grouped targets
               TgName=TgName+1;
               Im(i,j)=TgName;
               beChange=1;
               continue;
            end
            
        end% for j=2:Imc-1
    end%for i=2:Imr-1
    
end%while beChange==1


%%%%%%%%%%%%%combine group%%%%%%%%%%%%%%%%%%
TgName0=TgName;
beChange0=1;

while beChange0==1
    beChange0=0;
for i=2:TgName0
    beChange=0;
    [idx,idy]=find(Im==i);
    index=find(Im==i);
    lid=length(index);
    
    for j=1:lid
        for ii=-r:r
            for jj=-r:r
                temp=Im(idx(j)+ii,idy(j)+jj);
                if temp<i&&temp>0,%find neighbor than smaller than this group
                    Im(index)=temp;
                    beChange=1; 
                    beChange0=1;
                    break;
                end
            end
            if beChange==1,
                break;
            end
        end
        if beChange==1,
           break;
        end
    end
end
end

%%%%%%%%%%rename the groups after combination%%%%%%%%%%%%%%
TgName=0;
for i=1:TgName0
    index=find(Im==i);
    if isempty(index)==0
        TgName=TgName+1;
        Im(index)=TgName;
    end
end

if TgName>255
    erro('Too many targets to be located!');
end

%%%%%%%% Find the center of each target%%%%%%%%%%%%

TgCenter=zeros(TgName,3);
for i=1:TgName
    [idx,idy]=find(Im==i);
    TgCenter(i,2)=mean(idx);%x center
    TgCenter(i,1)=mean(idy);%y center
    TgCenter(i,3)=length(idx);%area
end 

%%%%%%%%Image Dilation%%%%%%%
Im=ImDilation(Im,mr);

%%%%%%%disp the result%%%%%%%%
if beDisp==0, return; end
    
Im0=zeros(Imr,Imc)+255;
index=find(Im>0);
Im0(index)=Im(index);

figure;
imshow(Im0,[0,max(Im0(:))]);
str=sprintf('Total targets: %d',TgName);
title(str);
for i=1:TgName
    str=sprintf('%d',i);
    text(TgCenter(i,1),TgCenter(i,2),['\color{green}','\fontsize{12}','\bf',str]);
end 


    
    
        
                    
                 
    

    
 
       
            
            
                
    
    
    

