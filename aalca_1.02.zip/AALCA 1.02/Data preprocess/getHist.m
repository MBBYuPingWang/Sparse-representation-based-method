function [his,pHis,nHis]=getHist(elements,tplHist,beDisp,beShowTpl)
% This fucntion get the hist program for elemnets according to the template
% tplHist, which is a cell structure of nHis x1
%pHis is the percentage hist
%beDisp=1,2 or 3 to show the results in number of elements/percentage of elements in each tplHist
%cluster or both
%beShowTpl=1 or 0 decides if to disp the template or not

if nargin<4
    beShowTpl=0;
end
if nargin<3
    beDisp=0;
end

if beShowTpl==1
    nCluster=length(tplHist);
    tempN=zeros(nCluster,1);
    for i=1:nCluster
        tempN(i)=length(tplHist{i});
    end    
    figure;
    bar(tempN);
    title('Disp of number of elements in the template hist');
    xlabel('Clusters');
    ylabel('Number of elements');
end   


nHis=length(tplHist);
his=zeros(nHis,1);
pHis=zeros(nHis,1);
for i=1:nHis
    [str23,his(i),index3from1]=findCross(elements,tplHist{i});
    if his(i)>0
        pHis(i)=his(i)/length(tplHist{i})*100;
        elements(index3from1)=[];%remove the found elements
        if isempty(elements)
            break;
        end
    end
end

if beDisp==1
    figure;
    bar(his);
    title('Disp of hist');
    xlabel('Clusters');
    ylabel('Number of elements');
    
elseif beDisp==2    
    figure;
    bar(pHis);
    title('Disp of percentage hist');
    xlabel('Clusters');
    ylabel('Cluster percentage(%)');
    
elseif beDisp==3    
    figure;
    bar(his);
    title('Disp of hist');
    xlabel('Clusters');
    ylabel('Number of elements');
   
    figure;
    bar(pHis);
    title('Disp of percentage hist');
    xlabel('Clusters');
    ylabel('Cluster percentage(%)');    
end