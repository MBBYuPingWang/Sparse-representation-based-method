function testfilterLP()
clc
x=rand(100,1);

%test band pass filter

fs=0.5;
wp=[.01 .08];
ws=[.0001 .1];
rp=1;
rs=20;
bePlotFilter=1;
[y,la,a,b]=FilterBP(fs,wp,ws,rp,rs,x,bePlotFilter);

% fs=0.5;
% wp=0.08;
% ws=0.09;
% rp=1;
% rs=20;
% bePlotFilter=1;
% [y,la,a,b]=FilterLP(fs,wp,ws,rp,rs,x,bePlotFilter);


% fs=0.5;
% wp=0.01;
% ws=0.001;
% rp=1;
% rs=20;
% bePlotFilter=1;
% [y,la,a,b]=FilterHP(fs,wp,ws,rp,rs,x,bePlotFilter);

figure;
plot(x)
hold on;
plot(y,'red');



%test high pass
% fs=0.5;
% wp=0.01;
% ws=0.001;
% rp=1;
% rs=20;
% bePlotFilter=1;
% 
% 
% [y,la,a,b]=FilterHP(fs,wp,ws,rp,rs,x,bePlotFilter);
% 
% figure;
% plot(x)
% hold on;
% plot(y,'red');


%%%%%%%%%%%%test lowpass
% fs=0.5;
% wp=0.08;
% ws=0.09;
% rp=1;
% rs=20;
% bePlotFilter=1;
% [y,la,a,b]=FilterLP(fs,wp,ws,rp,rs,x,bePlotFilter);
% 
% figure;
% plot(x)
% hold on;
% plot(y,'red');

