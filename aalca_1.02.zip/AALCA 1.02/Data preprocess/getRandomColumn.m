function cIndex=getRandomColumn(rlow,rup,nc)
% This function randomly select nc columns from [rlow,rup];
%the two ends will show up with same possiblity
%rlow and rup should be int

if nc<1
    cIndex=[];
    return;
end

if nc>rup-rlow
    cIndex=rlow:rup;
    return;
end

cIndex=zeros(1,nc);

nfound=0;
while 1
    tempIndex=ceil((rand(1))*(rup-rlow)+rlow-0.5);
    if tempIndex>rup
        tempIndex=rup;
    end
    
    if isempty(find(cIndex==tempIndex))
        nfound=nfound+1;
        if nfound>nc
            break;
        end
        cIndex(nfound)=tempIndex;
    end
end
    
    