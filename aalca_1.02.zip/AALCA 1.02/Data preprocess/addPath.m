function [pathParent,pathGrad]=addPath()
%pathParent,pathGrad are the one level and two level upper root path
disp('The following pathes are added:');
%add the dirs undersame root dir
path0=pwd;
p1=find(path0=='\');
p1=p1(length(p1));
path0=path0(1:p1-1);
pathParent=path0;

str='\Data preprocess';
path=strcat(path0,str);
addpath(path);
disp(path);

str='\Data analysis';
path=strcat(path0,str);
addpath(path);
disp(path);
% str='\SRC clustering';
% path=strcat(path0,str);
% addpath(path);
% disp(path);
% % 
%add the dirs undersame one hihger level root dir
p1=find(path0=='\');
p1=p1(length(p1));
path0=path0(1:p1-1);

pathGrad=path0;

str='\work data';
path=strcat(path0,str);
addpath(path);
disp(path);

str='\programs for fMRI\xjview8';
path=strcat(path0,str);
addpath(path);
disp(path);

str='\programs for fMRI\spm8';
path=strcat(path0,str);
addpath(path);
disp(path);

str='\programs for fMRI\wfu_pickatlas';
path=strcat(path0,str);
addpath(path);
disp(path);

str='\programs for fMRI\conn';
path=strcat(path0,str);
addpath(path);
disp(path);




