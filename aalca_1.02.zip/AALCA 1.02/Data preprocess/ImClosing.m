function Im=ImClosing(Im,r)
% opening is the erosion of the dilation of image Im
% used to remove the high frequecy noises in the target

Im=ImDilation(Im,r);
Im=ImErosion(Im,r);
