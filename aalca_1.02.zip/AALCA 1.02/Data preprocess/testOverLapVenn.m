function testOverLapVenn()
clc

nClusters=117;
p=4.7e-3;

% %for feature ananlysis
% A =[1437 560 9];
% IA = [429 7 0  0];
% totalN=nClusters*(nClusters+1)/2
% [regionName,pureA,PercentPureA,totalFeature]=overLapVenn(A,IA,totalN)

%for brain regions analysis
A =[100 105 11];
IA = [94 10 10 10];
totalN=nClusters
[regionName,pureA,PercentPureA,totalFeature]=overLapVenn(A,IA,totalN)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% nClusters=400;
% p=0.001;
% 
% % %for feature ananlysis
% % A =[7159        1715         59];
% % IA = [984 32 0  0];
% % totalN=nClusters*(nClusters+1)/2
% % [regionName,pureA,PercentPureA,totalFeature]=overLapVenn(A,IA,totalN)
% 
% %for brain regions analysis
% A =[305 297 52];
% IA = [242 45 39 35];
% totalN=nClusters
% [regionName,pureA,PercentPureA,totalFeature]=overLapVenn(A,IA,totalN)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% nClusters=1000;
% p=8.8e-5;

% % % features selected
% A =[7402        1324          23];
% IA = [434     9     0     0];
% totalN=nClusters*(1+nClusters)/2
% [regionName,pureA,PercentPureA]=overLapVenn(A,IA,totalN)

% % % networks selected
% A =[579   405    30];
% IA = [305    28     9     9];
% totalN=nClusters;
% [regionName,pureA,PercentPureA]=overLapVenn(A,IA,totalN)
% 
% %compare intra networks
% A =[67    38     0];
% IA = [18     0     0     0];
% totalN=nClusters;
% [regionName,pureA,PercentPureA]=overLapVenn(A,IA,totalN)

%for p=4.93e-4
% %compare  networks
% A =[773   723   192];
% IA = [614   184   140   138];
% totalN=nClusters;
% [regionName,pureA,PercentPureA]=overLapVenn(A,IA,totalN)

% %compare  networks
% A =[22392        4806         244];
% IA = [2255         139           1           0];
% totalN=nClusters;
% [regionName,pureA,PercentPureA]=overLapVenn(A,IA,totalN)




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% nClusters=116;
% p=4.8e-3;
% % features selected
% A =[1147         522           2]
% IA =[ 319     2     0     0]
% totalN=nClusters*(1+nClusters)/2
% [regionName,pureA,PercentPureA]=overLapVenn(A,IA,totalN)

% %regions selected
% A =[91   100     3];
% IA =[ 81     3     3     3];
% totalN=nClusters
% [regionName,pureA,PercentPureA]=overLapVenn(A,IA,totalN)

  
% %intra network selected
% A =[35    32     0]
% IA = [25     0     0     0]
% totalN=nClusters
% [regionName,pureA,PercentPureA]=overLapVenn(A,IA,totalN)