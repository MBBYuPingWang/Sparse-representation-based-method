function testGetHist()

clc
close all;

[pathParent,pathGrad]=addPath();
nClusters=116
path=strcat(pathGrad,sprintf('\\work data\\aal_clusters_%d.mat',nClusters))
load(path,'sClusters','nClusters','aalHist');
% 
% sClusters(1)
% sClusters(3)
% 
% aalHist=cell(nClusters,1);
% for i=1:nClusters
%     aalHist{i}=sClusters(i).Index;
% end
% 
% save(path,'sClusters','nClusters','aalHist');

ele=1:10:10000;
[his,pHis,nHis]=getHist(ele,aalHist,1);
nHis=nHis

