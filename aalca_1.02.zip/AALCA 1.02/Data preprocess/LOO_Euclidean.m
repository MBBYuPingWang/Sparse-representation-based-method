function [cr,classLabel,nSubj]=LOO_Euclidean(A,nAc,beShow)
%this function perform leave one out cross validation for the data given by
%A; A should be a cell matrix, each cell contains data for each class
%for Ai=A{i}, row of Ai are the subjects/samples, colomus of Ai are the
%variables/features
%nAc is the number of features/columns to be used for the cross validation
%the classifier is using mahattan distance
%beShow indicate if to prensen the classification results in figure

if nargin<2
    nAc=size(A{1},2);
end
if nargin<3
    beShow=0;
end

nClass=length(A); %the number of classes to be identified
%get the template according to which we perferm the classification
templates=zeros(nClass,nAc);
nSubj=0;%the number of subjects
for i=1:nClass
    A{i}=A{i}(:,1:nAc);
    nSubj=nSubj+size(A{i},1);
    templates(i,:)=mean(A{i});    
end

% back up the template
templates0=templates;
A0=A;
L2NormErro=zeros(nClass,1);%used for the L2 Norm error of the current subject
classLabel=zeros(nSubj,1);%1 for correct, 0 for incorrect
nSubj=0;
for i=1:nClass %process one class by one class
    Ai=A{i};%get the data of the current class
    [Air,Aic]=size(Ai);%[number of subjects,number of samples]
    for ai=1:Air %prprocess one subject at a time
        nSubj=nSubj+1;
%         restore the template
            templates=templates0;
%         get the data for current subject
          tempi=Ai(ai,:);
%         mordify the templates to exclude the current subject
          templates(i,:)=(Air*templates(i,:)-tempi)/(Air-1);
          Errors=templates-ones(nClass,1)*tempi;
          for j=1:nClass
              L2NormErro(j)=norm(Errors(j,:));
          end
          %assign the class for this subject
         tempClass=(find(L2NormErro==min(L2NormErro)));
         tempClass=tempClass(1);
         %plot the comparison results
         if beShow
              plotRows([templates;tempi]);  
              title(sprintf('Class:%d, identified as class:',i,tempClass));
          end 
         if tempClass==i
             classLabel(nSubj)=1;
         else
             classLabel(nSubj)=0; 
         end
    end
end
 
cr=sum(classLabel)/length(classLabel)*100;

end

function plotRows(A,colors)
%this function plot each row of A into a same figure
if nargin<2,
    colors=['r','g','b','c','m','y','k'];
end
lr=length(colors);

[Ar,Ac]=size(A);

for i=1:Ar
    figure(110);
    plot(A(i,:),colors(mod(i,lr)));
    hold on;
end
hold off;
end

  
          
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        