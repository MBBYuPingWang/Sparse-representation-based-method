function testGetGaussianKernel()

clc
close all;

[pathParent,pathGrad]=addPath();

% fileName='mask_aal.img';
% fileName=strcat('r',fileName)
% savePath=strcat(pathParent,'\Data analysis\brain masks\',fileName)
% fid=fopen(savePath);
% tempData=zeros(61,73,61,'uint8');
% tempData(:)=fread(fid,inf,'uint8');
% fclose all;

fileName='wrab02_fmri_006.img';
savePath=strcat(pathGrad,'\All data\data1\b02\resting_fMRI\',fileName)
fid=fopen(savePath);
tempData=zeros(61,73,61,'int16');
tempData(:)=fread(fid,inf,'int16');
fclose all; 


fwhm=2; 
dims=3;
[h,s,dimsValue] = getGaussianKernel(fwhm,dims) 
tempData1=imfilter(tempData,h,'same');

for i=10:15:50
    Im=tempData(:,:,i);
    figure;
    imagesc(Im);
    
    Im=tempData1(:,:,i);
    figure;    
    imagesc(Im)    
end 
 
 


fwhm=2;
dims=2;
[h,s,dimsValue] = getGaussianKernel(fwhm,dims) 
lk=dimsValue(1);
h1 = fspecial('gaussian',[2*lk+1,2*lk+1],s)


size(h)
lk=2*lk+1;
x=1:lk;
y=1:lk;
mesh(x,y,h(:,:,1)); 
  

Im0=floor(rand(30,30,20)*100);  
Im1 = imfilter(Im0,h,'full'); 
size(Im1)

Im2= imfilter(Im0,h,'same'); 
size(Im2)

figure;
image(Im0(:,:,1));
figure;
image(Im2(:,:,1));
figure;
image(Im0(:,:,1)-Im2(:,:,1));