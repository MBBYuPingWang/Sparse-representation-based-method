function index1=resizeIndex1to2(index0,dims)
% This funciton change the one dimension indexs to two diming indexs
% according to dims=[dr,dc]
index0=double(index0);
dims=double(dims);
lid0=length(index0);
index1=zeros(lid0,2);
dr=dims(1);

for i=1:lid0
%   find the column label
index1(i,2)=ceil(index0(i)/dr);

%find the row label;
index1(i,1)=index0(i)-(index1(i,2)-1)*dr;
if index1(i,1)==0
    index1(i,1)=dr;
end

%test if out of the boundary
if index1(i,1)>dims(1)||index1(i,2)>dims(2)    
    woringIndex1=index0(i)
    woringIndex2=index1(i,:)
    correctDim=dims
    error('something is wrong in function resizeIndex1to2()!');    
end

end

