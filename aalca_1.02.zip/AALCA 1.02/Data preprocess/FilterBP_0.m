function [y,la,a,b]=FilterBP(fs,wp,ws,rp,rs,x,bePlotFilter)
%this function filter the data with a band pass fileter
%fs is the sample frequency
% wp and ws are the passband and stopband edge frequencies
%example Bandpass:   Wp = [.01 .08], Ws = [.001 .1]
% rp is signal loss in pass band (db)
% rs is signal attenuation in the stopband (db)
% bePlotFilter=1 plot the fileter

%%%%%%%%%%%%%%example for 0.08 hz band pass filter%%%%%%%%%%
% fs=0.5;
% wp=[.01 .08];
% ws=[.001 .1];
% rp=1;
% rs=20;
% bePlotFilter=1;
% x=rand(100,1);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
x=double(x);
if nargin<7
    bePlotFilter=0;
end
f0=fs/2;
[n,wn]=buttord(wp/f0,ws/f0,rp,rs,'z');
[b,a]=butter(n,wn);

la=length(a);
[lx,xc]=size(x);
%conpensate the begining
coL=floor(la);
x1=zeros(lx+coL,xc);
x1(1:coL,:)=x(1:coL,:);
x1(coL+1:coL+lx,:)=x(:,:);

%filter x1
y=filter(b,a,x1);
%recover y
y=y(coL+1:coL+lx,:);

%plot the filter results
if bePlotFilter==1
[h,w]=freqz(b,a);
figure(100);
plot(w*fs/(2*pi),abs(h));
xlabel('Frequece(Hz)');
ylabel('Amplitude modification');
end
