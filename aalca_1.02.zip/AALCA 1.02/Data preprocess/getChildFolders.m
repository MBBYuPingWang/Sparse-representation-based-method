function [folderName, nFolder]=getChildFolders(fileDir)
%get the child folders
childFolders=dir(fileDir);
NumChildFolders=length(childFolders);

if NumChildFolders==0
    folderName='';
    nFolder=0;
    return;
end

folderName=cell(1,NumChildFolders);
nFolder=0;

for i=1:NumChildFolders
    if childFolders(i).isdir==0||strcmp(childFolders(i).name,'.')||strcmp(childFolders(i).name,'..')
        continue;
    end
    nFolder=nFolder+1;
    folderName{nFolder}=childFolders(i).name;

%     disp(childFolders(i));
end
if nFolder==0
    folderName='';
    nFolder=0;
    return;
end
folderName=folderName(1:nFolder);

