function [d3,indexFromD1,indexFromD2]=findRowCross(d1,d2,columnRang)
% Thisfunction compares two matrxi according to specified columns
%the columns in d1 and d2 are supposed to be non-reapted
if nargin<3,
    columnRang=1:size(d1,2);
end

lc=length(columnRang);
ntemp=0;
d3=zeros(max(size(d1,1),size(d2,1)),size(d1,2));
indexFromD1=zeros(max(size(d1,1),size(d2,1)),1);
indexFromD2=indexFromD1;
for i=1:size(d1,1)
    for j=1:size(d2,1)
        beGood=1;
        for k=1:lc
            if d1(i,columnRang(k))~=d2(j,columnRang(k)),
                beGood=0;
                break; 
            end
        end
        if beGood==0,break;end
            ntemp=ntemp+1;
            d3(ntemp,:)=d1(i,:);
            indexFromD1(ntemp)=i;
            indexFromD2(ntemp)=j;
            break;
    end
end

if ntemp==0
    d3=[];
    indexFromD1=[];
    indexFromD2=[];
    return;
end
d3=d3(1:ntemp,:);
indexFromD1=indexFromD1(1:ntemp,:);
indexFromD2=indexFromD2(1:ntemp,:);