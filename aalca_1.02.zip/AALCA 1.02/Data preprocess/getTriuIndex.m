function [indexTriu,lindexTriu]=getTriuIndex(d1,d2) 
%get the index for the upper triangular part of a matrix in dimesion d1*d2

lindexTriu=d2*(d2+1)/2;
indexTriu=zeros(lindexTriu,1);

ld=0;
for j=1:d2    
    indexTriu(ld+1:ld+j)=(j-1)*d1+1:(j-1)*d1+j;
    ld=ld+j;
end
