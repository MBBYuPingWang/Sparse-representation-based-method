function [krn,s,dimsValue] = getGaussianKernel(fwhm,dims,dimsValue)
% Generate a 3 dimension Gaussian smoothing kernel
%dims=1,2 or 3 for one, two or three dimension kernel
%dimsValue=[dx,dy,dx]
%fwhm is the full width of half maximaum value

% std from FWHM
s = fwhm/sqrt(8*log(2))+eps;
if nargin<3,
    dimsValue=zeros(1,dims);
    dimsValue=dimsValue+ceil(s*3);
end

if dims==1
    [krn,s] = getGaussianKernel1(dimsValue,s);
    return;
elseif dims==2
    [krn,s] = getGaussianKernel2(dimsValue,s);
    return;
elseif dims==3
    [krn,s] = getGaussianKernel3(dimsValue,s);
    return;
else
    error('Dimension of the kern should <3');
end

end


function [krn,s] = getGaussianKernel1(dims,s)
% Generate a 1 dimension Gaussian smoothing kernel
%dimsValue=[dx]
%s is the std of the kernel

dx=dims(1);
krn=zeros(2*dx+1,1);

for i=-dx:dx
  krn(i+dx+1)=getGaussianKernel0([i],s^2);
end
sumKrn=sum(krn(:));
krn=krn/sumKrn;
end

function [krn,s] = getGaussianKernel2(dims,s)
% Generate a 2 dimension Gaussian smoothing kernel
%dimsValue=[dx,dy]
%s is the std of the kernel

dx=dims(1);
dy=dims(2);
krn=zeros(2*dx+1,2*dy+1);

for i=-dx:dx
    for j=-dy:dy
            krn(i+dx+1,j+dy+1)=getGaussianKernel0([i,j],s^2);
    end
end
sumKrn=sum(krn(:));
krn=krn/sumKrn;

end


function [krn,s] = getGaussianKernel3(dims,s)
% Generate a 3 dimension Gaussian smoothing kernel
%dims=[dx,dy,dz]
%s is the std of the kernel

dx=dims(1);
dy=dims(2);
dz=dims(3);
krn=zeros(2*dx+1,2*dy+1,2*dz+1);

for i=-dx:dx
    for j=-dy:dy
        for k=-dz:dz
            krn(i+dx+1,j+dy+1,k+dz+1)=getGaussianKernel0([i,j,k],s^2);
        end
    end
end
sumKrn=sum(krn(:));
krn=krn/sumKrn;
end



function krn=getGaussianKernel0(x,s)
    krn = (1/sqrt(2*pi*s))*exp(-sum(x.^2)/(2*s));
end





