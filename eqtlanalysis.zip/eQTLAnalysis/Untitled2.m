close all;
a=rand(50,60)*1e-5;
figure;
imagesc(a);
colorbar;
ylabel('Index of SNPs');
xlabel('Index of expressions');

b=a;
b(b>1e-6)=1;
figure;
imagesc(b);
colorbar;
ylabel('Index of SNPs');
xlabel('Index of expressions');
