function [str,maxColumn]=splitStr(str0,separateMarker,beRemoveSpace)
%this funciton split (e.g. '|' or '/' , '\' or space separated)  strings into separate
%ones, which will be saved in a cell array 'str'
%str0 should be a cell matrix containing strings in each cell
%nStr=length(str)
%beRemoveSpace specify if remove the sapce within str0 
% str0 is in cell form
%maxColumn is the max number of sub-strings separated from a single string

if nargin<3,
    beRemoveSpace=1;
end
if nargin<2,
    separateMarker={ '|', '/' , '\'};
end

lstr0=length(str0);
str=cell(lstr0,100);
maxColumn=0;
for i=1:lstr0
    [tempStr,nTempStr]=splitOneStr(str0(i),separateMarker,beRemoveSpace);
    if maxColumn<nTempStr,maxColumn=nTempStr; end
    
    for j=1:nTempStr
        str(i,j)=tempStr(j);
    end
end
str=str(:,1:maxColumn);

function [str,nStr]=splitOneStr(str0,separateMarker,beRemoveSpace)

% %%an example
% str0={'asdf | asdfasdf  /rrwer \sdfasdgf'};
% separateMarker={ '|', '/' , '\'};
% beRemoveSpace=1;

str1=str0;
str0=str0{1};

lsm=length(separateMarker);
%add '$' into separaterMarker
separateMarker(lsm+1)={'$'};

%test is separateMarker include space

for i=1:lsm,
    if separateMarker{i}==' ',
        beRemoveSpace=0;
        break;
    end
end

if isempty(str0),
    str=str1;
    nStr=1;
    return;
end


if beRemoveSpace~=0,%space is not a seperator
    str0(str0==' ')=[];%remove the sapce
end

str0=strcat(str0,'$');
breakIndex=[];
for i=1:length(separateMarker),
    tempIndex=find(str0==separateMarker{i});
    if isempty(tempIndex), continue; end
    breakIndex=[breakIndex,tempIndex];
end
breakIndex=sort(unique(breakIndex));

if breakIndex(1)==1, %this breaker is before any character
    breakIndex(1)=[];
    str0(1)=[];%remove this breaker from the string
    breakIndex=breakIndex-1;
end

lbreak=length(breakIndex);%no character but the breakers in the string
if lbreak<1,
    str={''};
    nStr=0;
    return;
end

lstr0=length(str0);
str=cell(1,lbreak);
nStr=0;
pStart=1;
for i=1:lbreak
    if pStart>lstr0,break; end
    
    pEnd=breakIndex(i)-1;
    if pEnd<pStart,
        continue;
    end
    nStr=nStr+1;
    str{i}=str0(pStart:pEnd);
    pStart=pEnd+2;
end

%remove empty entries and any entries that is the same as separateMarker
indexBad=[];
nBad=0;
nStr=length(str);
for i=1:nStr
    if isempty(str{i})||ismember(str(i),separateMarker)
        nBad=nBad+1;
        indexBad(nBad)=i;
    end
end
str(indexBad)=[];
nStr=nStr-nBad;

%if using space as seperater, remove the sapce in each string
if ~ismember({' '},separateMarker),return; end

for i=1:nStr
    str{i}(str{i}==' ')=[];
end
    
    
    
    
