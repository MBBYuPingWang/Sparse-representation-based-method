function [geneName,geneIndex]=getGeneName4SNP(workPath,SNPName)
%this function get the gene name for the given SNPs
%load the corr result
savePath=strcat(workPath,'SNP_Gene_Map.mat');
load(savePath,'SNPName0','SNP_GeneName0');

%locate the position in map file
[SNPName1,indexFromb,geneIndex]=findCross2(SNPName,SNPName0);
geneName=SNP_GeneName0(indexFromb,:);

% [SNPName1,geneIndex]=findCross2(SNPName1,SNPName);

