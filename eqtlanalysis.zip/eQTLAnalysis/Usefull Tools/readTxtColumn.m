function [txtData,nRows,nColumns]=readTxtColumn(filePath,columnIndex,showStep,delimiter,nRow2Read)
%this function read the sepcific columns from the txt file speicifed by
%filePath.
%columnIndex refers to the index of columns to be read
%showStep specify if show the process of each line
%delimiter show what's the seperate each columns
%nRow specify how many number of rows to read

if nargin<5,
    nRow2Read=inf;
end
if nargin<4,
    delimiter={' ','	'};
end
if nargin<3,
    showStep=0;
end
if nargin<2, 
    columnIndex=[];
end  
 
fid=fopen(filePath);
tline = fgetl(fid);%read line by line    
[str]=splitStr({tline},delimiter);
str=splitStr(str,{'"'});
nColumns=length(str);%the number of columns
fclose(fid); 
if isempty(columnIndex),
    txtData=cell(10^5,nColumns);
else
    txtData=cell(10^5,length(columnIndex));
end 

fid=fopen(filePath); 
nRows=0;
nLine=0;
while ~feof(fid)
    nLine=nLine+1;   
    tline = fgetl(fid);%read line by line   
    %show the process
    if showStep,
        disp(nLine);
%         disp(tline);
    end
 
    if ~ischar(tline)||nLine>=nRow2Read, 
        disp('Reading finished !'); 
        break, 
    end    
    [str,maxColumn]=splitStr({tline},delimiter);
    
    if maxColumn<nColumns,
        disp('There is not enough columns in this line');
        continue;
    end
%     str=splitStr(str,{'"'});%remove possible '"' in the str
%     tt=str{1} 
    nRows=nRows+1;

    if isempty(columnIndex),
        txtData(nRows,:)=str;
    else
        txtData(nRows,:)=str(columnIndex);
    end
end
if nRows>0,
txtData=txtData(1:nRows,:);
end