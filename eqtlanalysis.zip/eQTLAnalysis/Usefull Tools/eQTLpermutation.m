function [Pvalue,minP]=eQTLpermutation(SNPVector,expressionVector,comparePvalue,nRun)
%This funciton perform permutation test using for the SNPVector and expressionVector
%expressionVector and SNPVector should be two vectors
%comparePvalue is the p-value for which the pumutation is tested
%nRun is the number of test
%Pvalue is the permutation p value
%minP is the minimum correlation p value acquired during the permutation

nRun=ceil(nRun^0.5);
[nr,nc]=size(expressionVector);
if nc>nr,%row vector, change to column vector
    expressionVector=expressionVector';
end
[nr,nc]=size(SNPVector);
if nc>nr,%row vector, change to column vector
    SNPVector=SNPVector';
end


nSample=length(expressionVector);%the number of samples

%get the SNP matrix for the permutation
SNPMatrix=getShuffledMatrix(SNPVector,nRun,nSample);

%get the expression matrix for the permutation
expressionMatrix=getShuffledMatrix(expressionVector,nRun,nSample);


%get the corr p-value matrix
[corrv,corrP]=corr(SNPMatrix,expressionMatrix);
clear corrv;
Pvalue=length(find(corrP(:)<=comparePvalue))/nRun^2;
minP=min(corrP(:));

function matrix=getShuffledMatrix(vector,nRun,nSample)
%set the matrix using Fisher-Yates Shuffle method
[nr,nc]=size(vector);
if nc<nr,%column vector, change to row vector
    vector=vector';
end

matrix=zeros(nSample,nRun);
for i=1:nRun
    matrix(:,i)=FisherYatesShuffle(vector)';
end        
    
