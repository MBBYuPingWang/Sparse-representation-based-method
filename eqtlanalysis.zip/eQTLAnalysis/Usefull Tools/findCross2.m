function [c,indexFroma,indexFromb,lc]=findCross2(a,b)
%this function find the cross of a and b, where a and b should all be
%unique number array or cell array
%c are the cross elements found in b
%indexFromb contains the index of c in b
%lc is the length of c
%indexFroma contains the index of c in a

[c,indexFromb]=ismember(a,b);
indexFromb(indexFromb==0)=[];
c_b=b(indexFromb);
lc=length(c_b);
indexFroma=find(c>0);
c=a(indexFroma);






