function beCis=judgeTrans_Cis_eQTL(SNP_chr,SNP_pos,expGene_chr,expGene_posS,expGene_posE,shreholdRange)
%this function judge the trans of cis of an eQTL

if nargin<6,
    shreholdRange=5e5;
end

nTest=length(SNP_chr);

beCis=zeros(nTest,1,'uint8');

for i=1:nTest,
    if SNP_chr(i)~=expGene_chr(i),%on different chrom
        continue;
    end
    
    if expGene_posS(i)-SNP_pos(i)>shreholdRange||SNP_pos(i)-expGene_posE(i)>shreholdRange
        continue;
    end
    beCis(i)=1;
end



