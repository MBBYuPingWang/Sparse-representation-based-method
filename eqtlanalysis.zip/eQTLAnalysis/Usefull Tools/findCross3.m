function [c_b,indexFromb,lc,c_a,indexFroma]=findCross3(a,b)
%this function find the cross of a and b, where a and b should all be
%unique number array or cell array
%c_b are the cross elements found in b
%indexFromb contains the index of c_b in b
%lc is the length of c_b
%c_a are the cross elements from a, which contains the same elements set as
%c_b but in different order
%indexFroma contains the index of c_a in a

[c,indexFromb]=ismember(a,b);
indexFromb(indexFromb==0)=[];
lf=length(indexFromb);
indexFromb=unique(indexFromb);
lf1=length(indexFromb);
if lf1~=lf, 
    warning('The elements in first matrix is not unique!');
end
c_b=b(indexFromb);
lc=length(c_b);

if nargout<3,
    return;
end

[c,indexFroma]=ismember(b,a);
indexFroma(indexFroma==0)=[];
lf=length(indexFroma);
indexFroma=unique(indexFroma);
lf1=length(indexFroma);
if lf1~=lf, 
    warning('The elements in second matrix is not unique!');
end
c_a=a(indexFroma);
lc=length(c_a);




