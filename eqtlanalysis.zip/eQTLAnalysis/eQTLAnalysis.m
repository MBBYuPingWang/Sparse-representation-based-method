function varargout = eQTLAnalysis(varargin)
% EQTLANALYSIS M-file for eQTLAnalysis.fig
%      EQTLANALYSIS, by itself, creates a new EQTLANALYSIS or raises the existing
%      singleton*.
%
%      H = EQTLANALYSIS returns the handle to a new EQTLANALYSIS or the handle to
%      the existing singleton*.
%
%      EQTLANALYSIS('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in EQTLANALYSIS.M with the given input arguments.
%
%      EQTLANALYSIS('Property','Value',...) creates a new EQTLANALYSIS or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before eQTLAnalysis_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to eQTLAnalysis_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help eQTLAnalysis

% Last Modified by GUIDE v2.5 19-Feb-2015 16:18:05

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @eQTLAnalysis_OpeningFcn, ...
                   'gui_OutputFcn',  @eQTLAnalysis_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before eQTLAnalysis is made visible.
function eQTLAnalysis_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to eQTLAnalysis (see VARARGIN)
clc
% Choose default command line output for eQTLAnalysis
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

%add some work path 
currentDir=pwd;
[parentDir,grandDir]=addPath();

%save the directions
setappdata(handles.dlg_eQTLAnalysis_main,'currentDir',currentDir);
setappdata(handles.dlg_eQTLAnalysis_main,'parentDir',parentDir);
setappdata(handles.dlg_eQTLAnalysis_main,'grandDir',grandDir);
setappdata(handles.dlg_eQTLAnalysis_main,'criticalP',0.00001);
setappdata(handles.dlg_eQTLAnalysis_main,'criticalQ',0.05);
setappdata(handles.dlg_eQTLAnalysis_main,'permutationN',10000);

parentDir=getappdata(handles.dlg_eQTLAnalysis_main,'parentDir');
workPath=strcat(parentDir,'\work data\');

%%%%%%%%%%%%%%%%%copy default source data into the work path%%%%%%%%%%%%%%%
%copy the SNP data into the work path
sourceFilePath=strcat(workPath,'Source Data\SNP_data.mat');
destiFilePath=strcat(workPath,'SNP_data.mat');
[copySucess1]=copyfile(sourceFilePath,destiFilePath);

%copy the expression data into the work path
sourceFilePath=strcat(workPath,'Source Data\expressionData.mat');
destiFilePath=strcat(workPath,'expressionData.mat');
[copySucess2]=copyfile(sourceFilePath,destiFilePath);


if copySucess1&&copySucess2,
    disp('==================================');
    disp('All available data is the current source data!');
else
    disp('==================================');
    error('Source data cannot be moved to work path!');
end

% UIWAIT makes eQTLAnalysis wait for user response (see UIRESUME)
% uiwait(handles.dlg_eQTLAnalysis_main);


% --- Outputs from this function are returned to the command line.
function varargout = eQTLAnalysis_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --------------------------------------------------------------------
function Menu_getTargetSNPs_Callback(hObject, eventdata, handles)
parentDir=getappdata(handles.dlg_eQTLAnalysis_main,'parentDir');
    [filename, pathname, filterindex] = uigetfile(  { '*.*','MAT-files (*.mat)';}, ...
        'Pick CFM files',...
        'MultiSelect', 'off',...
    strcat(parentDir,'\work data\'));
    
workPath=strcat(parentDir,'\work data\');
if filename~=0
%     creatTargetSNPData(pathname,filename,workPath);
%     getCorr_SNP_expression(workPath);
%     analyzeCorr(workPath,1e-4,0.05);
    performPermutation(workPath,10000)
end



function edit_P_Callback(hObject, eventdata, handles)
%get the current value of the bar
val=str2num(get(hObject,'string'));
setappdata(handles.dlg_eQTLAnalysis_main,'criticalP',val);


% --- Executes during object creation, after setting all properties.
function edit_P_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_P (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_Q_Callback(hObject, eventdata, handles)
%get the current value of the bar
val=str2num(get(hObject,'string'));
setappdata(handles.dlg_eQTLAnalysis_main,'criticalQ',val);


% --- Executes during object creation, after setting all properties.
function edit_Q_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_Q (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_PermuteN_Callback(hObject, eventdata, handles)
%get the current value of the bar
val=str2num(get(hObject,'string'));
setappdata(handles.dlg_eQTLAnalysis_main,'permutationN',val);


% --- Executes during object creation, after setting all properties.
function edit_PermuteN_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_PermuteN (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
parentDir=getappdata(handles.dlg_eQTLAnalysis_main,'parentDir');
    [filename, pathname, filterindex] = uigetfile(  { '*.*','MAT-files (*.mat)';}, ...
        'Pick CFM files',...
        'MultiSelect', 'off',...
    strcat(parentDir,'\work data\'));
    
workPath=strcat(parentDir,'\work data\');
if filename~=0
    clc
    %Preparing data
    disp('--------------------------');
    disp('Loading target SNP data, please wait...');
    creatTargetSNPData(pathname,filename,workPath);
    
    %eQTL analyzing
    disp('--------------------------');
    disp('Generating eQTL map, please wait...');
    getCorr_SNP_expression(workPath);
    
end


% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
close(handles.dlg_eQTLAnalysis_main);


% --- Executes on button press in pushbutton_report.
function pushbutton_report_Callback(hObject, eventdata, handles)
clc
parentDir=getappdata(handles.dlg_eQTLAnalysis_main,'parentDir');
workPath=strcat(parentDir,'\work data\');
    
    %generate report for the whole process
    disp('--------------------------');
    disp('Generating report for the eQTL analysis, please wait...');
    filePath=generateReport(workPath);
    
    


% --- Executes on button press in pushbutton_Permutation.
function pushbutton_Permutation_Callback(hObject, eventdata, handles)
parentDir=getappdata(handles.dlg_eQTLAnalysis_main,'parentDir');
workPath=strcat(parentDir,'\work data\');
 %Search for significant SNPs
    disp('--------------------------');
    disp('Searching for significant eQTLs, please wait...');
    criticalP=getappdata(handles.dlg_eQTLAnalysis_main,'criticalP');
    criticalQ=getappdata(handles.dlg_eQTLAnalysis_main,'criticalQ');
    analyzeCorr(workPath,criticalP,criticalQ);
    
    %perform the permuation
    disp('--------------------------');
    disp('Performing the purmuation, please wait...');
    permutationN=getappdata(handles.dlg_eQTLAnalysis_main,'permutationN');
    performPermutation(workPath,permutationN);


% --- Executes on button press in radiobutton_Fetus.
function radiobutton_Fetus_Callback(hObject, eventdata, handles)

val=get(hObject,'Value');
if val==0,
    return;
end

parentDir=getappdata(handles.dlg_eQTLAnalysis_main,'parentDir');
workPath=strcat(parentDir,'\work data\');

%copy the Fetus SNP data into the work path
sourceFilePath=strcat(workPath,'Source Data\SNP_data_Fetus.mat');
destiFilePath=strcat(workPath,'SNP_data.mat');
[copySucess1]=copyfile(sourceFilePath,destiFilePath);

%copy the Fetus expression data into the work path
sourceFilePath=strcat(workPath,'Source Data\expressionData_Fetus.mat');
destiFilePath=strcat(workPath,'expressionData.mat');
[copySucess2]=copyfile(sourceFilePath,destiFilePath);


if copySucess1&&copySucess2,
    disp('==================================');
    disp('The Fetus data is the current source data!');
else
    disp('==================================');
    error('Source data cannot be moved to work path!');
end


% --- Executes on button press in radiobutton_Non_Fetus.
function radiobutton_Non_Fetus_Callback(hObject, eventdata, handles)
val=get(hObject,'Value');
if val==0,
    return;
end

parentDir=getappdata(handles.dlg_eQTLAnalysis_main,'parentDir');
workPath=strcat(parentDir,'\work data\');

%copy the Fetus SNP data into the work path
sourceFilePath=strcat(workPath,'Source Data\SNP_data_None_Fetus.mat');
destiFilePath=strcat(workPath,'SNP_data.mat');
[copySucess1]=copyfile(sourceFilePath,destiFilePath);

%copy the Fetus expression data into the work path
sourceFilePath=strcat(workPath,'Source Data\expressionData_None_Fetus.mat');
destiFilePath=strcat(workPath,'expressionData.mat');
[copySucess2]=copyfile(sourceFilePath,destiFilePath);


if copySucess1&&copySucess2,
    disp('==================================');
    disp('The None-Fetus data is the current source data!');
else
    disp('==================================');
    error('Source data cannot be moved to work path!');
end


% --- Executes on button press in radiobutton_Overall.
function radiobutton_Overall_Callback(hObject, eventdata, handles)

val=get(hObject,'Value');
if val==0,
    return;
end

parentDir=getappdata(handles.dlg_eQTLAnalysis_main,'parentDir');
workPath=strcat(parentDir,'\work data\');

%copy the Fetus SNP data into the work path
sourceFilePath=strcat(workPath,'Source Data\SNP_data.mat');
destiFilePath=strcat(workPath,'SNP_data.mat');
[copySucess1]=copyfile(sourceFilePath,destiFilePath);

%copy the Fetus expression data into the work path
sourceFilePath=strcat(workPath,'Source Data\expressionData.mat');
destiFilePath=strcat(workPath,'expressionData.mat');
[copySucess2]=copyfile(sourceFilePath,destiFilePath);


if copySucess1&&copySucess2,
    disp('==================================');
    disp('All available data is the current source data!');
else
    disp('==================================');
    error('Source data cannot be moved to work path!');
end


% --- Executes on button press in pushbutton_Batch_Analysis.
function pushbutton_Batch_Analysis_Callback(hObject, eventdata, handles)
parentDir=getappdata(handles.dlg_eQTLAnalysis_main,'parentDir');
    [filename, pathname, filterindex] = uigetfile(  { '*.*','MAT-files (*.mat)';}, ...
        'Pick CFM files',...
        'MultiSelect', 'off',...
    strcat(parentDir,'\work data\'));
    
workPath=strcat(parentDir,'\work data\');
if filename~=0
    clc
    %Preparing data
    disp('--------------------------');
    disp('Loading target SNP data, please wait...');
    creatTargetSNPData(pathname,filename,workPath);
    
    %eQTL analyzing
    disp('--------------------------');
    disp('Generating eQTL map, please wait...');
    getCorr_SNP_expression(workPath);
    
    %Search for significant SNPs
    disp('--------------------------');
    disp('Searching for significant eQTLs, please wait...');
    criticalP=getappdata(handles.dlg_eQTLAnalysis_main,'criticalP');
    criticalQ=getappdata(handles.dlg_eQTLAnalysis_main,'criticalQ');
    analyzeCorr(workPath,criticalP,criticalQ);
    
    %perform the permuation
    disp('--------------------------');
    disp('Performing the purmuation, please wait...');
    permutationN=getappdata(handles.dlg_eQTLAnalysis_main,'permutationN');
    performPermutation(workPath,permutationN);
    
    %generate report for the whole process
    disp('--------------------------');
    disp('Generating report for the eQTL analysis, please wait...');
    filePath=generateReport(workPath);
    
    
end
