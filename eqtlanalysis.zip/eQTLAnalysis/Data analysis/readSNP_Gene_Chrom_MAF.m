function readSNP_Gene_Chrom_MAF()
clc

[pathParent,pathGrad]=addPath();
% filePath=strcat(pathParent,'\work data\SNAPResults07-22-2015_1.txt')
% columnIndex=[1,5,6,8,10,11,12];
% [SNPinf,nSNP]=readTxtColumn1(filePath,nRow2Read,columnIndex);

filePath=strcat(pathParent,'\work data\SNAPResults07-23-2015.txt')
nRow2Read=inf;
columnIndex=[1,5,6];
[SNPinf,nSNP]=readTxtColumn1(filePath,nRow2Read,columnIndex);
% [SNPinf,nSNP]=readTxtColumn1(filePath,nRow2Read)


%save the data to .mat file
savePath=strcat(filePath(1:end-3),'mat')
save(savePath, 'SNPinf','nSNP');
 
t=0;