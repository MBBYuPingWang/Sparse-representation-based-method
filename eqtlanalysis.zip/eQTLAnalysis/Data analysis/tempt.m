function tempt()

clc
creatFetusData()
 

% getAgeInf()
% changeSNP_Chrom_Map();
% changeGene_chrom_Map();

function creatFetusData()

% %creat fetus expression data
% filePath='E:\research NIH4\work data0\Source Data\expressionData.mat';
% load(filePath,'expressionData','expressionProbeName','subID','nProbe','nSample','subAge','indexFetus','indexNoneFetus');
% expressionData=expressionData(:,indexFetus);
% subID=subID(indexFetus);
% nSample=length(subID);
% subAge=subAge(indexFetus);
% filePath='E:\research NIH4\work data0\Source Data\expressionData_Fetus.mat';
% save(filePath,'expressionData','expressionProbeName','subID','nProbe','nSample','subAge');

% %creat non-fetus expression data
% filePath='E:\research NIH4\work data0\Source Data\expressionData.mat';
% load(filePath,'expressionData','expressionProbeName','subID','nProbe','nSample','subAge','indexFetus','indexNoneFetus');
% expressionData(:,indexFetus)=[];
% subID(indexFetus)=[];
% nSample=length(subID);
% subAge(indexFetus)=[];
% filePath='E:\research NIH4\work data0\Source Data\expressionData_None_Fetus.mat';
% save(filePath,'expressionData','expressionProbeName','subID','nProbe','nSample','subAge');

%create Fetus SNP data
%load SNP data
filePath='E:\research NIH4\work data0\Source Data\SNP_data.mat';
load(filePath,'SNPData','SNPMAF','SNPName','subjID');
filePath='E:\research NIH4\work data0\Source Data\expressionData.mat';
load(filePath,'indexFetus');
SNPData=SNPData(:,indexFetus);
subjID=subjID(indexFetus);
filePath='E:\research NIH4\work data0\Source Data\SNP_data_Fetus.mat';
save(filePath,'SNPData','SNPMAF','SNPName','subjID');

%create non-Fetus SNP data
%load SNP data
filePath='E:\research NIH4\work data0\Source Data\SNP_data.mat';
load(filePath,'SNPData','SNPMAF','SNPName','subjID');
filePath='E:\research NIH4\work data0\Source Data\expressionData.mat';
load(filePath,'indexFetus');
SNPData(:,indexFetus)=[];
subjID(indexFetus)=[];
filePath='E:\research NIH4\work data0\Source Data\SNP_data_None_Fetus.mat';
save(filePath,'SNPData','SNPMAF','SNPName','subjID');



function getAgeInf()

filePath='E:\research NIH4\Liu Chunyu Data\age_expression.xlsx';
[nums,txt]=xlsread(filePath);
IDs=txt(:,1);
ageTxt=txt(:,2);
nID=length(IDs);
age=zeros(nID,1);
for i=1:nID,
    tt=ageTxt{i};
    age(i)=str2num(tt(5:end));
end
 
% plot(age);

%load the expression data
load('E:\research NIH4\work data0\Source Data\expressionData.mat', ...
    'expressionData','expressionProbeName','expressionSampleName','nProbe','nSample');
subID=splitStr(expressionSampleName,{'"'});%remove possible '"' in the str

[c,indexFroma,indexFromb,lc]=findCross2(subID,IDs);
subAge=age(indexFromb);

%find the fetus group 
indexFetus=find(subAge<=0);
indexNoneFetus=find(subAge>0);


save('E:\research NIH4\work data0\Source Data\expressionData.mat', ...
    'expressionData','expressionProbeName','subID','nProbe','nSample','subAge','indexFetus','indexNoneFetus');





function correctExpressionSNPData()
%%%%%ajust the sample of expression data
%reading the corresponed sample name of expression data
filePath='E:\research NIH4\Liu Chunyu Data\expression sample.txt';
[expressionSampleName0,nRows,nColumns]=readTxtColumn(filePath,1);
filePath='E:\research NIH4\Liu Chunyu Data\expression data.mat';
load(filePath,'expressionSampleName');
expressionSampleName=splitStr(expressionSampleName,{'"'});%remove possible '"' in the str
[c_b,indexFromb,lc,c_a,indexFroma]=findCross2(expressionSampleName0,expressionSampleName);
load(filePath,'expressionSampleName','expressionProbeName','expressionData','nProbe','nSample');
expressionSampleName=expressionSampleName(indexFromb);
expressionData=expressionData(:,indexFromb);
expressionProbeName=splitStr(expressionProbeName,{'"'});%remove possible '"' in the str
nSample=length(expressionSampleName);
filePath='E:\research NIH4\Liu Chunyu Data\expression sample_1.mat';
save(filePath,'expressionSampleName','expressionProbeName','expressionData','nProbe','nSample');

 
%%%%%ajust the sample of SNP data 
%reading the corresponed sample name of SNP data
filePath='E:\research NIH4\Liu Chunyu Data\SNP sample.txt';
[SNPSampleName0,nRows,nColumns]=readTxtColumn(filePath,1);
%read the SNPdata
savePath='E:\research NIH4\Liu Chunyu Data\SNP data.mat'
load(savePath,'subjID');
[c_b,indexFromb,lc,c_a,indexFroma]=findCross2(SNPSampleName0,subjID);
load(savePath,'SNPName','subjID','SNPData');

subjID=c_b;
SNPData=SNPData(:,indexFromb);
savePath='E:\research NIH4\Liu Chunyu Data\SNP data_1.mat'
save(savePath,'SNPName','subjID','SNPData');


function changeGene_chrom_Map()
load('E:\research NIH4\work data\hg19_gene_chrom_map.mat','geneChroMap','nGene' );



nGene=nGene-1;
GeneName0=geneChroMap(2:end,4);
chrc=geneChroMap(2:end,1);
posEc=geneChroMap(2:end,3);
posSc=geneChroMap(2:end,2);
NM_num=geneChroMap(2:end,5);

chr=zeros(nGene,1,'uint8');
posE=zeros(nGene,1);
posS=zeros(nGene,1);
for i=1:nGene
    tt=chrc{i};
    tt(1:3)=[];
    
    if strcmp(tt,'X')||strcmp(tt,'Y'),
        tt='23';
        disp('Sex chromosome');
    end
    %test is tt(1) is number or not
    if tt(1)>'9'||tt(1)<'1',
        tt='0';
    end
    if length(tt)>2
        tt=tt(1:2);
        if strcmp(tt(2),'_'),
            tt=tt(1);
        end            
    end


    chr(i)=str2num(tt);
    posE(i)=str2num(posEc{i});
    posS(i)=str2num(posSc{i});
end
    
[GeneName0,I]=sort(GeneName0);
chr=chr(I);
posE=posE(I);
posS=posS(I);
NM_num=NM_num(I);
savePath='E:\research NIH4\work data\Gene_Chromosom_Pos.mat'
save(savePath,'GeneName0','chr','posE','posS','NM_num');


function changeSNP_Chrom_Map()
load('E:\research NIH4\work data\SNAPResults07-23-2015.mat')
nSNP=nSNP-1;
SNPName0=SNPinf(2:end,1);
chrc=SNPinf(2:end,2);
posc=SNPinf(2:end,3);

pos=zeros(nSNP,1);
chr=zeros(nSNP,1,'uint8');
for i=1:nSNP
    pos(i)=str2num(posc{i});
    tt=chrc{i};
    tt(1:3)=[];
    chr(i)=str2num(tt);
end
    
[SNPName0,I]=sort(SNPName0);
chr=chr(I);
pos=pos(I);

savePath='E:\research NIH4\work data\SNP_Chromosom_Pos_BC.mat'
save(savePath,'SNPName0','chr','pos');


