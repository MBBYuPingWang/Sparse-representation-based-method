function writeSNPList2excel()
clc
% %load the SNPs from SNP_Gene_Map.mat
filePath='E:\research NIH4\work data\SNP_Gene_Map.mat';
load(filePath,'SNPName0');


lf=length(filePath);
filePath(lf-2:lf)='xls';
% xlswrite(filePath,SNPName0);


% X={ 'rs6589846'
%     'rs2568023'
%     'rs2164182'
%     'rs11606976'};
X=SNPName0;
filePath(lf-2:lf)='txt';
fid=fopen(filePath,'w+');
for i=1:size(X,1)
    fprintf(fid,'%s\n',X{i});
end
fclose(fid);
