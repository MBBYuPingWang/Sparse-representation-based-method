function wirteSNP2TXT()
clc
% filePath='E:\research NIH4\work data\SNP_data.mat';
% writeSNPName2TXT(filePath);

% filePath='E:\research NIH4\work data\SNAPResults.txt'; 
% readSNPPos(filePath) 

corrections()

% filePath='E:\research NIH4\work data\gene_Chromosom_Pos.txt'; 
% readGeneChromsomePos(filePath)

function readGeneChromsomePos(filePath)
delimiter={' ','	'}; 
% [txtData,nRows,nColumns]=readTxtColumn(filePath,[1,2,3],0,delimiter,10)
[infGene,nRows,nColumns]=readTxtColumn(filePath,[1:4],1,delimiter);
% save the data
savePath='E:\research NIH4\work data\Gene_Chromosom_Pos.mat';
nGene=nRows-1;
GeneName0=infGene(2:end,4);


% savePath='E:\research NIH4\work data\Gene_Chromosom_Pos.mat';
% load(savePath,'GeneName0','nGene','chr','posS','posE');
% infGene=[chr,posS,posE];

chr=zeros(nGene,1,'uint8');
posS=zeros(nGene,1);
posE=zeros(nGene,1);
for i=1:nGene
    disp(i);
    chr(i)=uint8(str2num(infGene{i+1,1}));
    posS(i)=str2double(infGene{i+1,2});
    posE(i)=str2double(infGene{i+1,3});
end

save(savePath,'GeneName0','nGene','chr','posS','posE');


function corrections()
filePath='E:\research NIH4\work data\SNP_Chromosom_Pos_BC_1.mat';
load(filePath,'pos','SNPName0','chr','nSNP');
% SNPName=chr;
% chr=SNPName0;
% SNPName0=SNPName;
% save(filePath,'pos','SNPName0','chr','nSNP');
% chr0=chr;
% chr=zeros(nSNP,1,'uint8');
% % chr(:)=str2num(chr0{:}(4:end));
% for i=1:nSNP
%     disp(i);
%     chr(i)=str2num(chr0{i}(4:end));
% end

pos0=pos;
pos=zeros(nSNP,1);
for i=1:nSNP
    disp(i);
    pos(i)=str2num(pos0{i});
end

filePath='E:\research NIH4\work data\SNP_Chromosom_Pos_BC.mat';
save(filePath,'pos','SNPName0','chr','nSNP');





function readSNPPos(filePath) 
% filePath='E:\research NIH4\work data\SNP_Chromosom_Pos.txt'; 
% filePath='E:\research NIH4\work data\Document.txt';
delimiter={' ','	'}; 
% [txtData,nRows,nColumns]=readTxtColumn(filePath,[1,2,3],0,delimiter,10)
[infSNP,nRows,nColumns]=readTxtColumn(filePath,[1,5,6],1,delimiter);
% save the data
savePath='E:\research NIH4\work data\SNP_Chromosom_Pos_BC.mat';
nSNP=nRows-1;
SNPName0=infSNP(2:end,1);
chr=infSNP(2:end,2);
pos=infSNP(2:end,3);
save(savePath,'SNPName0','nSNP','chr','pos');


function writeSNPName2TXT(filePath)
%load the SNP gene map
% load('E:\research NIH4\work data\SNP_Gene_Map.mat','SNPName0','SNP_GeneName0');
load(filePath,'SNPName');
%write the SNPname to a .txt file
filePath='E:\research NIH4\work data\SNPNames.txt';
fid=fopen(filePath','w+t');
nSNP=length(SNPName);
for i=1:nSNP
%     fprintf(fid,'%6.2f  %12.8f\n',y);
    fprintf(fid,'%s\n',SNPName{i});
end
fclose(fid);


