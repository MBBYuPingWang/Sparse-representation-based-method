function filePath=generateReport(workPath)
%this function generate the report for the whole eQTL analysis 

savePath=strcat(workPath,'Permutation4selectedGoodSNPs.mat');
load(savePath,'nGood','permute_pValue','eQTLPvalue','goodSNP','goodExpression','goodSNP_GeneName','pThresh_FDR');


%get the goodExpression corresponded genes
goodExpression_GeneName=getGeneName4ExpressionProbe(workPath,goodExpression);


%sort the results in ascend order
[eQTLPvalue,indexP]=sort(eQTLPvalue,'ascend');
permute_pValue=permute_pValue(indexP);
goodSNP=goodSNP(indexP);
goodExpression=goodExpression(indexP);
goodSNP_GeneName=goodSNP_GeneName(indexP);
goodExpression_GeneName=goodExpression_GeneName(indexP);


%get the SNP corresponded chromosome positions
savePath=strcat(workPath,'SNP_Chromosom_Pos_BC.mat');
load(savePath,'SNPName0','chr','pos');

[c,indexFroma,indexFromb,lc]=findCross2(goodSNP,SNPName0);
SNP_chr=zeros(nGood,1,'uint8');
SNP_pos=zeros(nGood,1);
SNP_chr(indexFroma)=chr(indexFromb);
SNP_pos(indexFroma)=pos(indexFromb);

%get the expression gene corresponded chromosome positions
savePath=strcat(workPath,'Gene_Chromosom_Pos.mat');
load(savePath,'GeneName0','chr','posE','posS');

[c,indexFroma,indexFromb,lc]=findCross2(goodExpression_GeneName,GeneName0);
expGene_chr=zeros(nGood,1,'uint8');
expGene_posS=zeros(nGood,1);
expGene_posE=zeros(nGood,1);
expGene_chr(indexFroma)=chr(indexFromb);
expGene_posS(indexFroma)=posS(indexFromb);
expGene_posE(indexFroma)=posE(indexFromb);

%judge the trans_ or cis_ eQTL status
beCis=judgeTrans_Cis_eQTL(SNP_chr,SNP_pos,expGene_chr,expGene_posS,expGene_posE);


filePath=strcat(workPath,'eQTLReport.xls');
%write the title of each column
columnTitle={'SNP Name','GeneName4SNP','chr_SNP','pos_SNP','Expression Probe','GeneName4Expresson','expGene_chr','expGene_posS','expGene_posE','Cis eQTL','eQTL pValue','Permutation pValue','pThresh_FDR'};
xlswrite(filePath,columnTitle);

%write the SNPName
columNum=97;
xlswrite(filePath,goodSNP,'Sheet1',sprintf('%c2:%c%d',columNum,columNum,nGood+1));

%write the SNP corresponded gene name
columNum=columNum+1;
xlswrite(filePath,goodSNP_GeneName,'Sheet1',sprintf('%c2:%c%d',columNum,columNum,nGood+1));

%write the chromsome number for the SNP
columNum=columNum+1;
xlswrite(filePath,SNP_chr,'Sheet1',sprintf('%c2:%c%d',columNum,columNum,nGood+1));

%write the chromsome position for the SNP
columNum=columNum+1;
xlswrite(filePath,SNP_pos,'Sheet1',sprintf('%c2:%c%d',columNum,columNum,nGood+1));

%write the goodExpression
columNum=columNum+1;
xlswrite(filePath,goodExpression,'Sheet1',sprintf('%c2:%c%d',columNum,columNum,nGood+1));

%write the expression probe corresponded gene name
columNum=columNum+1;
xlswrite(filePath,goodExpression_GeneName,'Sheet1',sprintf('%c2:%c%d',columNum,columNum,nGood+1));

%write the expression _gene located chromosome number
columNum=columNum+1;
xlswrite(filePath,expGene_chr,'Sheet1',sprintf('%c2:%c%d',columNum,columNum,nGood+1));

%write the expression _gene located chromosome start position
columNum=columNum+1;
xlswrite(filePath,expGene_posS,'Sheet1',sprintf('%c2:%c%d',columNum,columNum,nGood+1));

%write the expression _gene located chromosome end position
columNum=columNum+1;
xlswrite(filePath,expGene_posE,'Sheet1',sprintf('%c2:%c%d',columNum,columNum,nGood+1));

%write eQTL cis- trans- status
columNum=columNum+1;
xlswrite(filePath,beCis,'Sheet1',sprintf('%c2:%c%d',columNum,columNum,nGood+1));

%write the eQTL pValue 
columNum=columNum+1;
xlswrite(filePath,eQTLPvalue,'Sheet1',sprintf('%c2:%c%d',columNum,columNum,nGood+1));

%write the permutation pValue 
columNum=columNum+1;
xlswrite(filePath,permute_pValue,'Sheet1',sprintf('%c2:%c%d',columNum,columNum,nGood+1));

%write the FDR corrected pValue Threshold
columNum=columNum+1;
xlswrite(filePath,pThresh_FDR,'Sheet1',sprintf('%c2',columNum));

disp('Report has been generated! And saved to:');
disp(filePath);
winopen(filePath);


function expression_GeneName=getGeneName4ExpressionProbe(workPath,expressionProbeName)

nProbe=length(expressionProbeName);
expression_GeneName=cell(nProbe,1);
expression_GeneName(:)={''};
savePath=strcat(workPath,'expression denote.mat');
load(savePath,'geneName','probeName');
[c,indexFroma,indexFromb]=findCross2(expressionProbeName,probeName);

expression_GeneName(indexFroma)=geneName(indexFromb);








