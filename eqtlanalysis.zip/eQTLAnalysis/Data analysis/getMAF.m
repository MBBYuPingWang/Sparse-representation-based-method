function getMAF()
% This funciton using the brain cloud data set to acquire the Minor allele
% frequency (MAF) of each SNP
clc

SNPFilePath='E:\research NIH4\work data\SNP_data.mat';
load(SNPFilePath,'SNPData','SNPName','subjID' );

[nSNP,nSample]=size(SNPData); %the rows are the SNPs, the columns are the samples
SNPMAF=zeros(nSNP,1);
nAllele=2*nSample;
for i=1:nSNP
    i
    tempSNP=SNPData(i,:);
    SNPMAF(i)=(length(find(tempSNP==1))+length(find(tempSNP==2))*2)/nAllele;
end

save(SNPFilePath,'SNPData','SNPName','subjID','SNPMAF');