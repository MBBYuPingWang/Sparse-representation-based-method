function readGeneChromMap()
clc

[pathParent,pathGrad]=addPath();



filePath=strcat(pathParent,'\work data\hg19_gene_chrom_map.txt')
nRow2Read=inf;
% columnIndex=[1,5,6,8,10,11,12];
% [geneChroMap,nGene]=readTxtColumn1(filePath,nRow2Read,columnIndex);

% nRow2Read=2;
[geneChroMap,nGene,nColumns,nBadRows]=readTxtColumn1(filePath,nRow2Read);


%save the data to .mat file
savePath=strcat(filePath(1:end-3),'mat')
save(savePath, 'geneChroMap','nGene');

