function readAge()
clc
creatFetusData();
creatNonFetusData();

function creatNonFetusData()
load('E:\research NIH4\work data\expressionData.mat','expressionData','expressionProbeName','expressionSampleName','nProbe','nSample','sampleAge')
indexFetus=find(sampleAge>0);

expressionData=expressionData(:,indexFetus);
expressionSampleName=expressionData(indexFetus);
nSample=length(indexFetus);
sampleAge=sampleAge(indexFetus);
save('E:\research NIH4\work data\expressionData_None_Fetus.mat','expressionData','expressionProbeName','expressionSampleName','nProbe','nSample','sampleAge');

load('E:\research NIH4\work data\SNP_data.mat','SNPData','SNPMAF', 'SNPName','subjID','sampleAge');
SNPData=SNPData(:,indexFetus);
sampleAge=sampleAge(indexFetus);
subjID=subjID(indexFetus);
save('E:\research NIH4\work data\SNP_data_None_Fetus.mat','SNPData','SNPMAF', 'SNPName','subjID','sampleAge');

i=0;



function creatFetusData()
load('E:\research NIH4\work data\expressionData.mat','expressionData','expressionProbeName','expressionSampleName','nProbe','nSample','sampleAge')
indexFetus=find(sampleAge<=0);

expressionData=expressionData(:,indexFetus);
expressionSampleName=expressionData(indexFetus);
nSample=length(indexFetus);
sampleAge=sampleAge(indexFetus);
save('E:\research NIH4\work data\expressionData_Fetus.mat','expressionData','expressionProbeName','expressionSampleName','nProbe','nSample','sampleAge');

load('E:\research NIH4\work data\SNP_data.mat','SNPData','SNPMAF', 'SNPName','subjID','sampleAge');
SNPData=SNPData(:,indexFetus);
sampleAge=sampleAge(indexFetus);
subjID=subjID(indexFetus);
save('E:\research NIH4\work data\SNP_data_Fetus.mat','SNPData','SNPMAF', 'SNPName','subjID','sampleAge');

i=1;



% filePath='E:\research NIH4\Liu Chunyu Data\age inf.xlsx';
% [num,txt]=xlsread(filePath)
% 
% 
% [str,maxColumn]=splitStr(txt(:,2),{' '});
% 
% nSubj=length(str);
% age=zeros(nSubj,1);
% 
% for i=1:nSubj
%     age(i)=str2num(str{i,2});
% end
% 
% %load the gene expression data
% load('E:\research NIH4\work data\expressionData.mat','expressionData','expressionProbeName','expressionSampleName','nProbe','nSample')    
% [expressionSampleName,maxColumn]=splitStr(expressionSampleName,{'"'})
% 
% [c,indexFromb,indexFroma,lc]=findCross2(expressionSampleName,txt(:,1));
% expressionSampleAge=age(indexFromb);
% % save the updated expression data
% save('E:\research NIH4\work data\expressionData.mat','expressionData','expressionProbeName','expressionSampleName','nProbe','nSample','expressionSampleAge')    


% load('E:\research NIH4\work data\expressionData.mat','expressionSampleAge')    
% %load the gene expression data
% load('E:\research NIH4\work data\SNP_data.mat','SNPData','SNPMAF', 'SNPName','subjID');
% sampleAge=expressionSampleAge;
% 
% save('E:\research NIH4\work data\SNP_data.mat','SNPData','SNPMAF', 'SNPName','subjID','sampleAge');


% load('E:\research NIH4\work data\expressionData.mat','expressionData','expressionProbeName','expressionSampleName','nProbe','nSample','expressionSampleAge')    
% sampleAge=expressionSampleAge;
% save('E:\research NIH4\work data\expressionData.mat','expressionData','expressionProbeName','expressionSampleName','nProbe','nSample','sampleAge')    














