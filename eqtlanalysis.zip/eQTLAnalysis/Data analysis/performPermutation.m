function performPermutation(workPath,nRun)
%This function performs permutation for the selected SNPs

%load targetSNP data
savePath=strcat(workPath,'targetSNP_data.mat');
load(savePath,'targetSNPData','targetSNPMAF');

%load the express data
filePath=strcat(workPath,'expressionData.mat');
load(filePath,'expressionData');

% %load the target SNP data
% savePath=strcat(workPath,'targetSNP_data.mat');
% load(savePath,'targetSNPData');

%load the corr analysis results
savePath=strcat(workPath,'selectedGoodSNPs.mat');
load(savePath,'results','goodSNP','goodExpression','goodSNP_GeneName','pThresh_FDR');
indexSNP=results(:,1);
indexExpression=results(:,2);
eQTLPvalue=results(:,3);
nGood=length(indexSNP);

SNPData=targetSNPData(indexSNP,:)';
expressionData=expressionData(indexExpression,:)';

% results=results
% goodSNP=goodSNP

% nRun=10000; 
pValue=zeros(nGood,1);
for i=1:nGood
    disp('------------------------');
    disp(i);
    [pValue(i),minP]=eQTLpermutation(SNPData(:,i),expressionData(:,i),eQTLPvalue(i),nRun);
    disp([pValue(i),minP,eQTLPvalue(i)]);
end

permute_pValue=pValue;


%save the permutation results
savePath=strcat(workPath,'Permutation4selectedGoodSNPs.mat');
save(savePath,'nGood','permute_pValue','eQTLPvalue','goodSNP','goodExpression','goodSNP_GeneName','pThresh_FDR');
disp('-----------------------------------');
disp('Permutation is done! Results were saved to:');
disp(savePath);







