function testArgin(varargin)
clc
disp(varargin)
who