function [targetSNP,nSNP]=getTargetSNP(pathname,filename)
%this funciton get the SNPs for analysis from a .xls or .txt file

fileType=getFileType(filename);


if strcmp(fileType,'.xls')||strcmp(fileType,'.xlsx') 
    [targetSNP,nSNP]=readSNP_xls(pathname,filename);
elseif strcmp(fileType,'.txt')
    [targetSNP,nSNP]=readSNP_txt(pathname,filename);
else
    error('The current version only support excel file or .txt file!');
end


function [targetSNP,nSNP]=readSNP_xls(pathname,filename)
%read the target SNP data information
filePath=fullfile(pathname,filename);
[nums,targetSNP]=xlsread(filePath);
nSNP=length(targetSNP);


function [targetSNP,nSNP]=readSNP_txt(pathname,filename)
    filePath=fullfile(pathname,filename);
    [targetSNP,nSNP]=readTxtColumn(filePath);
    
 function fileType=getFileType(fileName)
     
pos=find(fileName=='.');
pos=pos(end);
fileType=fileName(pos:end);
        
