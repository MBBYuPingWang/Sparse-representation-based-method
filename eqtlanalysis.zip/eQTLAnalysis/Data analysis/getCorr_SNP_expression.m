function getCorr_SNP_expression(workPath)
% This function calculate the correlation coefficients between the target
% SNP data and expression data


%load targetSNP data
savePath=strcat(workPath,'targetSNP_data.mat');
load(savePath,'targetSNPName','nTargetSNP','targetSNPData','targetSNPMAF');


%load the express data
filePath=strcat(workPath,'expressionData.mat');
% save(filePath,'expressionSampleName','expressionProbeName','expressionData','nProbe','nSample');
load(filePath,'expressionData','expressionProbeName');
%calculate the corr
[corr_SNP_expression,pValue_SNP_expression]=corr(double(targetSNPData'+1),expressionData');

%save the result
savePath=strcat(workPath,'corr_SNP_expression.mat');
save(savePath,'corr_SNP_expression','pValue_SNP_expression','expressionProbeName','targetSNPName');

disp('The eQTL map calculation is done! Results saved to:')
disp(savePath);