function creatTargetSNPData(pathname,filename,workPath)
% This function using the user-provided SNPs and database SNP data to
% create the target SNP data
%pathname and filename are user provided source (.txt or .xls) file where the target SNPs
%were save in a single column

[targetSNP,nSNP]=getTargetSNP(pathname,filename);
disp(sprintf('%d SNPs have been uploaded!',nSNP));

%load the SNP database
SNPDatabasePath=strcat(workPath,'SNP_data.mat'); 
load(SNPDatabasePath,'SNPData','SNPName','subjID','SNPMAF');

%find the SNPs in the database
[targetSNPName,indexFromb,indexFroma,nTargetSNP]=findCross2(targetSNP,SNPName);
disp(sprintf('%d SNPs were identfied in current data source!',nTargetSNP));


%creat SNP data
targetSNPData=SNPData(indexFromb,:);
targetSNPMAF=SNPMAF(indexFromb);

%save the results
savePath=strcat(workPath,'targetSNP_data.mat');
save(savePath,'targetSNPName','nTargetSNP','targetSNPData','targetSNPMAF','subjID');
disp('Target SNP data were saved to:');
disp(savePath);
