function analyzeCorr(workPath,pThresh,qThresh)
%analysis the corr results and pick up the good SNPs and the corresponding
%expressions

%load the corr result
savePath=strcat(workPath,'corr_SNP_expression.mat');
load(savePath,'corr_SNP_expression','pValue_SNP_expression','expressionProbeName','targetSNPName');
% pThresh=1e-4;

%FDR correction
goodP=pValue_SNP_expression(find(pValue_SNP_expression(:)<pThresh));
[pThresh] = getFDR(goodP,qThresh);

%get the ones that satisfy the pThreshold
[I,J]=find(pValue_SNP_expression<pThresh);

if length(I)<1,
    disp('------------------------------------');
    disp('No significant eQTLs was identified!');
    disp('Please change the pThresh higher and redo the process!')
    return;
else
    disp('------------------------------------');
    disp(sprintf('Congratulations! %d eQTLs were identified!',length(I)));   
    disp('Prepare permutation test for those eQTLs, please wait...');
end

nGood=length(I);
results=zeros(nGood,3);
for i=1:nGood,
    results(i,:)=[I(i),J(i),pValue_SNP_expression(I(i),J(i))];
end

goodSNP=targetSNPName(I);%rows correspond to SNP
goodExpression=expressionProbeName(J);%columns correspond to expression

%get the SNP related genes
[tempGeneName,tempGeneIndex]=getGeneName4SNP(workPath,goodSNP); 
goodSNP_GeneName=cell(nGood,2);
goodSNP_GeneName(tempGeneIndex,:)=tempGeneName;

pThresh_FDR=pThresh;
%save the results
savePath=strcat(workPath,'selectedGoodSNPs.mat');
save(savePath,'results','goodSNP','goodExpression','goodSNP_GeneName','pThresh_FDR','nGood');

disp('Analysis is finished! Results saved to:');
disp(savePath);





% disp(results(:,1:2));
% disp(results(:,3));


% % find the corresponding SNP_gene and expression gene
% infSNP=cell(nGood,6);
% infSNP(:,1)=targSNPName(I);
% infSNP(:,2)=targgeneName(I);
% for i=1:nGood,
%     infSNP{i,3}=chr(I(i));
%     infSNP{i,4}=bp(I(i));
% end
% 
% infSNP(:,5)=expressionProbeName(J);
% %get the expression corresponded gene names
% savePath='E:\research NIH4\work data\expression denote.mat';
% load(savePath,'probeName','geneName');
% [c_b,indexFromb,lc,c_a,indexFroma]=findCross2(infSNP(:,5),probeName);
% infSNP(indexFroma,6)=geneName(indexFromb)';
% disp(infSNP) 
